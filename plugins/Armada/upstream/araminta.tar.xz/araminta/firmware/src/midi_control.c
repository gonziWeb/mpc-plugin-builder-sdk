/* SPDX-License-Identifier: GPL-3.0-only
 * Adapted from MIDI control contribution by ChanceTheMaker (2026).
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Shared USB/TRS channel controls. Included by seq.c after its input helpers.
 * USB and TRS intentionally share channel state, matching the existing routing.
 * A synth part has one live bend/wheel state; channels assigned to the same part
 * share it (last controller wins). Drum hits ignore bend and sustain. CC1 keeps the existing matrix routing. */
typedef struct {
    int16_t bend;                           /* signed 14-bit value, zero = centre */
    uint8_t wheel, pedal, targets;
    uint8_t owned[NTRK];                    /* held/pedal notes per track, at most 128 per channel */
    uint8_t ready, semis, cents;
    uint8_t rpn_msb, rpn_lsb;
} midi_channel_t;
static midi_channel_t midi_ch[16];
/* Two notes a byte, 4 bits each: 0 free; 1..4 track + 1; 5..8 the same, key released and held by the channel's pedal. */
static uint8_t midi_sel_on[16][64];
static uint16_t midi_owners[NTRK];           /* avoids rescanning all 2048 entries for CC123 */
#define MIDI_SEL_PEDAL 4u                    /* entries above it (5..8) are pedal-held */

static inline uint32_t sel_get(uint32_t ch, uint32_t note)
{
    return (midi_sel_on[ch][note >> 1] >> ((note & 1u) * 4u)) & 15u;
}

static inline void sel_set(uint32_t ch, uint32_t note, uint32_t v)
{
    uint32_t sh = (note & 1u) * 4u;
    midi_sel_on[ch][note >> 1] = (uint8_t)((midi_sel_on[ch][note >> 1] & ~(15u << sh)) | (v << sh));
}

static inline uint32_t sel_track(uint32_t v)
{
    return v > MIDI_SEL_PEDAL ? v - MIDI_SEL_PEDAL : v;
}

static inline uint32_t sel_pedal(uint32_t v)
{
    return v > MIDI_SEL_PEDAL;
}

static midi_channel_t *midi_channel(uint32_t ch)
{
    midi_channel_t *c = &midi_ch[ch];
    if (!c->ready) {
        c->semis = 2;
        c->rpn_msb = c->rpn_lsb = 127;
        c->ready = 1;
    }
    return c;
}

static uint32_t midi_targets(uint32_t ch)
{
    return midi_channel(ch)->targets | (1u << trk_index(midi_track(ch)));
}

static void midi_expression(track_t *t, const midi_channel_t *c)
{
    int32_t range = ((int32_t)c->semis * 100 + c->cents) * 256 / 100;
    if (drum_track(t))
        return;
    midi_bend_target[trk_index(t)] = (int16_t)((int32_t)c->bend * range / (c->bend < 0 ? 8192 : 8191));
}

static void midi_expression_channel(uint32_t ch)
{
    uint32_t i, mask = midi_targets(ch);
    for (i = 0; i < NPART; i++)
        if (mask & (1u << i))
            midi_expression(&trk[i], midi_channel(ch));
}

/* The VOICE page's PITCH card (params.c BEND_DESC) drives the selected track's channel bend: the same live
 * state USB / TRS pitch bend writes, so the RPN 0 range, voice.c's ~6 ms smoothing and "last controller wins"
 * all apply. The card reads midi_bend_target (not the smoothed value) so quick turns add up, and writes the
 * 14-bit bend midi_expression turns back into a target. */
static int32_t midi_bend_card_cents(void)
{
    int32_t q8 = midi_bend_target[trk_index(TSEL)];
    return (q8 * 100 + (q8 >= 0 ? 128 : -128)) / 256;       /* (rounded: a cent is 2.56 Q8 units) */
}
static uint8_t bend_card_ch = 0xFFu;          /* the channel the card last bent (0xFF: none) */
static void midi_bend_card_set(int32_t cents)
{
    uint32_t ch = trk_midi_ch(song.sel);
    midi_channel_t *c = midi_channel(ch);
    int32_t range = ((int32_t)c->semis * 100 + c->cents) * 256 / 100, q8 = cents * 256 / 100;
    if (range <= 0)
        return;
    c->bend = (int16_t)clamp(q8 * 8192 / range, -8192, 8191);
    midi_expression_channel(ch);
    bend_card_ch = (uint8_t)ch;
}
/* track_select (ui.c): a track change puts the channel the card last bent back to centre, so no note is left
 * bent behind it (as panel_wheels_route does for the PRESETS wheel's MIDI-out bend). */
static void midi_bend_card_track(uint32_t next)
{
    if (bend_card_ch < 16u && bend_card_ch != trk_midi_ch(next)) {
        midi_channel_t *c = midi_channel(bend_card_ch);
        if (c->bend) {
            c->bend = 0;
            midi_expression_channel(bend_card_ch);
        }
        bend_card_ch = 0xFFu;
    }
}

/* a MIDI note of track t sounds note: one played as itself, or a tone of one played as a chord (chord.c) */
static int midi_note_held(const track_t *t, uint32_t note)
{
    uint32_t ch, id = trk_index(t) + 1u;
    for (ch = 0; ch < 16u; ch++)
        if (sel_track(sel_get(ch, note)) == id && !mchord_of(ch, note, id))
            return 1;
    return mchord_held(id, note);
}

/* a key held on track t sounds note (the key's own note, or a tone of its chord) */
static int midi_local_held(const track_t *t, uint32_t note)
{
    uint32_t k, i;
    for (k = 0; k < 27u; k++)
        if (kb_chn[k] && kb_trk[k] == trk_index(t))
            for (i = 0; i < kb_chn[k]; i++)
                if (kb_chord[k][i] == note)
                    return 1;
    return 0;
}

static void midi_release(uint32_t ch, uint32_t note)
{
    uint32_t id = sel_track(sel_get(ch, note));
    sel_set(ch, note, 0);
    if (id) {
        midi_owners[id - 1u]--;
        if (!--midi_ch[ch].owned[id - 1u])
            midi_ch[ch].targets &= (uint8_t)~(1u << (id - 1u));
    }
    if (id) {
        mchord_t *m = mchord_of(ch, note, id);
        uint8_t nn[CHORD_MAX];
        uint32_t n = 1, i;
        nn[0] = (uint8_t)note;
        if (m) {                                  /* a chord: exactly the notes it started */
            midi_strum_pending &= ~(1u << (uint32_t)(m - mchord));   /* strings not yet played */
            n = m->n;
            for (i = 0; i < n; i++)
                nn[i] = m->note[i];
            m->id = 0;
        }
        for (i = 0; i < n; i++)
            if (!midi_local_held(&trk[id - 1u], nn[i]))
                input_off(&trk[id - 1u], nn[i]);  /* input_off also checks other MIDI owners */
    }
}

/* a MIDI note-on (ch, note) of track t: its chord (chord.c) or the note alone. A note another key or MIDI
 * note holds already sounds: not started again */
static void midi_play(track_t *t, uint32_t ch, uint32_t note, uint32_t vel)
{
    uint8_t nn[CHORD_MAX];
    uint32_t n = chord_build(t, note, nn), i, f = 0;
    if (n > 1u || nn[0] != note)
        for (f = 0; f < MCHORD_N && mchord[f].id; f++)
            ;
    if (f == MCHORD_N) {                          /* no room to keep a chord: the note alone */
        n = 1;
        nn[0] = (uint8_t)note;
    }
    if ((n > 1u || nn[0] != note) && chord_strum_begin(t, nn, n, &mchord[f].strum, vel)) {
        mchord_t *m = &mchord[f];                  /* STRUM: the first string now, the rest tick */
        m->ch = (uint8_t)ch;
        m->src = (uint8_t)note;
        m->id = (uint8_t)(trk_index(t) + 1u);
        m->n = 0;
        for (i = 0; i < n; i++)
            m->note[i] = nn[i];
        midi_chord_tone(m);
        midi_strum_pending |= 1u << f;
        return;
    }
    for (i = 0; i < n; i++)                        /* (before the table says they are held) */
        if (!midi_note_held(t, nn[i]) && !midi_local_held(t, nn[i]))
            input_on(t, nn[i], vel);
    if (n > 1u || nn[0] != note) {
        mchord_t *m = &mchord[f];
        m->ch = (uint8_t)ch;
        m->src = (uint8_t)note;
        m->n = (uint8_t)n;
        for (i = 0; i < n; i++)
            m->note[i] = nn[i];
        m->id = (uint8_t)(trk_index(t) + 1u);
    }
}

static void midi_note_event(uint32_t ch, uint32_t note, uint32_t vel)
{
    midi_channel_t *c = midi_channel(ch);
    uint32_t id = sel_track(sel_get(ch, note));
    if (vel) {
        track_t *t = midi_track(ch);
        /* Repeated notes replace the previous press, including a pedal-held one. */
        if (id)
            midi_release(ch, note);
        midi_expression(t, c);
        if (t != TSEL)
            midi_hint = (uint8_t)(trk_index(t) + 1u);
        c->targets |= (uint8_t)(1u << trk_index(t));
        midi_play(t, ch, note, vel);
        sel_set(ch, note, trk_index(t) + 1u);
        midi_owners[trk_index(t)]++;
        c->owned[trk_index(t)]++;
    } else if (id) {
        if (c->pedal && !drum_track(&trk[id - 1u]))
            sel_set(ch, note, id + MIDI_SEL_PEDAL);
        else
            midi_release(ch, note);
    }
}

static void midi_pedal_up(uint32_t ch)
{
    uint32_t note;
    midi_channel(ch)->pedal = 0;
    for (note = 0; note < 128u; note++)
        if (sel_pedal(sel_get(ch, note)))
            midi_release(ch, note);
}

/* Preset/project panic and CC120 must discard ownership so a later pedal-up
 * or note-off cannot release notes subsequently started on another patch. */
static void __attribute__((noinline)) midi_forget_track(uint32_t track)
{
    uint32_t ch, note;
    for (ch = 0; ch < 16u; ch++) {
        if (!(midi_ch[ch].targets & (1u << track)))
            continue;
        for (note = 0; note < 128u; note++)
            if (sel_track(sel_get(ch, note)) == track + 1u)
                sel_set(ch, note, 0);
        midi_ch[ch].targets &= (uint8_t)~(1u << track);
        midi_ch[ch].owned[track] = 0;
    }
    midi_owners[track] = 0;
    mchord_forget(track);
    midi_bend_q8[track] = midi_bend_target[track] = 0;
}

static void midi_silence_track(uint32_t track)
{
    track_t *t = &trk[track];
    uint32_t i;
    trk_all_off(t);
    t->nheld = t->arp_phys = t->rh_n = 0;
    arp_forget(t);
    t->seq_n = t->seq_hold = t->slide_glide = 0;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active)
            voice_kill(&t->v[i]);             /* one-block fade, regardless of RELEASE */
    sl[track].rec = sl[track].loop = 0;       /* do not keep replaying captured sound */
    midi_forget_track(track);
}

static int midi_track_held(uint32_t track)
{
    uint32_t k;
    if (midi_owners[track])
        return 1;
    for (k = 0; k < 27u; k++)
        if ((fm1_in.notes & (1u << k)) && kb_trk[k] == track)
            return 1;
    return 0;
}

/* The standard CC map (#103): always on, these CCs only, on the track the channel plays (ROUT as notes). A CC
 * sets its parameter as a knob would, 0..127 over its range (64: the middle of a bipolar one), and AUTOMATION
 * records it as a knob move (motion_capture: the selected track, armed and playing). CC121 resets none of them
 * (RP-015: they are the sound's). CC 71..77 are not here: they are the screen's knobs and the panel's three
 * encoders (cc_knob_input); DECAY lost its CC to them */
static const uint8_t MIDI_CC_MAP[][2] = {
    {5, P_GLIDE}, {7, P_LEVEL}, {10, P_PAN},
    {91, P_REV}, {93, P_IHMIX}, {94, P_DLY},   /* 93: insert CHOR MIX (bus CHO send retired; P_CHOR is FXPOS) */
};
/* a CC sets parameter id of track t as a knob would: 0..127 over its range */
static void midi_cc_set(track_t *t, uint32_t id, uint32_t value)
{
    const param_desc_t *d = param_desc_of(eng_idx(t->eng_req), id);
    int32_t v = d->min + ((int32_t)value * (d->max - d->min) + 63) / 127;
    if (d->max <= d->min || t->p[id] == v)
        return;
    t->p[id] = (int16_t)v;
    (void)motion_capture(t, id, (int16_t)v);
    scale_lock_after(t, id);
}
/* CC 71..77 (the four knobs of the page on screen, then SELECT / ALGORITHM / PRESETS), whatever channel ROUT hears.
 * One message is one detent, so any controller works without a mode: a pot that moves sets the sign of its move, an
 * endless encoder repeating one value reads as its side of 64 (the centre the FM-1's own knobs use). The UI applies
 * them as knob turns (ui_input.c cc_knob_poll: HOME's cards, lists, cursors, actions, pages, track, sound, with the
 * panel's acceleration). The audio ISR only counts detents: ui.cc_step, read and cleared by the main loop */
#define CC_KNOB_FIRST 71u
#define CC_KNOB_N 7u
static uint8_t cc_last[CC_KNOB_N];          /* each CC's value the time before */
static volatile int8_t *const cc_step;      /* ui.cc_step (defined by ui.c; a build without the UI: none) */
static void cc_knob_input(uint32_t cc, uint32_t value)
{
    uint32_t k = cc - CC_KNOB_FIRST;
    int32_t d = (int32_t)value - (int32_t)cc_last[k];
    int32_t step;
    if (!d)                                 /* a repeat: an endless encoder's one click, 64 +- the way it went */
        d = (int32_t)value - 64;
    cc_last[k] = (uint8_t)value;
    if (!d || !cc_step)
        return;
    step = (int32_t)cc_step[k] + (d > 0 ? 1 : -1);
    cc_step[k] = (int8_t)clamp(step, -127, 127);
}

static void __attribute__((noinline)) midi_cc_map(track_t *t, uint32_t cc, uint32_t value)
{
    uint32_t i, id = 0xFFFFu;
    if (cc >= CC_KNOB_FIRST && cc < CC_KNOB_FIRST + CC_KNOB_N) {
        cc_knob_input(cc, value);
        return;
    }
    for (i = 0; i < NELEM(MIDI_CC_MAP); i++)
        if (MIDI_CC_MAP[i][0] == cc)
            id = MIDI_CC_MAP[i][1];
    if (id == 0xFFFFu)
        return;
    midi_cc_set(t, id, value);
}

static void midi_control(uint32_t ch, uint32_t cc, uint32_t value)
{
    midi_channel_t *c = midi_channel(ch);
    uint32_t i, mask;
    switch (cc) {
    case 1:
        c->wheel = (uint8_t)value;
        break;
    case 120:                                      /* All Sound Off: ignores the pedal */
        mask = midi_targets(ch);
        for (i = 0; i < NTRK; i++)
            if (mask & (1u << i))
                midi_silence_track(i);
        break;
    case 123:                                      /* All Notes Off: normal releases, honours pedal */
        mask = midi_targets(ch);
        for (i = 0; i < 128u; i++)
            if (sel_get(ch, i))
                midi_note_event(ch, i, 0);
        for (i = 0; i < NTRK; i++)
            if ((mask & (1u << i)) && !midi_track_held(i)) {
                trk_all_off(&trk[i]);
                trk[i].nheld = trk[i].arp_phys = trk[i].rh_n = 0;
                arp_forget(&trk[i]);
            }
        break;
    case 121:                                      /* Reset All Controllers, keep bend sensitivity */
        c->bend = 0;
        c->wheel = 0;
        c->rpn_msb = c->rpn_lsb = 127;
        midi_expression_channel(ch);
        midi_pedal_up(ch);
        break;
    case 64:
        if (value >= 64u)
            c->pedal = 1;
        else
            midi_pedal_up(ch);
        break;
    case 101: c->rpn_msb = (uint8_t)value; break;
    case 100: c->rpn_lsb = (uint8_t)value; break;
    case 99: case 98:                              /* NRPN selection cancels RPN data entry */
        c->rpn_msb = c->rpn_lsb = 127;
        break;
    case 6: case 38:
        if (!c->rpn_msb && !c->rpn_lsb) {           /* RPN 0: +/-0..24 semitones, 0..99 cents */
            if (cc == 6u)
                c->semis = (uint8_t)(value > 24u ? 24u : value);
            else
                c->cents = (uint8_t)(value > 99u ? 99u : value);
            midi_expression_channel(ch);
        }
        break;
    default:
        midi_cc_map(midi_track(ch), cc, value);
        break;
    }
}

/* ROUT CH1-4 listens to channels 1..4 only (1.2: CH5-8, CH9-12, CH13-16 to their four). A switch to a block from
 * SEL or another block (events_block, before the queue) lets go of what the other channels hold: their notes
 * released (also pedal-held ones), their pedal, bend, wheel and RPN selection reset, so no note can hang on a
 * channel that is no longer heard. Each part's bend then follows its own channel of the block. */
static void __attribute__((noinline)) midi_route_block(void)
{
    uint32_t ch, note;
    for (ch = 0; ch < 16u; ch++) {
        midi_channel_t *c = midi_channel(ch);
        if (midi_in_block(ch)) {
            midi_expression(midi_track(ch), c);
            continue;
        }
        for (note = 0; note < 128u; note++)
            if (sel_get(ch, note))
                midi_release(ch, note);
        c->pedal = c->wheel = 0;
        c->bend = 0;
        c->rpn_msb = c->rpn_lsb = 127;
    }
}

/* Program Change (1.5.1, #179 by renebohne): the track the channel plays (ROUT as for notes) takes program d1. Only
 * noted here, 0x80 | d1 per track (a later one before the main loop wins): a sound load is the main loop's work
 * (undo, motion, FM6's patch), never the audio ISR's. ui.mpc (ui.c; a build without the UI: none) */
static volatile uint8_t *const mpc_io;      /* ui.mpc (ui.c midi_pc_poll) */

/* Keep the occasional controller/panic dispatch outside the hot rendering loop. Channel voice messages only
 * (realtime and clock are handled in events_block, SysEx never reaches here). With ROUT CH1-4 channels
 * 5..16 are ignored entirely (with CH5-8 .. CH13-16 every channel outside the block): notes, bend, CCs (CC1/11/64, RPN, and the CC120/121/123 panic and reset),
 * channel aftertouch, Program Change, so they stay free for other instruments. */
static void __attribute__((noinline)) midi_event(uint32_t st, uint32_t ch, uint32_t d1, uint32_t d2)
{
    if (song.g[G_ROUTE] != 1 && !midi_in_block(ch))
        return;
    if (st == 0x90u || st == 0x80u)
        midi_note_event(ch, d1, st == 0x90u ? d2 : 0);
    else if (st == 0xE0u) {
        midi_channel(ch)->bend = (int16_t)((int32_t)(d1 | (d2 << 7)) - 8192);
        midi_expression_channel(ch);
    } else if (st == 0xB0u) {
        mod_midi(midi_track(ch), st, d1, d2);
        midi_control(ch, d1, d2);
    } else if (st == 0xD0u)
        mod_midi(midi_track(ch), st, d1, d2);
    else if (st == 0xC0u && mpc_io)                /* Program Change: the main loop loads it (ui.c midi_pc_poll) */
        mpc_io[trk_index(midi_track(ch))] = (uint8_t)(0x80u | d1);
}
