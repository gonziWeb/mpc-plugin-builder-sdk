/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Chord keys (SCL > CHORD: P_CHRD, P_VOIC): one key, MIDI note or arp input plays a chord. Included by seq.c
 * after kb_map; runs in the audio ISR with the rest of the note input.
 *   CHRD OFF; DIA3 / DIA7: the triad / seventh of the track's scale (ROOT, SCALE) built on the key, every tone
 *        in key (a key outside the scale takes the scale note below it); MAJ MIN DOM7 MAJ7 MIN7 SUS4 POW: that
 *        shape on the key, whatever the scale.
 *   VOIC CLOSE (root position); OPEN (the second tone an octave up: 1-5-3); INV1 / INV2 (the lowest tone, then
 *        the next, an octave up); +OCT (the root an octave down added; a seventh drops its fifth). At most
 *        CHORD_MAX notes, notes outside 0..127 left out.
 * The key is mapped first (kb_map: MAP KBD / ALL, TRN, the octave), the chord is built on the note it gives.
 * MONO / LEGATO / UNISON parts play the chord's root only; a kit (the DRUM engine, slices: an
 * engine that maps the keys itself) ignores CHRD. Every source keeps the notes it started (kb_chord for a
 * key, mchord for a MIDI note) and its release ends exactly those, so CHRD / VOIC changed while it is held
 * leave nothing hanging. A note several sources hold sounds once and ends with the last of them. */
/* Append modes: these values are stored in songs, presets and editor files. */
enum { CH_OFF, CH_DIA3, CH_DIA7, CH_MAJ, CH_MIN, CH_DOM7, CH_MAJ7, CH_MIN7, CH_SUS4, CH_POW, CH_AUTO, CH_MELODY };
enum { VC_CLOSE, VC_OPEN, VC_INV1, VC_INV2, VC_BASS };
#define CHORD_MAX 4u
#define MCHORD_N 24u                     /* MIDI notes held as chords at once (more: their root alone) */

static const int8_t CHORD_SHAPE[CH_POW - CH_MAJ + 1][CHORD_MAX] = {
    {0, 4, 7, -1}, {0, 3, 7, -1}, {0, 4, 7, 10}, {0, 4, 7, 11}, {0, 3, 7, 10}, {0, 5, 7, -1}, {0, 7, 12, -1},
};

static uint8_t kb_chord[27][CHORD_MAX], kb_chn[27];   /* the notes key k started (kb_chn 0: none) */
typedef struct { uint32_t pos, beat; uint8_t total, rate, vel; } chord_strum_t;
static chord_strum_t kb_strum[27];
typedef struct { uint8_t id, ch, src, n, note[CHORD_MAX]; chord_strum_t strum; } mchord_t;   /* id: track + 1, 0 = free */
/* the strum a note-on belongs to (the free take records it: seq.c ft_note_on): rate 1..7, index
 * 0-based, total 2..CHORD_MAX. on = 0 for a chord played at once. */
static struct { uint8_t on, rate, index, total; } chord_strum_now;
static mchord_t mchord[MCHORD_N];
static uint32_t kb_strum_pending, midi_strum_pending;   /* bit per key / MIDI chord still sweeping */
static uint8_t chord_alternate[NTRK];                  /* STROKE ALT: the next chord's direction, per track */

/* seq.c, below: the note input and MIDI OUT */
static void input_on(track_t *t, uint32_t note, uint32_t vel);
static int midi_note_held(const track_t *t, uint32_t note);
static int midi_local_held(const track_t *t, uint32_t note);
static void midi_out_event(uint32_t e);
/* the last chord played per track (the CHORD page shows it): its root, notes, and the shape's tones above the
 * root (bit i = i semitones, 0..11) */
static struct { uint8_t root, n, note[CHORD_MAX]; uint16_t mask; } chord_last[NTRK];

/* 1 = the track's keys are a kit: no chords */
static int chord_kit(const track_t *t)
{
    const engine_t *e = ENGINES[eng_idx(t->eng_req)];
    return e->oneshot || (e->keys && e->keys(t, 0) >= 0);
}

/* CHRD / VOIC as the matrix leaves them when a key starts (mod.c mod_value): a per-block value is never in t->p
 * while keys are read here, so the matrix's slots are asked directly */
static uint32_t chord_mode(const track_t *t) { return (uint32_t)mod_value(t, P_CHRD); }
static uint32_t chord_voic(const track_t *t) { return (uint32_t)mod_value(t, P_VOIC); }

#include "chord_auto.c"
#include "chord_melody.c"

/* the tones of the chord (semitones above *root, ascending, iv[0] = 0) -> their number; DIA may move *root
 * down onto the scale */
static uint32_t chord_tones(const track_t *t, uint32_t mode, int32_t *root, int32_t *iv)
{
    uint32_t n = 0, i;
    if (mode >= CH_MAJ) {
        for (i = 0; i < CHORD_MAX && CHORD_SHAPE[mode - CH_MAJ][i] >= 0; i++)
            iv[n++] = CHORD_SHAPE[mode - CH_MAJ][i];
        return n;
    }
    {
        uint32_t mask = scale_mask(t), deg[12], c = 0, at = 0, guard = 12;
        int32_t r = t->p[P_ROOT];
        while (guard-- && !((mask >> (uint32_t)((*root - r + 120) % 12)) & 1u))
            (*root)--;                                  /* outside the scale: the scale note below */
        for (i = 0; i < 12u; i++)
            if ((mask >> i) & 1u) {
                if (i == (uint32_t)((*root - r + 120) % 12))
                    at = c;
                deg[c++] = i;
            }
        for (i = 0; i < (mode == CH_DIA7 ? 4u : 3u); i++) {   /* every other note of the scale */
            uint32_t k = at + 2u * i;
            iv[n++] = (int32_t)deg[k % c] + 12 * (int32_t)(k / c) - (int32_t)deg[at];
        }
        return n;
    }
}

/* the chord on note `root` as track t plays it now -> out (ascending), the number of notes (1..CHORD_MAX);
 * *rp its root, *maskp its tones above the root (bit i: i semitones; 0 = no chord). The root alone when CHRD
 * is OFF, on a kit, or for MONO / LEGATO / UNISON (their chord's root) */
static uint32_t chord_make(const track_t *t, uint32_t root, uint8_t *out, int32_t *rp, uint16_t *maskp)
{
    int32_t iv[CHORD_MAX + 1u], r = (int32_t)root, x;
    uint32_t mode = chord_mode(t), n, i, j, m = 0;
    uint16_t mask = 0;
    *rp = r;
    *maskp = 0;
    if (!mode || mode > CH_MELODY || chord_kit(t)) {
        out[0] = (uint8_t)root;
        return 1;
    }
    if (mode == CH_AUTO)
        return chord_auto_make(t, root, out, rp, maskp);
    if (mode == CH_MELODY)
        return chord_melody_make(t, root, out, rp, maskp);
    n = chord_tones(t, mode, &r, iv);
    for (i = 0; i < n; i++)
        mask |= (uint16_t)(1u << (iv[i] % 12));
    *rp = r;
    *maskp = mask;
    if (trk_vmode(t) != V_POLY) {                       /* one voice: the root */
        out[0] = (uint8_t)clamp(r, 0, 127);
        return 1;
    }
    switch (chord_voic(t)) {
    case VC_OPEN:                                       /* 1-5-3(-7): the second tone an octave up */
        if (n >= 3u)
            iv[1] += 12;
        break;
    case VC_INV2:
    case VC_INV1:
        for (j = 0; j < (chord_voic(t) == VC_INV2 ? 2u : 1u); j++) {   /* the lowest tone an octave up */
            x = iv[0] + 12;
            for (i = 1; i < n; i++)
                iv[i - 1u] = iv[i];
            iv[n - 1u] = x;
        }
        break;
    case VC_BASS:                                       /* the root an octave down; a seventh drops its fifth */
        if (n == CHORD_MAX) {
            iv[2] = iv[3];
            n--;
        }
        for (i = n; i > 0; i--)
            iv[i] = iv[i - 1u];
        iv[0] = -12;
        n++;
        break;
    default:
        break;
    }
    for (i = 1; i < n; i++)                             /* ascending */
        for (j = i; j > 0 && iv[j - 1u] > iv[j]; j--) {
            x = iv[j];
            iv[j] = iv[j - 1u];
            iv[j - 1u] = x;
        }
    for (i = 0; i < n && m < CHORD_MAX; i++) {          /* inside 0..127, each note once */
        x = r + iv[i];
        if (x < 0 || x > 127 || (m && out[m - 1u] == (uint8_t)x))
            continue;
        out[m++] = (uint8_t)x;
    }
    if (!m) {
        out[0] = (uint8_t)clamp(r, 0, 127);
        return 1;
    }
    return m;
}

/* chord_make for a note played now: a chord is kept in chord_last (the CHORD page shows it) */
static uint32_t chord_build(track_t *t, uint32_t root, uint8_t *out)
{
    int32_t r;
    uint16_t mask;
    uint32_t m = chord_make(t, root, out, &r, &mask), i, k = trk_index(t);
    if (chord_mode(t) == CH_AUTO && !chord_kit(t) && trk_vmode(t) == V_POLY)
        chord_auto_remember(t, r, mask, out, m);
    if (m > 1u || chord_mode(t) == CH_MELODY) {
        chord_last[k].root = (uint8_t)clamp(r, 0, 127);
        chord_last[k].mask = mask;
        chord_last[k].n = (uint8_t)m;
        for (i = 0; i < CHORD_MAX; i++)
            chord_last[k].note[i] = i < m ? out[i] : 0u;
    }
    return m;
}

/* a chord's name from its root and tones (bit i: i semitones above the root): "C", "Cm7", "F#m7b5", "Gsus4",
 * "A5" -> b (12 bytes) */
static void chord_name(char *b, uint32_t root, uint32_t mask)
{
    uint32_t mi = (mask >> 3) & 1u, ma = (mask >> 4) & 1u, b5 = (mask >> 6) & 1u, p5 = (mask >> 7) & 1u;
    uint32_t s5 = (mask >> 8) & 1u, d7 = (mask >> 9) & 1u, m7 = (mask >> 10) & 1u, M7 = (mask >> 11) & 1u;
    const char *q, *x = "";
    str_cpy(b, N_NOTE[root % 12u], 12);
    if (mi && !ma && b5 && !p5)
        q = d7 ? "dim7" : m7 ? "m7b5" : "dim";
    else if (ma && !mi && s5 && !p5)
        q = m7 ? "+7" : M7 ? "+M7" : "aug";
    else if (ma && !mi)
        q = m7 ? "7" : M7 ? "maj7" : d7 ? "6" : "";
    else if (mi)
        q = m7 ? "m7" : M7 ? "mM7" : d7 ? "m6" : "m";
    else if ((mask >> 5) & 1u) {                        /* no third: suspended */
        q = m7 ? "7" : "";
        x = "sus4";
    } else if ((mask >> 2) & 1u) {
        q = m7 ? "7" : "";
        x = "sus2";
    } else
        q = "5";
    str_cpy(b + str_len(b), q, 12 - str_len(b));
    str_cpy(b + str_len(b), x, 12 - str_len(b));
}

/* ------------------------------------------------------------- STRUM --- */
/* A division is the whole first-to-last sweep: onset k = (beat / DEN[rate]) * k / (n - 1), kept as a beat
 * fraction, so a tempo change mid-sweep keeps the proportions. Rate and direction freeze at the press. */
static const uint8_t STRUM_DEN[] = {1, 2, 4, 8, 16, 32, 6, 12};   /* OFF, 1/8 .. 1/128, 16T, 32T */
/* 1 = started (sound the first tone, then tick the rest), 0 = play the chord at once */
static int chord_strum_begin(track_t *t, uint8_t *notes, uint32_t n, chord_strum_t *s, uint32_t vel)
{
    uint32_t rate = sweep_rate(t), stroke = sweep_stroke(t), i;
    memset(s, 0, sizeof *s);
    if (!rate || rate >= NELEM(STRUM_DEN) || n < 2u || t->p[P_AMODE])
        return 0;
    if (stroke == 2u)
        stroke = (uint32_t)(chord_alternate[trk_index(t)]++ & 1u);
    if (stroke == 1u)                                  /* UP: the same sweep, top to bottom */
        for (i = 0; i < n / 2u; i++) {
            uint8_t x = notes[i];
            notes[i] = notes[n - 1u - i];
            notes[n - 1u - i] = x;
        }
    if (!stroke && chord_mode(t) == CH_MELODY) {
        /* MELO: the melody sounds on the press; DOWN orders the accompaniment below it. */
        uint8_t melody = notes[n - 1u];
        for (i = n - 1u; i; i--) notes[i] = notes[i - 1u];
        notes[0] = melody;
    }
    s->total = (uint8_t)n;
    s->rate = (uint8_t)rate;
    s->vel = (uint8_t)vel;
    s->beat = beat_samples() ? beat_samples() : 1u;
    return 1;
}
/* samples still due before `started` more tones (0: fire one), after `elapsed` samples */
static uint32_t chord_strum_due(chord_strum_t *s, uint32_t started, uint32_t elapsed)
{
    uint32_t beat = beat_samples() ? beat_samples() : 1u;
    if (s->beat != beat) {                             /* tempo moved: keep the beat fraction */
        s->pos = (uint32_t)(((uint64_t)s->pos * beat + s->beat / 2u) / s->beat);
        s->beat = beat;
    }
    s->pos += elapsed;
    {
        uint32_t target = (beat / STRUM_DEN[s->rate]) * started / (s->total - 1u);
        return s->pos < target ? target - s->pos : 0u;
    }
}
/* a strummed tone into the note input, tagged so the free take can put it back on the take's tempo */
static void chord_strum_input(track_t *t, uint32_t note, uint32_t vel, const chord_strum_t *s, uint32_t i)
{
    chord_strum_now.on = 1;
    chord_strum_now.rate = s->rate;
    chord_strum_now.index = (uint8_t)i;
    chord_strum_now.total = s->total;
    input_on(t, note, vel);
    chord_strum_now.on = 0;
}
static void key_chord_tone(uint32_t k, track_t *t)
{
    uint32_t i = kb_chn[k], note, mc = trk_midi_ch(trk_index(t));
    if (i >= CHORD_MAX)
        return;
    note = kb_chord[k][i];
    if (midi_local_held(t, note)) {                    /* (checked before counting it as started) */
        kb_chn[k] = (uint8_t)(i + 1u);
        return;
    }
    kb_chn[k] = (uint8_t)(i + 1u);
    chord_strum_input(t, note, 100, &kb_strum[k], i);
    midi_out_event(0x09u | (0x90u | mc) << 8 | note << 16 | 100u << 24);
}
static void midi_chord_tone(mchord_t *m)
{
    track_t *t = &trk[m->id - 1u];
    uint32_t i = m->n, note;
    if (i >= CHORD_MAX)
        return;
    note = m->note[i];
    if (!midi_note_held(t, note) && !midi_local_held(t, note))   /* (self excluded: n still i) */
        chord_strum_input(t, note, m->strum.vel, &m->strum, i);
    m->n = (uint8_t)(i + 1u);
}
/* one block: fire the strings whose onset is due */
static void chord_strum_tick(uint32_t n)
{
    uint32_t k;
    for (k = 0; k < 27u && kb_strum_pending; k++)
        if (kb_strum_pending & (1u << k)) {
            chord_strum_t *s = &kb_strum[k];
            chord_strum_due(s, kb_chn[k], n);
            while (kb_chn[k] < s->total && !chord_strum_due(s, kb_chn[k], 0))
                key_chord_tone(k, &trk[kb_trk[k]]);
            if (kb_chn[k] >= s->total)
                kb_strum_pending &= ~(1u << k);
        }
    for (k = 0; k < MCHORD_N && midi_strum_pending; k++)
        if (midi_strum_pending & (1u << k)) {
            mchord_t *m = &mchord[k];
            chord_strum_due(&m->strum, m->n, n);
            while (m->n < m->strum.total && !chord_strum_due(&m->strum, m->n, 0))
                midi_chord_tone(m);
            if (m->n >= m->strum.total)
                midi_strum_pending &= ~(1u << k);
        }
}

/* the MIDI note (ch, src) of track id - 1 that plays a chord, 0 = none */
static mchord_t *mchord_of(uint32_t ch, uint32_t src, uint32_t id)
{
    uint32_t i;
    for (i = 0; i < MCHORD_N; i++)
        if (mchord[i].id == id && mchord[i].ch == ch && mchord[i].src == src)
            return &mchord[i];
    return 0;
}

/* a MIDI-held chord of track id - 1 sounds note */
static int mchord_held(uint32_t id, uint32_t note)
{
    uint32_t i, j;
    for (i = 0; i < MCHORD_N; i++)
        if (mchord[i].id == id)
            for (j = 0; j < mchord[i].n; j++)
                if (mchord[i].note[j] == note)
                    return 1;
    return 0;
}

static void mchord_forget(uint32_t track)               /* panic: the track's MIDI chords are gone */
{
    chord_auto_forget(track);
    uint32_t i;
    for (i = 0; i < 27u; i++)
        if (kb_trk[i] == track)
            kb_strum_pending &= ~(1u << i);
    for (i = 0; i < MCHORD_N; i++)
        if (mchord[i].id == track + 1u) {
            mchord[i].id = 0;
            midi_strum_pending &= ~(1u << i);
        }
}
