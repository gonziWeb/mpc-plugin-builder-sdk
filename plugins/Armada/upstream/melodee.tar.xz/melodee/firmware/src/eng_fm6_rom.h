/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Kerem Kilic (Ellic Studio) */
/* FM6 factory voices (PTCH F9..F24): Melodee's own DX7 voices; SEND puts any of them out
 * as a DX7 single-voice dump.
 *
 * OP(EG rates 1-4, EG levels 1-4, key level scaling: break point, left / right depth,
 * left / right curve (0 -LIN, 1 -EXP, 2 +EXP, 3 +LIN), key rate scaling, AMS, velocity,
 * output level, coarse (0 = 0.5), fine, detune -7..7); OPX: fixed frequency (coarse 0..3 =
 * 1 Hz .. 1 kHz); the frequency is coarse x (1 + fine / 100). A voice: OP1..OP6, pitch EG rates and levels, algorithm (1..32),
 * feedback, oscillator key sync, LFO (speed, delay, PMD, AMD, sync, wave 0 TRI 1 SAW DOWN
 * 2 SAW UP 3 SQUARE 4 SINE 5 S&H, PMS), transpose (24 = none), name. */
#define OP(r1, r2, r3, r4, l1, l2, l3, l4, bp, ld, rd, lc, rc, rs, am, kv, ol, cr, fi, dt) \
    {r1, r2, r3, r4, l1, l2, l3, l4, bp, ld, rd, lc, rc, rs, am, kv, ol, 0, cr, fi, (dt) + 7}
#define OPX(r1, r2, r3, r4, l1, l2, l3, l4, bp, ld, rd, lc, rc, rs, am, kv, ol, cr, fi, dt) \
    {r1, r2, r3, r4, l1, l2, l3, l4, bp, ld, rd, lc, rc, rs, am, kv, ol, 1, cr, fi, (dt) + 7}
#define OP_OFF OP(99, 99, 99, 99, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0)
#define PEG(r1, r2, r3, r4, l1, l2, l3, l4) {r1, r2, r3, r4}, {l1, l2, l3, l4}
#define PEG_FLAT PEG(99, 99, 99, 99, 50, 50, 50, 50)
#define VOICE(o1, o2, o3, o4, o5, o6, peg, alg, fb, oks, lfo, name) \
    {{o1, o2, o3, o4, o5, o6}, peg, (alg) - 1, fb, oks, lfo, 24, name}
#define LFO(spd, dly, pmd, amd, sync, wave, pms) spd, dly, pmd, amd, sync, wave, pms
#define NO_LFO LFO(35, 0, 0, 0, 1, 0, 0)

#ifndef MELODEE_RES
#define MELODEE_RES  /* melodee.c: the resource region (res.c) */
#endif
static const fm6_rom_t FM6_ROM[] MELODEE_RES = {
    /* tine electric piano: three pairs; OP4 (x14) is the bell of the tine, gone in 0.2 s */
    VOICE(OP(96, 35, 25, 60, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 2, 98, 1, 0, 1),
          OP(95, 45, 25, 66, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 6, 70, 1, 0, -1),
          OP(96, 33, 25, 58, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 2, 92, 1, 0, 0),
          OP(99, 70, 40, 60, 99, 0, 0, 0, 51, 0, 34, 0, 1, 3, 0, 7, 66, 14, 0, 0),
          OP(96, 36, 25, 60, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 2, 82, 1, 0, -3),
          OP(95, 50, 25, 66, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 6, 60, 1, 0, 3),
          PEG_FLAT, 5, 2, 1, NO_LFO, "TINE EP   "),
    /* brass: OP6 with feedback drives three carriers, a slower modulator swell */
    VOICE(OP(70, 60, 50, 70, 99, 92, 90, 0, 39, 0, 0, 0, 0, 2, 0, 1, 97, 1, 0, 0),
          OP(55, 50, 40, 70, 80, 95, 90, 0, 39, 0, 0, 0, 0, 2, 0, 3, 82, 1, 0, 0),
          OP(72, 60, 50, 70, 99, 94, 92, 0, 39, 0, 0, 0, 0, 2, 0, 1, 95, 1, 0, 2),
          OP(72, 60, 50, 70, 99, 94, 92, 0, 39, 0, 0, 0, 0, 2, 0, 1, 93, 1, 0, -2),
          OP(72, 50, 45, 70, 99, 90, 88, 0, 39, 0, 0, 0, 0, 2, 0, 1, 80, 1, 0, 1),
          OP(48, 60, 40, 66, 95, 97, 92, 0, 39, 0, 0, 0, 0, 2, 0, 3, 84, 1, 0, 0),
          PEG_FLAT, 22, 6, 1, LFO(34, 40, 4, 0, 0, 4, 3), "BRASS SECT"),
    /* solid bass: x0.5 carrier and modulator, a x3 click pair on top */
    VOICE(OP(99, 52, 30, 72, 99, 88, 78, 0, 39, 0, 0, 0, 0, 2, 0, 1, 99, 0, 0, 0),
          OP(99, 64, 40, 72, 99, 72, 55, 0, 39, 0, 0, 0, 0, 2, 0, 5, 80, 0, 0, 0),
          OP(99, 80, 50, 72, 99, 55, 0, 0, 39, 0, 0, 0, 0, 2, 0, 2, 72, 1, 0, 0),
          OP(99, 86, 50, 72, 99, 30, 0, 0, 39, 0, 0, 0, 0, 2, 0, 4, 70, 3, 0, 0),
          OP_OFF, OP_OFF, PEG_FLAT, 1, 0, 1, NO_LFO, "SOLID BASS"),
    /* bells: three inharmonic pairs (x3.5, x5.4, x7) over long decays */
    VOICE(OP(99, 30, 20, 34, 99, 72, 0, 0, 39, 0, 0, 0, 0, 1, 0, 2, 96, 1, 0, 0),
          OP(99, 40, 25, 34, 99, 60, 0, 0, 39, 0, 0, 0, 0, 1, 0, 4, 72, 3, 17, 0),
          OP(99, 34, 22, 34, 99, 66, 0, 0, 39, 0, 0, 0, 0, 1, 0, 2, 84, 2, 0, 3),
          OP(99, 46, 25, 34, 99, 50, 0, 0, 39, 0, 0, 0, 0, 1, 0, 4, 64, 5, 8, 0),
          OP(99, 28, 20, 34, 99, 70, 0, 0, 39, 0, 0, 0, 0, 1, 0, 2, 80, 1, 0, -3),
          OP(99, 50, 30, 34, 99, 40, 0, 0, 39, 0, 0, 0, 0, 1, 0, 4, 56, 7, 0, 0),
          PEG_FLAT, 5, 0, 1, NO_LFO, "BELLS     "),
    /* marimba: a x4 mallet on the body, overtone pair at x4 / x10 */
    VOICE(OP(99, 56, 40, 56, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 3, 99, 1, 0, 0),
          OP(99, 80, 50, 60, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 5, 70, 4, 0, 0),
          OP(99, 68, 50, 60, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 3, 68, 4, 0, 0),
          OP(99, 84, 60, 60, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 5, 50, 10, 0, 0),
          OP_OFF, OP_OFF, PEG_FLAT, 5, 0, 1, NO_LFO, "MARIMBA   "),
    /* clavinet: bright, nasal pluck that holds while the key is down */
    VOICE(OP(99, 42, 30, 85, 99, 86, 62, 0, 39, 0, 0, 0, 0, 3, 0, 2, 99, 1, 0, 0),
          OP(99, 60, 40, 85, 99, 72, 50, 0, 39, 0, 0, 0, 0, 3, 0, 6, 78, 3, 0, 0),
          OP(99, 42, 30, 85, 99, 86, 62, 0, 39, 0, 0, 0, 0, 3, 0, 2, 84, 1, 0, 2),
          OP(99, 70, 50, 85, 99, 60, 40, 0, 39, 0, 0, 0, 0, 3, 0, 6, 80, 1, 0, 0),
          OP(99, 46, 34, 85, 99, 80, 55, 0, 39, 0, 0, 0, 0, 3, 0, 2, 70, 2, 0, 0),
          OP(99, 64, 44, 85, 99, 66, 46, 0, 39, 0, 0, 0, 0, 3, 0, 5, 60, 5, 0, 0),
          PEG_FLAT, 5, 5, 1, NO_LFO, "CLAVINET  "),
    /* drawbar organ: six carriers at 16' 8' 5 1/3' 4' 2 2/3' 2', a little vibrato */
    VOICE(OP(99, 99, 99, 88, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 84, 0, 0, 0),
          OP(99, 99, 99, 88, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 90, 1, 0, 0),
          OP(99, 99, 99, 88, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 78, 1, 50, 0),
          OP(99, 99, 99, 88, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 82, 2, 0, 0),
          OP(99, 99, 99, 88, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 72, 3, 0, 0),
          OP(99, 99, 99, 88, 99, 99, 99, 0, 39, 0, 0, 0, 0, 0, 0, 0, 70, 4, 0, 0),
          PEG_FLAT, 32, 2, 1, LFO(36, 0, 4, 0, 0, 4, 3), "DRAWBARS  "),
    /* strings: three detuned saw-like pairs, slow attack, delayed vibrato */
    VOICE(OP(42, 30, 50, 40, 99, 95, 95, 0, 39, 0, 0, 0, 0, 1, 0, 1, 92, 1, 0, 3),
          OP(40, 30, 50, 40, 86, 80, 80, 0, 39, 0, 0, 0, 0, 1, 0, 2, 76, 1, 0, 0),
          OP(42, 30, 50, 40, 99, 95, 95, 0, 39, 0, 0, 0, 0, 1, 0, 1, 92, 1, 0, -3),
          OP(40, 30, 50, 40, 86, 80, 80, 0, 39, 0, 0, 0, 0, 1, 0, 2, 76, 1, 0, 0),
          OP(42, 30, 50, 40, 99, 95, 95, 0, 39, 0, 0, 0, 0, 1, 0, 1, 84, 1, 0, 0),
          OP(40, 30, 50, 40, 86, 80, 80, 0, 39, 0, 0, 0, 0, 1, 0, 2, 70, 1, 0, 0),
          PEG_FLAT, 5, 6, 0, LFO(30, 50, 8, 0, 0, 4, 3), "STRINGS   "),
    /* glass pad: x1 / x2 pairs with a x1.41 shimmer, slow both ways */
    VOICE(OP(38, 30, 30, 34, 99, 92, 90, 0, 39, 0, 0, 0, 0, 0, 0, 1, 94, 1, 0, 2),
          OP(32, 26, 30, 34, 90, 70, 66, 0, 39, 0, 0, 0, 0, 0, 0, 2, 70, 1, 41, 0),
          OP(38, 30, 30, 34, 99, 92, 90, 0, 39, 0, 0, 0, 0, 0, 0, 1, 88, 2, 0, -2),
          OP(30, 26, 30, 34, 88, 70, 66, 0, 39, 0, 0, 0, 0, 0, 0, 2, 62, 3, 0, 0),
          OP(38, 30, 30, 34, 99, 92, 90, 0, 39, 0, 0, 0, 0, 0, 0, 1, 80, 1, 0, 0),
          OP(34, 30, 30, 34, 90, 80, 78, 0, 39, 0, 0, 0, 0, 0, 0, 2, 58, 1, 0, 0),
          PEG_FLAT, 5, 3, 0, LFO(24, 40, 5, 0, 0, 4, 3), "GLASS PAD "),
    /* lead: one carrier, three modulator chains, OP6 feedback for a saw edge */
    VOICE(OP(99, 50, 40, 70, 99, 94, 90, 0, 39, 0, 0, 0, 0, 2, 0, 1, 99, 1, 0, 0),
          OP(99, 60, 45, 70, 99, 86, 80, 0, 39, 0, 0, 0, 0, 2, 0, 4, 76, 1, 0, 0),
          OP(99, 55, 45, 70, 99, 82, 76, 0, 39, 0, 0, 0, 0, 2, 0, 4, 66, 2, 0, 0),
          OP(99, 70, 50, 70, 99, 60, 40, 0, 39, 0, 0, 0, 0, 2, 0, 5, 60, 3, 0, 0),
          OP(99, 60, 45, 70, 99, 88, 84, 0, 39, 0, 0, 0, 0, 2, 0, 3, 72, 1, 0, 1),
          OP(99, 60, 45, 70, 99, 88, 84, 0, 39, 0, 0, 0, 0, 2, 0, 3, 76, 1, 0, -1),
          PEG_FLAT, 16, 7, 1, LFO(38, 45, 6, 0, 0, 4, 3), "SYNC LEAD "),
    /* harp: plucked, about two seconds, a x2 pair for the string */
    VOICE(OP(99, 38, 28, 50, 99, 0, 0, 0, 39, 0, 0, 0, 0, 4, 0, 2, 98, 1, 0, 0),
          OP(99, 56, 35, 50, 99, 0, 0, 0, 39, 0, 0, 0, 0, 4, 0, 5, 70, 1, 0, 0),
          OP(99, 40, 28, 50, 99, 0, 0, 0, 39, 0, 0, 0, 0, 4, 0, 2, 82, 2, 0, 2),
          OP(99, 64, 40, 50, 99, 0, 0, 0, 39, 0, 0, 0, 0, 4, 0, 5, 56, 2, 0, 0),
          OP_OFF, OP_OFF, PEG_FLAT, 5, 0, 1, NO_LFO, "HARP      "),
    /* kalimba: a x5 tine over a short body, quick to fade */
    VOICE(OP(99, 52, 40, 54, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 3, 99, 1, 0, 0),
          OP(99, 76, 50, 56, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 6, 64, 5, 0, 0),
          OP(99, 62, 46, 54, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 3, 74, 3, 0, 0),
          OP(99, 84, 60, 56, 99, 0, 0, 0, 39, 0, 0, 0, 0, 3, 0, 6, 54, 9, 0, 0),
          OP_OFF, OP_OFF, PEG_FLAT, 5, 0, 1, NO_LFO, "KALIMBA   "),
    /* flute: a soft x1 pair with a little feedback breath on a quiet third carrier */
    VOICE(OP(62, 40, 50, 60, 99, 96, 96, 0, 39, 0, 0, 0, 0, 1, 0, 2, 97, 1, 0, 0),
          OP(54, 40, 50, 60, 80, 66, 64, 0, 39, 0, 0, 0, 0, 1, 0, 4, 64, 1, 0, 0),
          OP(60, 40, 50, 60, 99, 90, 90, 0, 39, 0, 0, 0, 0, 1, 0, 2, 58, 2, 0, 0),
          OP(56, 40, 50, 60, 90, 80, 80, 0, 39, 0, 0, 0, 0, 1, 0, 4, 50, 1, 0, 0),
          OP(70, 50, 50, 60, 99, 70, 60, 0, 39, 0, 0, 0, 0, 1, 0, 2, 50, 1, 0, 0),
          OP(70, 50, 50, 60, 99, 80, 76, 0, 39, 0, 0, 0, 0, 1, 0, 2, 48, 9, 0, 0),
          PEG_FLAT, 5, 7, 0, LFO(33, 60, 7, 0, 0, 4, 3), "FLUTE     "),
    /* steel drum: x1 carrier against a x3.4 modulator, a short pitch dip */
    VOICE(OP(99, 46, 34, 50, 99, 30, 0, 0, 39, 0, 0, 0, 0, 3, 0, 3, 98, 1, 0, 0),
          OP(99, 60, 40, 52, 99, 20, 0, 0, 39, 0, 0, 0, 0, 3, 0, 5, 72, 3, 13, 0),
          OP(99, 50, 36, 50, 99, 25, 0, 0, 39, 0, 0, 0, 0, 3, 0, 3, 80, 2, 0, 0),
          OP(99, 70, 46, 52, 99, 10, 0, 0, 39, 0, 0, 0, 0, 3, 0, 5, 58, 6, 0, 0),
          OP_OFF, OP_OFF, PEG(99, 70, 99, 99, 44, 50, 50, 50), 5, 0, 1, NO_LFO, "STEEL DRUM"),
    /* synth bass: OP6 feedback saw down a modulator chain, a fast filter-like decay */
    VOICE(OP(99, 56, 40, 74, 99, 86, 80, 0, 39, 0, 0, 0, 0, 2, 0, 1, 99, 1, 0, 0),
          OP(99, 70, 50, 74, 99, 60, 40, 0, 39, 0, 0, 0, 0, 2, 0, 5, 74, 1, 0, 0),
          OP(99, 56, 40, 74, 99, 86, 80, 0, 39, 0, 0, 0, 0, 2, 0, 1, 84, 0, 0, 0),
          OP(99, 74, 50, 74, 99, 56, 30, 0, 39, 0, 0, 0, 0, 2, 0, 5, 78, 1, 0, 0),
          OP(99, 70, 50, 74, 99, 64, 50, 0, 39, 0, 0, 0, 0, 2, 0, 5, 70, 1, 0, 0),
          OP(99, 70, 50, 74, 99, 70, 60, 0, 39, 0, 0, 0, 0, 2, 0, 4, 72, 1, 0, 0),
          PEG_FLAT, 7, 6, 1, NO_LFO, "SAW BASS  "),
    /* tubular bells: x1 against x3.5, struck, a long ring */
    VOICE(OP(99, 26, 20, 34, 99, 80, 0, 0, 39, 0, 0, 0, 0, 1, 0, 2, 96, 1, 0, 0),
          OP(99, 34, 22, 34, 99, 70, 0, 0, 39, 0, 0, 0, 0, 1, 0, 4, 74, 3, 17, 0),
          OP(99, 26, 20, 34, 99, 80, 0, 0, 39, 0, 0, 0, 0, 1, 0, 2, 82, 1, 0, 4),
          OP(99, 38, 24, 34, 99, 60, 0, 0, 39, 0, 0, 0, 0, 1, 0, 4, 66, 3, 17, 0),
          OP(99, 30, 22, 34, 99, 70, 0, 0, 39, 0, 0, 0, 0, 1, 0, 2, 60, 2, 0, 0),
          OP(99, 50, 30, 34, 99, 30, 0, 0, 39, 0, 0, 0, 0, 1, 0, 4, 48, 1, 41, 0),
          PEG_FLAT, 5, 0, 1, NO_LFO, "TUBULAR   "),
};
#define FM6_NROM (sizeof FM6_ROM / sizeof FM6_ROM[0])

#undef OP
#undef OPX
#undef OP_OFF
#undef PEG
#undef PEG_FLAT
#undef VOICE
#undef LFO
#undef NO_LFO
