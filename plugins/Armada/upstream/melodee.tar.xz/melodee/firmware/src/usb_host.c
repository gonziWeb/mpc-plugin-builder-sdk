/* SPDX-License-Identifier: GPL-3.0-only */
/* Copyright (C) 2026 Kerem Kilic (Ellic Studio)
 * Retains USB host enumeration and input contributed by recursivefieldinstruments (2026). */
/* USB MIDI host on USB0 (MELODEE_USB_HOST), included by usb.c after the SIE helpers and ep1_take.
 *
 * The port is either the computer-facing device (usb.c) or, when the menu's USB HOST is on, the host of a class
 * compliant USB-MIDI controller, alone, behind a hub, or behind a hub on a hub's port (many hubs are two hub chips
 * in one case: the first chip's last port is the second chip). The choice is never saved: every boot is a device, so
 * the update paths always work. Switching is the main loop's (uh_task); usb.up is 0 while the port is a host.
 *
 *   main loop (uh_task)   waits for a device, resets the bus, and enumerates it with blocking EP0 transfers
 *                         (hub: powers the ports, resets those with something on them, and tries each device
 *                         until one has a USB-MIDI streaming interface; a hub found there is walked the same way,
 *                         one level only). Failed direct probes wait for unplug; idle hubs are polled for
 *                         downstream connection changes. The ISR does nothing until uh.run.
 *   TIMER5 (uh_poll)      once uh.run is 1 the SIE is the ISR's alone: optional IN and OUT endpoints share host
 *                         EP1 in separate directions. IN is asked for a packet (ReqPkt), read when RxPktRdy, and its channel / clock events
 *                         go to the same ring as USB and TRS MIDI (source 1). A stall or a run of errors sets
 *                         uh.fault; the main loop then resets the bus and looks for a device again.
 *
 * Register sequences follow the AC79 SDK's USB0 host code (usb_h_sie_init, usb_h_chirp_and_reset, usb0_h_ep_read,
 * usb_ctlXfer): EP0 data moves through ep0buf / EP0_CNT as in the device driver, the target is FADDR (USB0 has no
 * per-endpoint function address), RXMAXP is 0xFF as everywhere in this firmware. Not driven: VBUS (the port
 * needs outside power, e.g. a powered hub), low-speed devices. OUT drains the existing MIDI track queue only
 * after the target ACKs; no SysEx/editor traffic is sent to attached devices.
 * Host OUT is tested against the SDK register definitions and a SIE model, not on hardware: see BUILDING.md. */
#if MELODEE_USB_HOST
#include "usb_host_desc.h"

enum { S_DEVCTL = 15, S_TXTYPE = 24, S_TXINTERVAL = 25, S_RXTYPE = 26, S_RXINTERVAL = 27 };
enum { UH_MSG_NONE, UH_MSG_ON, UH_MSG_OFF, UH_MSG_MIDI, UH_MSG_NOMIDI, UH_MSG_LOW, UH_MSG_LOST };
#define UH_FIRST_ADDR 1u
#define UH_MAX_ERRORS 16u
#define UH_HUB_LEVELS 2u                                /* the hub on the port, and one hub on its ports */
#define UH_HUB_PORTS 7u                                 /* ports used per hub */
#define UH_ROOT_TRIES 5u                                /* resets of a device that does not answer at all */

static uint8_t uh_rx[64 + 4] __attribute__((aligned(4)));
typedef struct {
    uint8_t addr, mps, ports;                           /* addr 0: no hub at this level */
    uint8_t port;                                       /* level 1: the level-0 port it is on */
} uh_hub_t;

static struct {
    uint8_t want;                                       /* the menu (main loop) */
    uint8_t on;                                         /* the port is a host */
    volatile uint8_t run;                               /* TIMER5 owns the active MIDI endpoints */
    volatile uint8_t fault;                             /* TIMER5 -> main loop: reset the bus and look again */
    uint8_t seen, next_addr, dev, tried;
    uint8_t answered;                                   /* the device on the port answered its first request */
    uh_hub_t hub[UH_HUB_LEVELS];
    uint8_t hub_poll_level, hub_poll_port;
    uint8_t in_ep, out_mps, tx_count, tx_rt, tx_errors, line_idle;   /* tx_rt: of tx_count, from the clock's ring */
    uint8_t msg;                                        /* one UH_MSG_* for main.c to show */
    volatile uint8_t errors;
    uint32_t t_ms, retry_ms;
    uint32_t tx_ms, hub_poll_ms;
    volatile uint32_t pkts, events;
} uh;

/* ------------------------------------------------ main loop: control --- */
static void uh_wait(uint32_t ms)                        /* main loop only */
{
    uint32_t t = fm1_ms;
    while (fm1_ms - t < ms)
        fm1_wdt_feed();
}

/* CSR0 (host) until want_set bits are all set and want_clr are all clear: >= 0 the CSR0, < 0 a stall / error / timeout */
static int uh_csr0(uint32_t want_set, uint32_t want_clr)
{
    uint32_t t = fm1_ms, v;
    for (;;) {
        v = sie_rd(S_CSR0);
        if (v & 0x04u) {                                /* RxStall */
            sie_wr(S_CSR0, 0);
            return -2;
        }
        if (v & 0x10u) {                                /* Error: no answer */
            sie_wr(S_CSR0, 0);
            return -1;
        }
        if ((v & want_set) == want_set && !(v & want_clr))
            return (int)v;
        if (fm1_ms - t > 500u)
            return -3;
        fm1_wdt_feed();
    }
}

/* One control transfer to `addr`: SETUP, the IN data stage if any, the status stage. Bytes read, or < 0.
 * Only requests without an OUT data stage (every one used here). The data goes to `out`, or with `walk` to the
 * descriptor walk, which may end the data stage early once it has found what it needs. */
static int uh_xfer(uint8_t addr, uint8_t rt, uint8_t rq, uint16_t val, uint16_t idx, uint16_t len, uint8_t *out,
                   uh_desc_t *walk, uint8_t mps)
{
    uint32_t got = 0, n, k, i, stop = 0;
    int r;
    sie_wr(S_FADDR, addr);
    sie_wr(S_INDEX, 0);
    ep0buf[0] = rt;
    ep0buf[1] = rq;
    ep0buf[2] = (uint8_t)val;
    ep0buf[3] = (uint8_t)(val >> 8);
    ep0buf[4] = (uint8_t)idx;
    ep0buf[5] = (uint8_t)(idx >> 8);
    ep0buf[6] = (uint8_t)len;
    ep0buf[7] = (uint8_t)(len >> 8);
    fm1_usb_ep0_send(ep0buf, 8);
    sie_wr(S_CSR0, 0x0Au);                              /* SetupPkt | TxPktRdy */
    r = uh_csr0(0, 0x02u);
    if (r < 0)
        return r;
    if (len && (rt & 0x80u)) {
        while (got < len) {
            sie_wr(S_CSR0, 0x20u);                      /* ReqPkt */
            r = uh_csr0(0x01u, 0);
            if (r < 0)
                return r;
            n = sie_rd(S_COUNT0);
            if (n > 64u)
                n = 64u;
            fm1_usb_rx_sync();
            k = got + n > len ? len - got : n;
            if (walk)
                stop = (uint32_t)uh_desc_feed(walk, ep0buf, k);
            else
                for (i = 0; i < k; i++)
                    out[got + i] = ep0buf[i];
            sie_wr(S_CSR0, 0);                          /* RxPktRdy done */
            got += n;
            if (n < mps || stop)
                break;
        }
        if (got > len)
            got = len;
        sie_wr(S_CSR0, 0x42u);                          /* status: StatusPkt | TxPktRdy (zero-length OUT) */
        r = uh_csr0(0, 0x02u);
    } else {
        sie_wr(S_CSR0, 0x60u);                          /* status: StatusPkt | ReqPkt (zero-length IN) */
        r = uh_csr0(0x01u, 0);
        if (r >= 0)
            sie_wr(S_CSR0, 0);
    }
    return r < 0 ? r : (int)got;
}

static int uh_ctl(uint8_t addr, uint8_t rt, uint8_t rq, uint16_t val, uint16_t idx, uint16_t len, uint8_t *out,
                  uint8_t mps)
{
    return uh_xfer(addr, rt, rq, val, idx, len, out, 0, mps);
}

/* ---------------------------------------------------- enumeration --- */
static int uh_hub_probe(uint8_t level, uint8_t addr, uint8_t mps, uint8_t cfgval, uh_midi_t *m);

/* A device on port p (1..7) of the hub at `level` gets its own address: 2..8 below the first hub, 9..15 below the
 * second, so a hub's devices never take an address the other hub's tree uses. */
static uint8_t uh_port_addr(uint8_t level, uint8_t p) { return (uint8_t)(UH_FIRST_ADDR + level * UH_HUB_PORTS + p); }

/* The device at address 0 (just reset): give it an address, read its configuration, and if it has a USB-MIDI
 * streaming interface select it. 1 = found, 0 = no (including a hub two levels down and a device that fails). */
static int uh_probe(uint8_t depth, uh_midi_t *m)
{
    uint8_t d8[8], c9[9], mps, cls, addr = uh.next_addr++;
    uint32_t total;
    uh_desc_t walk;
    int r;
    r = uh_ctl(0, 0x80, 6, 0x0100, 0, 8, d8, 8);        /* GET_DESCRIPTOR(device), first 8 bytes */
    if (r < 8)
        return 0;
    if (!depth)
        uh.answered = 1;
    mps = d8[7] == 16u || d8[7] == 32u || d8[7] == 64u ? d8[7] : 8u;
    cls = d8[4];
    if (uh_ctl(0, 0x00, 5, addr, 0, 0, 0, mps) < 0)     /* SET_ADDRESS */
        return 0;
    uh_wait(10);                                        /* the device settles to its new address */
    r = uh_ctl(addr, 0x80, 6, 0x0200, 0, 9, c9, mps);
    if (r < 9)
        return 0;
    total = (uint32_t)(c9[2] | c9[3] << 8);             /* the whole configuration, walked as it arrives */
    uh_desc_start(&walk, m);
    if (total > 9u && uh_xfer(addr, 0x80, 6, 0x0200, 0, (uint16_t)total, 0, &walk, mps) < 9)
        return 0;
    if (cls == 9u)                                      /* a hub */
        return depth < UH_HUB_LEVELS ? uh_hub_probe(depth, addr, mps, c9[5], m) : 0;
    if (!m->found)
        return 0;
    if (uh_ctl(addr, 0x00, 9, m->cfg, 0, 0, 0, mps) < 0)   /* SET_CONFIGURATION */
        return 0;
    if (m->alt && uh_ctl(addr, 0x01, 11, m->alt, m->iface, 0, 0, mps) < 0)   /* SET_INTERFACE */
        return 0;
    uh.dev = addr;
    return 1;
}

/* Probe only this downstream port of the hub at `level`; keep the hubs and the other devices configured. Each
 * port reuses its address on reconnect, so repeated hot-plugs cannot exhaust the USB address space. */
static int uh_hub_port_probe(uint8_t level, uint8_t p, uint32_t st, uh_midi_t *m)
{
    uint8_t b[4], addr = uh.hub[level].addr, mps = uh.hub[level].mps;
    uint32_t t;
    int r;
    if (!(st & 0x0001u) || (st & 0x0200u))              /* nothing there, or low speed */
        return 0;
    if (!level && uh.hub[1].addr && uh.hub[1].port == p)
        uh.hub[1].addr = 0;                             /* the reset takes the second hub's address and its tree */
    if (uh_ctl(addr, 0x23, 3, 4, p, 0, 0, mps) < 0)    /* SET_FEATURE(PORT_RESET) */
        return 0;
    t = fm1_ms;
    for (;;) {
        if (uh_ctl(addr, 0xA3, 0, 0, p, 4, b, mps) >= 4 && (b[2] & 0x10u))   /* C_PORT_RESET */
            break;
        if (fm1_ms - t > 500u)
            return 0;
        uh_wait(10);
    }
    uh_ctl(addr, 0x23, 1, 20, p, 0, 0, mps);            /* CLEAR_FEATURE(C_PORT_RESET) */
    if (uh_ctl(addr, 0xA3, 0, 0, p, 4, b, mps) < 4 || !(b[0] & 0x02u))   /* enabled? */
        return 0;
    uh_wait(20);                                        /* reset recovery */
    uh.next_addr = uh_port_addr(level, p);
    r = uh_probe((uint8_t)(level + 1u), m);
    if (!level && uh.hub[1].addr == uh_port_addr(0, p))
        uh.hub[1].port = p;                             /* a second hub was found here, configured even if idle */
    return r;
}

/* Read and acknowledge connection changes, including disconnects and unsupported devices. An unresponsive
 * hub is left alone until root unplug/replug (the first hub) or a change on its port (the second), rather than
 * repeating a blocking control timeout forever. */
static int uh_hub_status(uint8_t level, uint8_t p, uint8_t *b)
{
    uh_hub_t *h = &uh.hub[level];
    if (uh_ctl(h->addr, 0xA3, 0, 0, p, 4, b, h->mps) < 4 ||
        ((b[2] & 1u) && uh_ctl(h->addr, 0x23, 1, 16, p, 0, 0, h->mps) < 0)) {
        h->addr = 0;
        uh.hub[1].addr = 0;                             /* (the second hub is below the first) */
        return 0;
    }
    return 1;
}

/* Configure and power a hub once (level 0: the one on the port, 1: one on its ports). After the initial scan,
 * idle polling uses connection-change bits. */
static int uh_hub_probe(uint8_t level, uint8_t addr, uint8_t mps, uint8_t cfgval, uh_midi_t *m)
{
    uint8_t b[16], ports, p;                            /* (the hub descriptor is 9 bytes with <= 7 ports) */
    uint32_t good;
    uh_hub_t *h = &uh.hub[level];
    if (uh_ctl(addr, 0x00, 9, cfgval, 0, 0, 0, mps) < 0)
        return 0;
    if (uh_ctl(addr, 0xA0, 6, 0x2900, 0, 9, b, mps) < 7)   /* hub descriptor */
        return 0;
    ports = b[2] > UH_HUB_PORTS ? UH_HUB_PORTS : b[2];
    good = (uint32_t)b[5] * 2u;                         /* bPwrOn2PwrGood, in 2 ms */
    for (p = 1; p <= ports; p++)
        uh_ctl(addr, 0x23, 3, 8, p, 0, 0, mps);         /* SET_FEATURE(PORT_POWER) */
    uh_wait((good < 100u ? 100u : good) + 100u);        /* power good, then the devices announce themselves */
    h->addr = addr;
    h->mps = mps;
    h->ports = ports;
    if (!level) {
        uh.hub[1].addr = 0;
        uh.hub_poll_level = 0;
        uh.hub_poll_port = 1;
    }
    uh.hub_poll_ms = fm1_ms;
    for (p = 1; p <= ports; p++) {
        if (!uh_hub_status(level, p, b))
            return 0;
        if (uh_hub_port_probe(level, p, (uint32_t)(b[0] | b[1] << 8), m))
            return 1;
    }
    return 0;
}

/* the next hub port the idle poll reads: every port of the first hub, then of the second if there is one */
static void uh_hub_poll_next(void)
{
    uint8_t l = uh.hub_poll_level;
    if (uh.hub_poll_port < uh.hub[l].ports && uh.hub[l].addr) {
        uh.hub_poll_port++;
        return;
    }
    uh.hub_poll_level = !l && uh.hub[1].addr && uh.hub[1].ports ? 1u : 0u;
    uh.hub_poll_port = 1;
}

/* Host EP1 has independent RX/TX DMA slots. Both target endpoints belong to this device and alternate setting. */
static void uh_start_ep(const uh_midi_t *m)
{
    sie_wr(S_FADDR, uh.dev);
    sie_wr(S_INDEX, 1);
    uh.in_ep = m->in_ep;
    uh.out_mps = (uint8_t)m->out_mps;
    uh.tx_count = uh.tx_rt = uh.tx_errors = 0;
    uh.line_idle = 0;
    if (m->in_ep) {
        fm1_usb_ep_rxbuf(1, uh_rx);
        sie_wr(S_RXMAXP, 0xFF);
        sie_wr(S_RXCSR1, 0x90);                         /* clear data toggle, flush */
        sie_wr(S_RXCSR2, 0);
        sie_wr(S_RXTYPE, (uint32_t)(m->in_type << 4 | m->in_ep));
        sie_wr(S_RXINTERVAL, m->in_type == 3u ? m->in_interval : 0u);
        sie_wr(S_RXCSR1, 0x20u);                        /* ReqPkt */
    }
    if (m->out_ep) {
        fm1_usb_ep_txbuf(1, ep1tx);
        sie_wr(S_TXMAXP, 0xFF);                         /* AC79 USB0's DMA maximum, as in the device driver */
        sie_wr(S_TXCSR1, 0x48);                         /* ClrDataTog | FlushFIFO, only at endpoint start */
        sie_wr(S_TXCSR2, 0x20);                         /* MODE: TX half of a bidirectional endpoint */
        sie_wr(S_TXTYPE, (uint32_t)(m->out_type << 4 | m->out_ep));
        sie_wr(S_TXINTERVAL, m->out_type == 3u ? m->out_interval : 0u);
    }
    fm1_usb_ep_enable(1u << 1);
    uh.errors = 0;
    uh.fault = 0;
    RING_PUBLISH();
    uh.run = 1;
}

/* Stop admitting output before discarding queued notes. CPU0 releases the old USB input owners and schedules
 * releases for MIDI-track notes that had been admitted (including a packet with an uncertain ACK). */
static void uh_session_end(void)
{
    uh.run = 0;
    uh.out_mps = 0;
    uh.tx_count = uh.tx_rt = 0;
    mo_r = mo_w;
    rt_r = rt_w;
    RING_PUBLISH();
    midi_usb_lost = 1;
}

/* the controller's port as a host with nothing attached yet */
static void uh_host_up(void)
{
    usb.timeouts = 0;
    fm1_usb_reset();
    uh_wait(25);
    fm1_usb_host_attach(ep0buf);
    uh_wait(25);
    sie_wr(S_INTRUSBE, 0);
    sie_wr(S_INTRTX1E, 0);
    sie_wr(S_INTRTX2E, 0);
    sie_wr(S_INTRRX1E, 0);
    sie_wr(S_INTRRX2E, 0);
    fm1_usb_ep_enable(0x1Fu);
    sie_wr(S_FADDR, 0);
    sie_wr(S_DEVCTL, 0x03u);                            /* session + host request */
    uh.seen = 0;
    uh.line_idle = 0;
    uh.hub[0].addr = uh.hub[1].addr = 0;
}

/* a device is on the line: reset the bus and find the MIDI endpoint */
static void uh_connect(void)
{
    uh_midi_t m;
    uint32_t t;
    int ok;
    if (sie_rd(S_DEVCTL) & 0x20u) {                     /* low speed (FSDev is bit 6, LSDev bit 5) */
        if (!uh.tried)
            uh.msg = UH_MSG_LOW;                        /* said once per attach, as NO MIDI is */
        uh.tried = 1;
        return;
    }
    /* A root port reset lasts >= 50 ms (USB 2.0 TDRSTR). Some hubs answer only after 400 ms of recovery, so a
     * device that does not answer at all is reset again with a longer wait; one that answered is not. */
    for (t = 0;; t++) {
        sie_wr(S_POWER, 0x08u);                         /* bus reset */
        uh_wait(50);
        sie_wr(S_POWER, 0);
        uh_wait(100u << t);                             /* 100, 200, 400, 800, 1600 ms */
        uh.next_addr = UH_FIRST_ADDR;
        uh.answered = 0;
        if ((ok = uh_probe(0, &m)) || uh.answered || t + 1u == UH_ROOT_TRIES)
            break;
    }
    if (ok) {
        uh_start_ep(&m);
        uh.msg = UH_MSG_MIDI;
        uh.tried = 0;
    } else {
        if (!uh.tried)
            uh.msg = UH_MSG_NOMIDI;                     /* said once per attach */
        uh.tried = 1;
    }
}

/* Main loop. The menu's USB HOST (uh.want) switches the port; as a host this finds and keeps a controller. */
static void uh_task(uint32_t now)
{
    if (uh.want != uh.on) {
        usb.up = 0;                                     /* TIMER5 leaves the SIE to this context */
        usb.config = 0;
        usb.suspended = 0;
        uh_session_end();
        uh.fault = 0;
        uh.tried = 0;
        if (uh.want) {
#if MELODEE_USB_AUDIO
            ua_hw_stop();
            ua_host_volume_reset();
#endif
            usb.sx_on = 0;
            fm1_usb_off();
            uh.on = 1;
            uh_host_up();
            uh.retry_ms = now;
            uh.msg = UH_MSG_ON;
        } else {
            uh.on = 0;
            fm1_usb_off();
            usb.retry_ms = now - 1000u;                 /* usb_retry makes the port a device again at once */
            uh.msg = UH_MSG_OFF;
        }
        return;
    }
    if (!uh.on)
        return;
    if (uh.fault) {                                     /* stall, or the controller stopped answering (TIMER5 cleared run) */
        uh_session_end();
        uh.fault = 0;
        uh_host_up();
        uh.retry_ms = now + 500u;
        uh.msg = UH_MSG_LOST;
        return;
    }
    if (uh.run)
        return;
    if ((int32_t)(now - uh.t_ms) < 20 || (int32_t)(now - uh.retry_ms) < 0)
        return;
    uh.t_ms = now;
    if (!fm1_usb_line()) {
        uh.seen = 0;
        if (uh.line_idle < 5u) uh.line_idle++;
        if (uh.line_idle >= 5u) {                       /* debounce root disconnect while idle too */
            uh.tried = 0;
            uh.hub[0].addr = uh.hub[1].addr = 0;
        }
        return;
    }
    uh.line_idle = 0;
    if (uh.tried) {
        if (uh.hub[0].addr && uh.hub[0].ports && (uint32_t)(now - uh.hub_poll_ms) >= 100u) {
            uint8_t b[4], l = uh.hub_poll_level, p = uh.hub_poll_port;
            uh_midi_t m;
            uh.hub_poll_ms = now;
            uh_hub_poll_next();
            if (!uh.hub[l].addr)                       /* the second hub went since this port was chosen */
                return;
            if (!uh_hub_status(l, p, b) || !(b[2] & 1u))
                return;
            if (!l && uh.hub[1].addr && uh.hub[1].port == p)
                uh.hub[1].addr = 0;                    /* the second hub's port changed: it and its tree are gone */
            if ((b[0] & 1u) && !(b[1] & 2u)) {
                uh_wait(100);                          /* newly attached device settles before port reset */
                if (uh_hub_status(l, p, b) && uh_hub_port_probe(l, p, (uint32_t)(b[0] | b[1] << 8), &m)) {
                    uh_start_ep(&m);
                    uh.msg = UH_MSG_MIDI;
                    uh.tried = 0;
                }
            }
        }
        return;                                        /* direct failures wait for root unplug/replug */
    }
    if (uh.seen < 5u) {                                 /* 100 ms of a steady line before the bus reset */
        uh.seen++;
        return;
    }
    uh.seen = 0;
    uh_connect();
}

/* ------------------------------------------------------ TIMER5 ISR --- */
static void uh_fail(void)
{
    uh.run = 0;
    uh.fault = 1;
}

/* Retain ring slots and the DMA buffer until ACK. A NAK or transient error retries the same data toggle;
 * a stall, repeated errors or 500 ms without completion hands recovery to the main loop. Never wait here. */
static void uh_tx_poll(void)
{
    uint32_t csr = sie_rd(S_TXCSR1), n = 0;
    if (uh.tx_count) {
        if ((csr & 0x20u) || fm1_ms - uh.tx_ms >= 500u) {
            uh_fail();
            return;
        }
        if (csr & 0x84u) {                              /* Error / NAK timeout */
            if ((csr & 4u) && ++uh.tx_errors >= UH_MAX_ERRORS) {
                uh_fail();
                return;
            }
            sie_wr(S_TXCSR1, 0x01u);                    /* retry retained FIFO, preserving data toggle */
            return;
        }
        if (csr & 0x03u) return;                        /* TxPktRdy / FIFONotEmpty: no ACK yet */
        RING_PUBLISH();
        rt_r += uh.tx_rt;
        mo_r += (uint32_t)uh.tx_count - uh.tx_rt;
        uh.tx_count = uh.tx_rt = uh.tx_errors = 0;
    }
    while (rt_r + n / 4u != rt_w && n + 4u <= uh.out_mps) {
        uint32_t p = midi_rt_q[(rt_r + n / 4u) % RTQ];
        ep1tx[n] = (uint8_t)p;
        ep1tx[n + 1] = (uint8_t)(p >> 8);
        ep1tx[n + 2] = (uint8_t)(p >> 16);
        ep1tx[n + 3] = (uint8_t)(p >> 24);
        n += 4u;
    }
    uh.tx_rt = (uint8_t)(n / 4u);
    while (mo_r + n / 4u - uh.tx_rt != mo_w && n + 4u <= uh.out_mps) {
        uint32_t p = midi_out_q[(mo_r + n / 4u - uh.tx_rt) % MQ];
        ep1tx[n] = (uint8_t)p;
        ep1tx[n + 1] = (uint8_t)(p >> 8);
        ep1tx[n + 2] = (uint8_t)(p >> 16);
        ep1tx[n + 3] = (uint8_t)(p >> 24);
        n += 4u;
    }
    if (!n) return;
    uh.tx_count = (uint8_t)(n / 4u);
    uh.tx_ms = fm1_ms;
    fm1_usb_ep_send(1, ep1tx, n);
    sie_wr(S_TXCSR1, 0x01u);
}

static void uh_poll(void)
{
    uint32_t csr, n, i;
    if (!fm1_usb_line()) {
        /* EOP also drives SE0 briefly. Require 8 ms of idle samples, not one sample during a packet. */
        if (++uh.line_idle >= 16u) uh_fail();
        return;
    }
    uh.line_idle = 0;
    sie_wr(S_INDEX, 1);
    if (uh.out_mps) uh_tx_poll();
    if (!uh.run || !uh.in_ep) return;
    csr = sie_rd(S_RXCSR1);
    if (csr & 0x40u) {                                  /* RxStall: the endpoint is gone */
        uh_fail();
        return;
    }
    if (csr & 0x0Cu) {                                  /* Error / DataError: no usable answer */
        if (++uh.errors >= UH_MAX_ERRORS) {
            uh_fail();
            return;
        }
        sie_wr(S_RXCSR1, 0x20u);                        /* the flags clear (written 0) and the request goes again; the
                                                         * data toggle stays: it is reset when the endpoint starts only */
        return;
    }
    if (csr & 0x01u) {                                  /* a packet is in uh_rx */
        n = sie_rd(S_RXCOUNT1) | (sie_rd(S_RXCOUNT2) << 8);
        if (n > 64u)
            n = 64u;
        fm1_usb_rx_sync();
#ifndef MELODEE_LOADER
        if (MQ - (mi_w - mi_r) < EP1_ROOM)
            return;                                     /* ring too full: the packet stays, retried next poll */
#endif
        for (i = 0; i + 3u < n; i += 4u) {
            uint32_t p = uh_midi_ok((uint32_t)uh_rx[i] | (uint32_t)uh_rx[i + 1] << 8 |
                                    (uint32_t)uh_rx[i + 2] << 16 | (uint32_t)uh_rx[i + 3] << 24);
            if (p) {
                midi_enqueue(p, 1u);
                uh.events++;
            }
        }
        uh.pkts++;
        uh.errors = 0;
        sie_wr(S_RXCSR1, 0x10u);                        /* release the packet */
        sie_wr(S_RXCSR1, 0x20u);                        /* and ask for the next */
        return;
    }
    if (!(csr & 0x20u))                                 /* nothing pending: ask */
        sie_wr(S_RXCSR1, 0x20u);
}
#endif /* MELODEE_USB_HOST */
