/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * JIANT (FELUCCA TONIC): DRUM-X, after the idea of Sonic Charge's Microtonic (a tuned oscillator with a pitch
 * envelope and FM, a filtered noise generator, their envelopes, two patches and a MORPH between them), built anew
 * small and in fixed point for the FM-1. */
/* A DRUM-X sound (a lane of a kit) is dx_lane_t, 11 bytes: the mode and five values for each of its patches A and B:
 *   PITCH  the oscillator, MIDI 24..119 (33 Hz .. 7.9 kHz), 3/4 semitone a step
 *   PMOD   the pitch envelope: up to +4 octaves at the hit, falling with a sixth of the decay's tau (1..40 ms)
 *   DECAY  the amplitude's tau, 3 ms .. 1.5 s (exponential)
 *   NOISE  the mix: 0 the oscillator only .. 127 the noise only
 *   COLOR  the oscillator's FM index (SINE: its drive) and the noise filter's cutoff (30 Hz .. 16 kHz)
 * The mode: the oscillator (SINE, FM at 1:1, METAL at 1:1.47, BELL at 1:2.76), the noise filter (LP, BP, HP), the
 * noise's envelope (as the oscillator's, or SNAP: a quarter of its tau); (JIANT 0.4, the mode's free bits 5..7) the
 * pitch modulation, as Microtonic's: DECAY (the envelope above), LONG (its tau half the decay's, up to 250 ms: the
 * 808 boom), NOISE (a random pitch each block, scaled by the envelope: glitch, grit), SINE (a sine at 1/8 of the
 * pitch, scaled by the envelope: wobble, laser); and DRIVE (the oscillator x3 into a soft clip: dense kicks, fat toms).
 * MORPH (0 A .. 127 B) mixes the two patches value by value, read every block: it may move while a hit rings.
 * Envelopes per block (Q30 values, Q16 factors, dv_kb), ramped linearly inside it; the pitch ramps too. A hit
 * that has rung out (-84 dB) stops computing (live 0) and writes zeros. Only 32-bit products.
 *
 * (Skiff, modified 2026-10-10) From JIANT FM by juanjiant-bit, https://github.com/juanjiant-bit/JIANT (GPL-3.0-only),
 * at 9d1c453. In Skiff it is its own engine beside DRUM (eng_drumx.c), so the lanes (DV_*) and the helpers dv_exp2,
 * dv_kb are drum_voice.c's (the same code): this file is included after it. The rest as JIANT wrote it. */
enum { DXW_SINE, DXW_FM, DXW_METAL, DXW_BELL };
enum { DXF_LP, DXF_BP, DXF_HP };
#define DX_MODE(w, f, snap) ((uint8_t)((w) | (f) << 2 | (snap) << 4))
enum { DXM_DECAY, DXM_LONG, DXM_NOISE, DXM_SINE };       /* (JIANT 0.4) the pitch modulation: mode bits 5..6 */
#define DX_DRIVE 0x80u                                   /* .. the oscillator driven: bit 7 */
enum { DXP_PITCH, DXP_PMOD, DXP_DECAY, DXP_NOISE, DXP_COLOR, DXP_N };
typedef struct {
    uint8_t mode;
    uint8_t a[DXP_N], b[DXP_N];                          /* 0..127 */
} dx_lane_t;
typedef struct {                                         /* a hit */
    uint32_t ph, ph2, inc;                               /* the phases; the last block's end increment */
    int32_t ea, en, ep;                                  /* amplitude, noise (Q30), pitch (Q15) envelopes */
    int32_t ic1, ic2, rng;                               /* the noise filter's state, the noise */
    int32_t mo;                                          /* WARP: the modulator's last output (its feedback) */
    uint32_t ph3;                                        /* (JIANT 0.4) the SINE pitch modulation's phase */
    int32_t lp;                                          /* (JIANT 0.5) the output's one-pole low-pass state */
    uint8_t live, trig, choke;
} dx_voice_t;

/* the oscillator's modulator ratios (Q12), by wave */
static const uint16_t DX_RATIO[4] = {4096, 4096, 6021, 11305};

static void dx_trigger(dx_voice_t *v) { v->trig = 1; v->choke = 0; }
static void dx_choke(dx_voice_t *v) { if (v->live) v->choke = 1; }

/* a decay value (0..127) -> its tau in us: 3 ms x 2^(9 d / 127) */
static uint32_t dx_tau(uint32_t d) { return ((dv_exp2(d * 9u * 4096u / 127u) >> 8) * 3000u) >> 8; }

/* one block of lane L's hit v into y (n <= CTL): Q15, peaks near full scale. morph 0..127; tune16 1/16 semitones;
 * dofs / cofs / nofs move DECAY / COLOR / NOISE (-64..63). warp (DRUM's FOLD since JIANT 0.5, was WARP, 0..127): the
 * oscillator through a wavefolder after its envelope, x1 .. x9 into three folds at +-T: the hit's loud start folds
 * into bright partials, its tail unfolds back to the plain wave (a West Coast drum); 0: the patch as it is.
 * fm (DRUM's FM, JIANT, 0..127): every wave through FM with a harmonic modulator, its ratio in eight bands (x0.5 1 1.5
 * 2 3 4 5 7: the timbre's family) and, inside a band, its index rising (subtle .. hard); with WARP the two add. The oscillator and the noise each run their own loop (the wave and the
 * filter picked once a block), skipped when the mix leaves them out; gains and the pitch step per sample */
static __attribute__((noinline)) void dx_run(const dx_lane_t *L, dx_voice_t *v, int32_t morph, int32_t tune16,
                                             int32_t dofs, int32_t cofs, int32_t nofs, int32_t warp, int32_t fm, int32_t *y,
                                             uint32_t n)
{
    static const uint16_t FM_RATIO[8] = {128, 256, 384, 512, 768, 1024, 1280, 1792};   /* Q8 of the carrier */
    int32_t q[DXP_N], p16, depth, ea1, en1, ep1, og, ng, ga, dga, gn, dgn, kd, inc, dinc;
    uint32_t i, k, wave = L->mode & 3u, flt = (L->mode >> 2) & 3u, ta, tn, tp, kb, inc1;
    tsvf_t c;
    if (!v->live && !v->trig) {
        for (i = 0; i < n; i++)
            y[i] = 0;
        return;
    }
    morph = clamp(morph, 0, 127);
    for (k = 0; k < DXP_N; k++)
        q[k] = L->a[k] + ((L->b[k] - L->a[k]) * morph) / 127;
    q[DXP_DECAY] = clamp(q[DXP_DECAY] + dofs, 0, 127);
    q[DXP_COLOR] = clamp(q[DXP_COLOR] + cofs, 0, 127);
    q[DXP_NOISE] = clamp(q[DXP_NOISE] + nofs, 0, 127);
    ta = dx_tau((uint32_t)q[DXP_DECAY]);
    tn = (L->mode >> 4) & 1u ? ta >> 2 : ta;
    tp = ((L->mode >> 5) & 3u) == DXM_LONG ? (uint32_t)clamp((int32_t)(ta / 2u), 4000, 250000)
                                           : (uint32_t)clamp((int32_t)(ta / 6u), 1000, 40000);
    p16 = 384 + q[DXP_PITCH] * 12 + tune16;
    depth = q[DXP_PMOD] * 6;
    if (v->trig) {                                       /* the hit: from the top */
        v->trig = 0;
        v->live = 1;
        v->ea = v->en = 1 << 30;
        v->ep = 32767;
        v->ph = v->ph2 = 0;
        v->ic1 = v->ic2 = 0;
        if (!v->rng)
            v->rng = 0x2545F491;
        v->inc = pitch_inc((uint32_t)clamp(p16 + depth, 0, 2047));
    }
    kb = v->choke ? dv_kb(1500u) : dv_kb(ta);            /* (a choked hit: gone in ~5 ms) */
    ea1 = mulq16(v->ea, kb);
    en1 = mulq16(v->en, v->choke ? kb : dv_kb(tn));
    ep1 = (int32_t)(((uint32_t)v->ep * dv_kb(tp)) >> 16);
    {
        uint32_t pm = (L->mode >> 5) & 3u;
        int32_t off = (depth * ep1) >> 15;              /* DECAY, LONG: the envelope */
        if (pm == DXM_NOISE) {                          /* (JIANT 0.4) a random pitch each block, the envelope's depth */
            int32_t r = v->rng ? v->rng : 0x2545F491;
            off = (off * ((int32_t)noise32(&r) >> 17)) >> 14;
            v->rng = r;
        } else if (pm == DXM_SINE) {                    /* .. a sine at 1/8 of the pitch */
            v->ph3 += v->inc << 2;
            off = (off * sine_i(v->ph3)) >> 15;
        }
        inc1 = pitch_inc((uint32_t)clamp(p16 + off, 0, 2047));
    }
    ng = q[DXP_NOISE] * 258;
    og = ((32767 - ng) * 11) >> 4;                       /* (x 11 / 16: about the DRUM kits' level) */
    ng = (ng * 11) >> 4;
    ga = mulq15(og, v->ea >> 15) << 8;                   /* the oscillator's gain, Q23, stepped */
    dga = ((mulq15(og, ea1 >> 15) << 8) - ga) / (int32_t)n;
    gn = mulq15(ng, v->en >> 15) << 8;                   /* the noise's */
    dgn = ((mulq15(ng, en1 >> 15) << 8) - gn) / (int32_t)n;
    inc = (int32_t)(v->inc >> 4);                        /* (>> 4: the step fits) */
    dinc = ((int32_t)(inc1 >> 4) - inc) / (int32_t)n;
    if (og) {                                            /* the oscillator */
        uint32_t ph = v->ph;
        int32_t fold = clamp(warp, 0, 127);
        fm = clamp(fm, 0, 127);
        warp = fm ? 0x100 : 0;                           /* (FM: the FM loop below; the flag stripped there) */
        if (wave == DXW_SINE && q[DXP_COLOR] && !warp) {   /* drive x1 .. x2.5 into the soft clip */
            int32_t g = 4096 + q[DXP_COLOR] * 48;
            for (i = 0; i < n; i++, inc += dinc, ga += dga) {
                y[i] = mulq15(softclip((sine_i(ph) * g) >> 12), ga >> 8);
                ph += (uint32_t)inc << 4;
            }
        } else if (wave == DXW_SINE && !warp) {
            for (i = 0; i < n; i++, inc += dinc, ga += dga) {
                y[i] = mulq15(sine_i(ph), ga >> 8);
                ph += (uint32_t)inc << 4;
            }
        } else if (!warp) {                              /* FM: up to ~1.5 cycles of phase */
            uint32_t ph2 = v->ph2, ratio = DX_RATIO[wave];
            int32_t idx = q[DXP_COLOR] * 3;
            for (i = 0; i < n; i++, inc += dinc, ga += dga) {
                y[i] = mulq15(sine_i(ph + (uint32_t)(sine_i(ph2) * idx) * 512u), ga >> 8);
                ph += (uint32_t)inc << 4;
                ph2 += ((uint32_t)inc >> 8) * ratio;
            }
            v->ph2 = ph2;
        } else {                                         /* FM: harmonic, every wave */
            uint32_t w = 0u;
            uint32_t ph2 = v->ph2, ratio = (fm ? FM_RATIO[(uint32_t)fm >> 4] : DX_RATIO[wave]) + w * 70u, fb = w << 10;
            int32_t idx = q[DXP_COLOR] * 3 + (int32_t)w * 3 + (fm ? (((fm & 15) + 3) * 12) : 0), mo = v->mo;   /* (JIANT
                                                          * 0.5: the band's index halved and more, no glassy edge) */
            for (i = 0; i < n; i++, inc += dinc, ga += dga) {
                mo = sine_i(ph2 + (uint32_t)mo * fb);    /* (up to a turn of feedback; uint32: wraps as a phase) */
                y[i] = mulq15(sine_i(ph + (uint32_t)(mo * idx) * 512u), ga >> 8);
                ph += (uint32_t)inc << 4;
                ph2 += ((uint32_t)inc >> 8) * ratio;
            }
            v->ph2 = ph2;
            v->mo = mo;
        }
        v->ph = ph;
        if (L->mode & DX_DRIVE)                         /* (JIANT 0.4) DRIVE: x3 into the soft clip, the level near */
            for (i = 0; i < n; i++)
                y[i] = (softclip(y[i] * 3) * 22000) >> 15;
        if (fold) {                                      /* (JIANT 0.5) FOLD: after the envelope, so it follows it */
            int32_t g = 16 + (fold * 5 >> 3);            /* (JIANT 0.5: x1 .. x5.9, Q4; was x16.9: aliased hiss) */
            for (i = 0; i < n; i++) {
                int32_t v = clamp((y[i] * g) >> 4, -5 * 16384, 5 * 16384), a;
                for (a = 0; a < 3; a++)
                    v = v > 16384 ? 32768 - v : v < -16384 ? -32768 - v : v;
                y[i] = (v * 3) >> 1;
            }
        }
    } else {
        for (i = 0; i < n; i++)
            y[i] = 0;
    }
    if (ng) {                                            /* the noise through its filter */
        int32_t ic1 = v->ic1, ic2 = v->ic2, rng = v->rng;
        kd = flt == DXF_BP ? 2400 : 6000;                /* (BP a little resonant) */
        tsvf_coef_k(&c, q[DXP_COLOR] << 8, kd);
/* (one loop per filter: the choice is not made per sample) */
#define DX_NOISE(OUT)                                                                                              \
        for (i = 0; i < n; i++, gn += dgn) {                                                                       \
            int32_t r = (int32_t)noise32(&rng) >> 17, v3 = r - ic2, v1, v2;   /* +-16384 */                      \
            v1 = (c.a1 * ic1 + c.a2 * v3) >> 13;                                                                   \
            v2 = ic2 + ((c.a2 * ic1 + c.a3 * v3) >> 13);                                                           \
            ic1 = clamp(2 * v1 - ic1, -150000, 150000);                                                            \
            ic2 = clamp(2 * v2 - ic2, -150000, 150000);                                                            \
            y[i] += mulq15(clamp((OUT) << 1, -32767, 32767), gn >> 8);                                            \
        }
        if (flt == DXF_LP)
            DX_NOISE(v2)
        else if (flt == DXF_BP)
            DX_NOISE(v1)
        else
            DX_NOISE(r - ((kd * v1) >> 12) - v2)
#undef DX_NOISE
        v->ic1 = ic1;
        v->ic2 = ic2;
        v->rng = rng;
    }
    {                                                    /* (JIANT 0.5) the edge taken off: a one-pole low-pass at
                                                          * ~8 kHz on the sound (FM, FOLD and bright noise at 16 kHz
                                                          * were knife-sharp, the dice's above all) */
        int32_t lp = v->lp;
        for (i = 0; i < n; i++) {
            lp += ((y[i] - lp) * 22300) >> 15;
            y[i] = lp;
        }
        v->lp = lp;
    }
    v->ea = ea1;
    v->en = en1;
    v->ep = ep1;
    v->inc = inc1;
    if (v->ea < (1 << 16) && v->en < (1 << 16))         /* -84 dB */
        v->live = 0;
}

/* the factory kit: {mode, A, B}, A and B {PITCH PMOD DECAY NOISE COLOR}. dx_kit is the music's kit ((Skiff) the
 * project's, one for every DRUM-X track: project.c keeps it in SKF3), edited on EDIT > SOUND (ui_dx.c); DX_KIT_DEF
 * what a project without one gets */
#define DX_KIT_INIT {                                                                                                     \
    {DX_MODE(DXW_SINE, DXF_LP, 1), {9, 70, 72, 4, 20}, {14, 100, 88, 10, 60}},        /* KICK */                    \
    {DX_MODE(DXW_FM, DXF_BP, 0), {40, 30, 52, 80, 90}, {46, 18, 64, 104, 70}},       /* SNARE */                    \
    {DX_MODE(DXW_SINE, DXF_BP, 0), {60, 0, 46, 127, 84}, {54, 0, 58, 127, 76}},      /* CLAP */                     \
    {DX_MODE(DXW_METAL, DXF_HP, 0), {100, 0, 22, 96, 116}, {108, 0, 14, 112, 122}},  /* HAT CL */                   \
    {DX_MODE(DXW_METAL, DXF_HP, 0), {100, 0, 62, 96, 112}, {108, 0, 74, 112, 118}},  /* HAT OP */                   \
    {DX_MODE(DXW_SINE, DXF_LP, 1), {30, 40, 66, 10, 30}, {36, 60, 76, 20, 50}},      /* TOM */                      \
    {DX_MODE(DXW_BELL, DXF_HP, 1), {63, 10, 14, 16, 46}, {70, 24, 20, 30, 60}},     /* RIM */                       \
    {DX_MODE(DXW_METAL, DXF_BP, 0), {69, 0, 72, 0, 40}, {74, 0, 84, 12, 56}},        /* BELL */                     \
}
static const dx_lane_t DX_KIT_DEF[8] = DX_KIT_INIT;
static dx_lane_t dx_kit[8] = DX_KIT_INIT;
/* a stored kit as the voice takes it: values 0..127, the mode's fields in range (wave 0..3, filter 0..2, snap) */
static int dx_kit_ok(const dx_lane_t *k)
{
    uint32_t l, i;
    for (l = 0; l < 8u; l++) {
        if (((k[l].mode >> 2) & 3u) > DXF_HP)          /* (JIANT 0.4: bits 5..7 the pitch modulation, DRIVE) */
            return 0;
        for (i = 0; i < DXP_N; i++)
            if (k[l].a[i] > 127u || k[l].b[i] > 127u)
                return 0;
    }
    return 1;
}
