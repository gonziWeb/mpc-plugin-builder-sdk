/* SPDX-License-Identifier: GPL-3.0-only
 * Adapted from MIDI control contribution by ChanceTheMaker (2026).
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Shared USB/TRS channel controls. Included by seq.c after its input helpers.
 * USB and TRS intentionally share channel state, matching the existing routing.
 * A synth part has one live bend/wheel state; channels assigned to the same part
 * share it (last controller wins). Drum hits ignore bend and sustain. CC1 keeps the existing matrix routing. */
typedef struct {
    int16_t bend;                           /* signed 14-bit value, zero = centre */
    uint8_t wheel, pedal, targets;
    uint8_t owned[NTRK];                    /* held/pedal notes per track, at most 128 per channel */
    uint8_t ready, semis, cents;
    uint8_t rpn_msb, rpn_lsb;
} midi_channel_t;
static midi_channel_t midi_ch[16];
/* Low bits: track + 1. High bit: key released, held by its channel's pedal. */
static uint8_t midi_sel_on[16][128];
#define midi_notes midi_sel_on
static uint16_t midi_owners[NTRK];           /* avoids rescanning all 2048 entries for CC123 */
#define MIDI_PEDAL_NOTE 0x80u

static midi_channel_t *midi_channel(uint32_t ch)
{
    midi_channel_t *c = &midi_ch[ch];
    if (!c->ready) {
        c->semis = 2;
        c->rpn_msb = c->rpn_lsb = 127;
        c->ready = 1;
    }
    return c;
}

static uint32_t midi_targets(uint32_t ch)
{
    return midi_channel(ch)->targets | (1u << trk_index(midi_track(ch)));
}

static void midi_expression(track_t *t, const midi_channel_t *c)
{
    int32_t range = ((int32_t)c->semis * 100 + c->cents) * 256 / 100;
    if (drum_track(t))
        return;
    midi_bend_target[trk_index(t)] = (int32_t)c->bend * range / (c->bend < 0 ? 8192 : 8191);
}

static void midi_expression_channel(uint32_t ch)
{
    uint32_t i, mask = midi_targets(ch);
    for (i = 0; i < NPART; i++)
        if (mask & (1u << i))
            midi_expression(&trk[i], midi_channel(ch));
}

/* a MIDI note of track t sounds note: one played as itself, or a tone of one played as a chord (chord.c) */
static int midi_note_held(const track_t *t, uint32_t note)
{
    uint32_t ch, id = trk_index(t) + 1u;
    for (ch = 0; ch < 16u; ch++)
        if ((midi_notes[ch][note] & 0x7Fu) == id && !mchord_of(ch, note, id))
            return 1;
    return mchord_held(id, note);
}

/* a key held on track t sounds note (the key's own note, or a tone of its chord). (2.1, #74) With the ARP on, the SOLO
 * black keys' notes (seq.c kb_sol, sounding) and the others' (the ARP's) are apart: the keys of in_solo's kind */
static int midi_local_held(const track_t *t, uint32_t note)
{
    uint32_t k, i;
    for (k = 0; k < KB_N; k++)
        if (kb_chn[k] && kb_trk[k] == trk_index(t) && (!t->p[P_AMODE] || kb_sol[k] == in_solo))
            for (i = 0; i < kb_chn[k]; i++)
                if (kb_chord[k][i] == note)
                    return 1;
    return 0;
}

static void midi_release(uint32_t ch, uint32_t note)
{
    uint32_t id = midi_notes[ch][note] & 0x7Fu;
    midi_notes[ch][note] = 0;
    if (id) {
        midi_owners[id - 1u]--;
        if (!--midi_ch[ch].owned[id - 1u])
            midi_ch[ch].targets &= (uint8_t)~(1u << (id - 1u));
    }
    if (id) {
        mchord_t *m = mchord_of(ch, note, id);
        uint8_t nn[CHORD_MAX];
        uint32_t n = 1, i;
        nn[0] = (uint8_t)note;
        if (m) {                                  /* a chord: exactly the notes it started */
            n = m->n;
            for (i = 0; i < n; i++)
                nn[i] = m->note[i];
            m->id = 0;
        }
        for (i = 0; i < n; i++)
            if (!midi_local_held(&trk[id - 1u], nn[i]))
                input_off(&trk[id - 1u], nn[i]);  /* input_off also checks other MIDI owners */
    }
}

/* a MIDI note-on (ch, note) of track t: its chord (chord.c) or the note alone. A note another key or MIDI
 * note holds already sounds: not started again */
static void midi_play(track_t *t, uint32_t ch, uint32_t note, uint32_t vel)
{
    uint8_t nn[CHORD_MAX];
    uint32_t n = chord_build(t, note, nn), i, f = 0;
    if (n > 1u || nn[0] != note)
        for (f = 0; f < MCHORD_N && mchord[f].id; f++)
            ;
    if (f == MCHORD_N) {                          /* no room to keep a chord: the note alone */
        n = 1;
        nn[0] = (uint8_t)note;
    }
    for (i = 0; i < n; i++)
        if (!midi_note_held(t, nn[i]) && !midi_local_held(t, nn[i]))
            input_on(t, nn[i], vel);
    if (n > 1u || nn[0] != note) {
        mchord_t *m = &mchord[f];
        m->ch = (uint8_t)ch;
        m->src = (uint8_t)note;
        m->n = (uint8_t)n;
        for (i = 0; i < n; i++)
            m->note[i] = nn[i];
        m->id = (uint8_t)(trk_index(t) + 1u);
    }
}

static void midi_note_event(uint32_t ch, uint32_t note, uint32_t vel)
{
    midi_channel_t *c = midi_channel(ch);
    uint32_t id = midi_notes[ch][note] & 0x7Fu;
    if (vel) {
        track_t *t = midi_track(ch);
        /* Repeated notes replace the previous press, including a pedal-held one. */
        if (id)
            midi_release(ch, note);
        midi_expression(t, c);
        if (t != TSEL)
            midi_hint = (uint8_t)(trk_index(t) + 1u);
        c->targets |= (uint8_t)(1u << trk_index(t));
        midi_play(t, ch, note, vel);
        midi_notes[ch][note] = (uint8_t)(trk_index(t) + 1u);
        midi_owners[trk_index(t)]++;
        c->owned[trk_index(t)]++;
    } else if (id) {
        if (c->pedal && !drum_track(&trk[id - 1u]))
            midi_notes[ch][note] |= MIDI_PEDAL_NOTE;
        else
            midi_release(ch, note);
    }
}

static void midi_pedal_up(uint32_t ch)
{
    uint32_t note;
    midi_channel(ch)->pedal = 0;
    for (note = 0; note < 128u; note++)
        if (midi_notes[ch][note] & MIDI_PEDAL_NOTE)
            midi_release(ch, note);
}

/* Preset/project panic and CC120 must discard ownership so a later pedal-up
 * or note-off cannot release notes subsequently started on another patch. */
static void __attribute__((noinline)) midi_forget_track(uint32_t track)
{
    uint32_t ch, note;
    for (ch = 0; ch < 16u; ch++) {
        if (!(midi_ch[ch].targets & (1u << track)))
            continue;
        for (note = 0; note < 128u; note++)
            if ((midi_notes[ch][note] & 0x7Fu) == track + 1u)
                midi_notes[ch][note] = 0;
        midi_ch[ch].targets &= (uint8_t)~(1u << track);
        midi_ch[ch].owned[track] = 0;
    }
    midi_owners[track] = 0;
    mchord_forget(track);
    midi_bend_q8[track] = midi_bend_target[track] = 0;
}

static void midi_silence_track(uint32_t track)
{
    track_t *t = &trk[track];
    uint32_t i;
    trk_all_off(t);
    t->nheld = t->arp_phys = t->rh_n = 0;
    arp_forget(t);
    t->seq_n = t->seq_hold = t->slide_glide = 0;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active)
            voice_kill(&t->v[i]);             /* one-block fade, regardless of RELEASE */
    sl[track].rec = sl[track].loop = 0;       /* do not keep replaying captured sound */
    midi_forget_track(track);
}

static int midi_track_held(uint32_t track)
{
    uint32_t k;
    if (midi_owners[track])
        return 1;
    for (k = 0; k < 27u; k++)
        if ((fm1_in.notes & (1u << k)) && kb_trk[k] == track)
            return 1;
    return 0;
}

/* The standard CC map (#103): always on, these CCs only, on the track the channel plays (ROUT as notes). A CC
 * sets its parameter as a knob would, 0..127 over the parameter's range (64: the middle of a bipolar one), and
 * AUTOMATION records it as a knob move (motion_capture: the selected track, armed and playing). CC74 / CC71 are
 * the engine's own brightness / resonance (MIDI_CC_ENG); an engine without one ignores them. CC121 resets none
 * of them (RP-015: they are the sound's) */
#define MCC_CUT 0xFEu
#define MCC_RES 0xFFu
static const uint8_t MIDI_CC_MAP[][2] = {
    {5, P_GLIDE}, {7, P_LEVEL}, {10, P_PAN}, {71, MCC_RES}, {72, P_REL}, {73, P_ATK}, {74, MCC_CUT}, {75, P_DEC},
    {91, P_REV}, {93, P_CHOR}, {94, P_DLY},
};
/* per engine (ENGINES[] order): CC74's E index + 1 in the high nibble, CC71's in the low one, 0 = none */
static const uint8_t MIDI_CC_ENG[NENGINES] = {
    0x56, 0x00, 0x30, 0x80, 0x50, 0x07, 0x67, 0x00,   /* ANALOG CUT RES, -, PHASE DCW, LOFI TONE, SAMPLE CUT, VOICE Q,
                                                       * TRIO CUT RES, WHEEL - */
    0x80, 0x30, 0x30, 0x34, 0x30,                     /* GRAIN TONE, PHYS BRIT, DRUM TONE, NOISE FREQ RES, FM6 MLVL */
    FELUCCA_SLICE ? 0x80 : 0x00,                      /* SLICE TONE */
    0x30,                                             /* DRUM-X TONE */
    0x00,                                             /* (custom) SYNTH: its filter is FX > FILTER's (cc_eng_id) */
    0x12,                                             /* (custom) FMINI CUT EMPH */
};
/* the parameter CC74 (cut, 1) or CC71 (0) sets on track t: the engine's own (MIDI_CC_ENG), (custom) SYNTH's the FILTER's
 * CUTOFF / RESO; P_COUNT none */
static uint32_t cc_eng_id(const track_t *t, int cut)
{
    uint32_t e = eng_idx(t->eng_req), n = MIDI_CC_ENG[e] >> (cut ? 4 : 0) & 15u;
    if (e == ENGI_SYNTH)
        return cut ? P_FCUT : P_FRES;
    return n ? P_E0 + n - 1u : P_COUNT;
}
/* a CC sets parameter id of track t as a knob would: 0..127 over its range */
static void midi_cc_set(track_t *t, uint32_t id, uint32_t value)
{
    const param_desc_t *d = param_desc_of(eng_idx(t->eng_req), id);
    int32_t v = d->min + ((int32_t)value * (d->max - d->min) + 63) / 127;
    if (d->max <= d->min || t->p[id] == v)
        return;
    t->p[id] = (int16_t)v;
    (void)motion_capture(t, id, (int16_t)v);
}
/* (Skiff 1.3, from Felucca 1.5's MIDI LEARN, its Discussion #170) up to ML_N CCs, each set to one parameter of one
 * track, on whatever channel MIDI IN hears (one it ignores stays ignored). Kept with the settings in engine 1's
 * favourites row, bytes 2..31 (DIGITAL, retired: its stars were only ever byte 0, settings_persist.c; all 0 in every
 * older setting = nothing learned), an entry 3 bytes: the parameter's code (0 = empty; a common parameter its P_* id + 1,
 * an engine one ML_E0 + k for P_E0 + k: P_E0 moves when common ones are added), the CC, the track. A learned CC no
 * longer reaches the standard map (#103) on any channel: the controller is the user's now. The CCs with a meaning of
 * their own (midi_control's cases, CC0 / 32 bank select, CC11, CC96 / 97, CC120..127) are never learned. The UI
 * (midi_learn.c) writes the entries with the interrupts off; ml_arm / ml_heard hand it a CC heard while learning */
#define ML_N 10u
#define ML_E0 0xF8u
typedef char ml_ids_fit[P_E0 < ML_E0 && P_COUNT - P_E0 == 8 ? 1 : -1];
static uint8_t *const ml_tab;               /* (midi_learn.c: a build without the UI, none) */
static volatile uint8_t *const ml_io;       /* ui.ml.io (midi_learn.c; not globals here: the ISR's data keeps its layout) */
#define ml_arm (ml_io[0])                   /* the UI waits for a CC (MIDI LEARN with a parameter picked) */
#define ml_heard (ml_io[1])                 /* .. the CC that came meanwhile, + 1 (0 none) */
static uint32_t ml_id(uint32_t code)        /* an entry's code -> P_* id, P_COUNT: none this firmware knows */
{
    return code >= ML_E0 ? P_E0 + code - ML_E0 : code && code <= P_E0 ? code - 1u : P_COUNT;
}
static int ml_free_cc(uint32_t cc)          /* (CC1 6 38 64 98..101 120..127: midi_control's own) */
{
    return cc && cc < 120u && cc != 1u && cc != 6u && cc != 11u && cc != 32u && cc != 38u && cc != 64u &&
           (cc < 96u || cc > 101u);
}
/* 1: cc is learned (set here) or taken by MIDI LEARN waiting for one */
static int __attribute__((noinline)) midi_learned(uint32_t cc, uint32_t value)
{
    uint32_t i, id, hit = 0;
    if (!ml_tab || !ml_free_cc(cc))
        return 0;
    if (ml_arm) {
        if (!ml_heard)
            ml_heard = (uint8_t)(cc + 1u);
        return 1;
    }
    for (i = 0; i < ML_N; i++) {
        const uint8_t *e = ml_tab + 3u * i;
        if (e[0] && e[1] == cc) {
            if ((id = ml_id(e[0])) < P_COUNT && e[2] < NTRK)
                midi_cc_set(&trk[e[2]], id, value);
            hit = 1;
        }
    }
    return hit;
}

/* (2.2) CC OUT: the CC parameter id of track t goes out on: the CC learned to it (MIDI LEARN: the user's), else the
 * standard map's (CC74 / CC71 the engine's own), unless MIDI LEARN took that CC for another parameter; 0 none */
static uint32_t cc_out_of(const track_t *t, uint32_t id)
{
    uint32_t i, j, c = 0;
    for (i = 0; ml_tab && i < ML_N; i++)
        if (ml_tab[3u * i] && ml_id(ml_tab[3u * i]) == id && ml_tab[3u * i + 2u] == trk_index(t))
            return ml_tab[3u * i + 1u];
    for (i = 0; i < NELEM(MIDI_CC_MAP) && !c; i++) {
        uint32_t p = MIDI_CC_MAP[i][1];
        if ((p >= MCC_CUT ? cc_eng_id(t, p == MCC_CUT) == id : p == id))
            c = MIDI_CC_MAP[i][0];
    }
    for (j = 0; c && ml_tab && j < ML_N; j++)
        if (ml_tab[3u * j] && ml_tab[3u * j + 1u] == c)
            return 0;
    return c;
}
/* .. its value, 0..127 over the parameter's range: midi_cc_set's inverse (that CC coming back sets the same value) */
static uint32_t cc_value(const track_t *t, uint32_t id)
{
    const param_desc_t *d = param_desc_of(eng_idx(t->eng_req), id);
    int32_t r = d->max - d->min;
    return r > 0 ? (uint32_t)((clamp(t->p[id], d->min, d->max) - d->min) * 127 + r / 2) / (uint32_t)r : 0u;
}

static void __attribute__((noinline)) midi_cc_map(track_t *t, uint32_t cc, uint32_t value)
{
    uint32_t i, id = 0xFFFFu;
    if (midi_learned(cc, value))                /* (a learned CC is the user's: not the map's) */
        return;
    for (i = 0; i < NELEM(MIDI_CC_MAP); i++)
        if (MIDI_CC_MAP[i][0] == cc)
            id = MIDI_CC_MAP[i][1];
    if (id >= MCC_CUT) {
        if (id == 0xFFFFu)
            return;
        id = cc_eng_id(t, id == MCC_CUT);
        if (id >= P_COUNT)
            return;
    }
    midi_cc_set(t, id, value);
}

static void midi_control(uint32_t ch, uint32_t cc, uint32_t value)
{
    midi_channel_t *c = midi_channel(ch);
    uint32_t i, mask;
    switch (cc) {
    case 1:
        c->wheel = (uint8_t)value;
        break;
    case 120:                                      /* All Sound Off: ignores the pedal */
        mask = midi_targets(ch);
        for (i = 0; i < NTRK; i++)
            if (mask & (1u << i))
                midi_silence_track(i);
        break;
    case 123:                                      /* All Notes Off: normal releases, honours pedal */
        mask = midi_targets(ch);
        for (i = 0; i < 128u; i++)
            if (midi_notes[ch][i])
                midi_note_event(ch, i, 0);
        for (i = 0; i < NTRK; i++)
            if ((mask & (1u << i)) && !midi_track_held(i)) {
                trk_all_off(&trk[i]);
                trk[i].nheld = trk[i].arp_phys = trk[i].rh_n = 0;
                arp_forget(&trk[i]);
            }
        break;
    case 121:                                      /* Reset All Controllers, keep bend sensitivity */
        c->bend = 0;
        c->wheel = 0;
        c->rpn_msb = c->rpn_lsb = 127;
        midi_expression_channel(ch);
        midi_pedal_up(ch);
        break;
    case 64:
        if (value >= 64u)
            c->pedal = 1;
        else
            midi_pedal_up(ch);
        break;
    case 101: c->rpn_msb = (uint8_t)value; break;
    case 100: c->rpn_lsb = (uint8_t)value; break;
    case 99: case 98:                              /* NRPN selection cancels RPN data entry */
        c->rpn_msb = c->rpn_lsb = 127;
        break;
    case 6: case 38:
        if (!c->rpn_msb && !c->rpn_lsb) {           /* RPN 0: +/-0..24 semitones, 0..99 cents */
            if (cc == 6u)
                c->semis = (uint8_t)(value > 24u ? 24u : value);
            else
                c->cents = (uint8_t)(value > 99u ? 99u : value);
            midi_expression_channel(ch);
        }
        break;
    default:
        midi_cc_map(midi_track(ch), cc, value);
        break;
    }
}

/* MIDI IN CH1-6 listens to the channels the tracks are set to only. A switch to it from SEL, or a track's channel
 * changed ((1.3) T1..T6 CHANNEL; events_block, before the queue), lets go of what the other channels hold: their notes
 * released (also pedal-held ones), their pedal, bend, wheel and RPN selection reset, so no note can hang on a channel
 * that is no longer heard. Each part's bend then follows its own channel, as CH1-6 routes it. */
static void __attribute__((noinline)) midi_route_drop(void)
{
    uint32_t ch, note;
    for (ch = 0; ch < 16u; ch++) {
        midi_channel_t *c;
        if (midi_slot(ch) >= 0 || ch + 1u == mset_ch(MSET(1, 1) & 31u))   /* ((2.2) AUTO CHANNEL's: heard) */
            continue;
        c = midi_channel(ch);
        for (note = 0; note < 128u; note++)
            if (midi_notes[ch][note])
                midi_release(ch, note);
        c->pedal = c->wheel = 0;
        c->bend = 0;
        c->rpn_msb = c->rpn_lsb = 127;
    }
    for (ch = 0; ch < NPART; ch++)
        midi_expression(&trk[ch], midi_channel(trk_midi_ch(ch)));
}

/* Keep the occasional controller/panic dispatch outside the hot rendering loop. Channel voice messages only
 * (realtime and clock are handled in events_block, SysEx never reaches here). With MIDI IN CH1-6 the channels
 * no track is set to (7..16 unless (1.3) T1..T6 CHANNEL says) are ignored entirely: notes, bend, CCs (CC1/11/64, RPN,
 * and the CC120/121/123 panic and reset), channel aftertouch, so they stay free for other instruments. */
/* (Skiff 1.3, from Felucca 1.5.1, its #179 by renebohne) Program Change: the track the channel plays (MIDI IN as for
 * notes) takes program d1. Only noted here, 0x80 | d1 per track (a later one before the main loop wins): a sound load is
 * the main loop's work (undo, motion, FM6's patch), never the audio ISR's. ui.mpc (ui.c midi_pc_poll; a build without
 * the UI: none) */
static volatile uint8_t *const mpc_io;
/* (2.2) MENU > MIDI > REMOTE (channel 1..16, OFF): on its channel CC 102..115 press the panel's 14 buttons in the
 * order of their labels (panel.c B_FX .. B_OCTUP: Sloop's REMOTE map, so a controller's template for it works here),
 * 64 and up held down, below let go: the input's debounce takes them as the contacts (hal/fm1_input.h virt / vtap), so
 * taps, holds, layers and a button with a key act as on the panel. ui.c rmt_btn: panel.btn (a label's button).
 * (2.5) Its encoders, relative (two's complement: 1..63 that many clicks right, 127..65 left; 0, 64 nothing): CC
 * 116..119 KNOB 1..4, 85 ALGORITHM, 86 PRESETS, 87 SELECT (no CC of the MIDI spec's, Sloop's or the standard map's;
 * 120..127 are the channel's modes). The turns go where the panel's do (panel.c panel_enc, by role: ui.c rmt_enc_q), so
 * every page, acceleration and MIDI LEARN take them as a knob's */
static const uint8_t *const rmt_btn;
static volatile int16_t *const rmt_enc_q;

static void __attribute__((noinline)) midi_event(uint32_t st, uint32_t ch, uint32_t d1, uint32_t d2)
{
    if (st == 0xB0u && (d1 - 102u < 14u || d1 - 116u < 4u || d1 - 85u < 3u) && rmt_btn &&
        ch + 1u == mset_ch(MSET(15, 5) >> 3)) {
        if (d1 - 102u < 14u) {
            uint32_t bit = 1u << rmt_btn[d1 - 102u];
            if (d2 >= 64u) {
                fm1_in.virt |= bit;
                fm1_in.vtap ^= bit;
            } else
                fm1_in.virt &= ~bit;
        } else if (d2 && d2 != 64u && rmt_enc_q) {
            uint32_t r = d1 >= 116u ? 3u + d1 - 116u : d1 == 87u ? 0u : d1 - 84u;   /* (panel.c EN_*: ui.c checks) */
            rmt_enc_q[r] = (int16_t)(rmt_enc_q[r] + (d2 < 64u ? (int32_t)d2 : (int32_t)d2 - 128));
        }
        return;
    }
    if (!song.g[G_ROUTE] && midi_slot(ch) < 0 && ch + 1u != mset_ch(MSET(1, 1) & 31u))   /* (CH1-6: a channel no */
        return;                                    /* track is set to; (2.2) AUTO CHANNEL's plays the selected one) */
    mn.quiet = 1;                                  /* ((2.2) what MIDI IN plays is never sent back out: seq.c mo_note) */
    if (st == 0x90u || st == 0x80u)
        midi_note_event(ch, d1, st == 0x90u ? d2 : 0);
    else if (st == 0xE0u) {
        midi_channel(ch)->bend = (int16_t)((int32_t)(d1 | (d2 << 7)) - 8192);
        midi_expression_channel(ch);
    } else if (st == 0xB0u) {
        mod_midi(midi_track(ch), st, d1, d2);
        midi_control(ch, d1, d2);
    } else if (st == 0xD0u)
        mod_midi(midi_track(ch), st, d1, d2);
    else if (st == 0xC0u && mpc_io)                /* ((1.3) Program Change: the main loop loads it, ui.c) */
        mpc_io[trk_index(midi_track(ch))] = (uint8_t)(0x80u | d1);
    mn.quiet = 0;
}
