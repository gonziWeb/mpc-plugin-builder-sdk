/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Chord keys (SCL > CHORD: P_CHRD, P_VOIC): one key, MIDI note or arp input plays a chord. Included by seq.c
 * after kb_map; runs in the audio ISR with the rest of the note input.
 *   CHRD OFF; DIA3 / DIA7: the triad / seventh of the track's scale (ROOT, SCALE) built on the key, every tone
 *        in key (a key outside the scale takes the scale note below it, as QNT SNAP does; CHR builds on the
 *        major scale of ROOT); MAJ MIN DOM7 MAJ7 MIN7 SUS4 POW: that shape on the key, whatever the scale.
 *   VOIC CLOSE (root position); OPEN (the second tone an octave up: 1-5-3); INV1 / INV2 (the lowest tone, then
 *        the next, an octave up); +OCT (the root an octave down added; a seventh drops its fifth). At most
 *        CHORD_MAX notes, notes outside 0..127 left out.
 * The key is mapped first (kb_map: QNT SNAP / WHITE, TRN, the octave), the chord is built on the note it gives.
 * MONO / LEGATO / UNISON parts play the chord's root only; a kit (the DRUM engine, slices: an
 * engine that maps the keys itself) ignores CHRD. Every source keeps the notes it started (kb_chord for a
 * key, mchord for a MIDI note) and its release ends exactly those, so CHRD / VOIC changed while it is held
 * leave nothing hanging. A note several sources hold sounds once and ends with the last of them. */
enum { CH_OFF, CH_DIA3, CH_DIA7, CH_MAJ, CH_MIN, CH_DOM7, CH_MAJ7, CH_MIN7, CH_SUS4, CH_POW, CH_BUS };
enum { VC_CLOSE, VC_OPEN, VC_INV1, VC_INV2, VC_BASS };
#define CHORD_MAX 4u
#define MCHORD_N 24u                     /* MIDI notes held as chords at once (more: their root alone) */

static const int8_t CHORD_SHAPE[CH_POW - CH_MAJ + 1][CHORD_MAX] = {
    {0, 4, 7, -1}, {0, 3, 7, -1}, {0, 4, 7, 10}, {0, 4, 7, 11}, {0, 3, 7, 10}, {0, 5, 7, -1}, {0, 7, 12, -1},
};

static uint8_t kb_chord[27][CHORD_MAX], kb_chn[27];   /* the notes key k started (kb_chn 0: none) */
static uint8_t kb_midi[27][CHORD_MAX], kb_midin[27];  /* the notes key k last sent to MIDI OUT: retriggers move
                                                       * only the local list, so the external NoteOns stay matched */
static uint8_t kb_live[27];                            /* this press may still retrigger (panic clears it until re-press) */
typedef struct { uint8_t id, ch, src, n, note[CHORD_MAX]; } mchord_t;   /* id: track + 1, 0 = free */
static mchord_t mchord[MCHORD_N];
/* the last chord played per track (the CHORD page shows it): its root, notes, and the shape's tones above the
 * root (bit i = i semitones, 0..11) */
static struct { uint8_t root, key, n, note[CHORD_MAX]; uint16_t mask; uint8_t gen, vel; } chord_last[NTRK];
static uint8_t chord_live[NTRK];        /* an owner still holds the CHRD BUS chord: eligibility for retrigger */

/* 1 = the track's keys are a kit: no chords */
static int chord_kit(const track_t *t)
{
    const engine_t *e = ENGINES[eng_idx(t->eng_req)];
    return e->oneshot || (e->keys && e->keys(t, 0) >= 0);
}

/* the tones of the chord (semitones above *root, ascending, iv[0] = 0) -> their number; DIA may move *root
 * down onto the scale */
static uint32_t chord_tones(const track_t *t, uint32_t mode, int32_t *root, int32_t *iv)
{
    uint32_t n = 0, i;
    if (mode == CH_BUS) {
        uint16_t bm = harmony_mask(t), rel;
        if (bm) {                                     /* the HARMONIC BUS chord, at the octave nearest the key */
            int32_t br = (int32_t)harmony_live_desc(harmony_chord_at(harmony_bar), &rel);   /* effective root + relative tones */
            while (br + 12 <= *root + 6)
                br += 12;
            while (br > *root + 6)
                br -= 12;
            *root = br;
            iv[n++] = 0;
            for (i = 1; i < 12u && n < CHORD_MAX; i++)
                if ((rel >> i) & 1u)
                    iv[n++] = (int32_t)i;
            return n;
        }
        mode = CH_DIA3;                               /* bus off: the scale's triad, as DIA3 */
    }
    if (mode >= CH_MAJ) {
        for (i = 0; i < CHORD_MAX && CHORD_SHAPE[mode - CH_MAJ][i] >= 0; i++)
            iv[n++] = CHORD_SHAPE[mode - CH_MAJ][i];
        return n;
    }
    {
        uint32_t mask = scale_mask(t), deg[12], c = 0, at = 0, guard = 12;
        int32_t r = t->p[P_ROOT];
        if (mask == 0xFFFu)
            mask = SCALE_MASK[1];                       /* CHR: no key of its own, the major scale of ROOT */
        while (guard-- && !((mask >> (uint32_t)((*root - r + 120) % 12)) & 1u))
            (*root)--;                                  /* outside the scale: the scale note below */
        for (i = 0; i < 12u; i++)
            if ((mask >> i) & 1u) {
                if (i == (uint32_t)((*root - r + 120) % 12))
                    at = c;
                deg[c++] = i;
            }
        for (i = 0; i < (mode == CH_DIA7 ? 4u : 3u); i++) {   /* every other note of the scale */
            uint32_t k = at + 2u * i;
            iv[n++] = (int32_t)deg[k % c] + 12 * (int32_t)(k / c) - (int32_t)deg[at];
        }
        return n;
    }
}

/* the chord on note `root` as track t plays it now -> out (ascending), the number of notes (1..CHORD_MAX);
 * *rp its root, *maskp its tones above the root (bit i: i semitones; 0 = no chord). The root alone when CHRD
 * is OFF, on a kit, or for MONO / LEGATO / UNISON (their chord's root) */
static uint32_t chord_make(const track_t *t, uint32_t root, uint8_t *out, int32_t *rp, uint16_t *maskp)
{
    int32_t iv[CHORD_MAX + 1u], r = (int32_t)root, x;
    uint32_t mode = (uint32_t)t->p[P_CHRD], n, i, j, m = 0;
    uint16_t mask = 0;
    *rp = r;
    *maskp = 0;
    if (!mode || mode > CH_BUS || chord_kit(t)) {
        out[0] = (uint8_t)root;
        return 1;
    }
    n = chord_tones(t, mode, &r, iv);
    for (i = 0; i < n; i++)
        mask |= (uint16_t)(1u << (iv[i] % 12));
    *rp = r;
    *maskp = mask;
    if (trk_vmode(t) != V_POLY) {                       /* one voice: the root */
        out[0] = (uint8_t)clamp(r, 0, 127);
        return 1;
    }
    switch (t->p[P_VOIC]) {
    case VC_OPEN:                                       /* 1-5-3(-7): the second tone an octave up */
        if (n >= 3u)
            iv[1] += 12;
        break;
    case VC_INV2:
    case VC_INV1:
        for (j = 0; j < (t->p[P_VOIC] == VC_INV2 ? 2u : 1u); j++) {   /* the lowest tone an octave up */
            x = iv[0] + 12;
            for (i = 1; i < n; i++)
                iv[i - 1u] = iv[i];
            iv[n - 1u] = x;
        }
        break;
    case VC_BASS:                                       /* the root an octave down; a seventh drops its fifth */
        if (n == CHORD_MAX) {
            iv[2] = iv[3];
            n--;
        }
        for (i = n; i > 0; i--)
            iv[i] = iv[i - 1u];
        iv[0] = -12;
        n++;
        break;
    default:
        break;
    }
    for (i = 1; i < n; i++)                             /* ascending */
        for (j = i; j > 0 && iv[j - 1u] > iv[j]; j--) {
            x = iv[j];
            iv[j] = iv[j - 1u];
            iv[j - 1u] = x;
        }
    for (i = 0; i < n && m < CHORD_MAX; i++) {          /* inside 0..127, each note once */
        x = r + iv[i];
        if (x < 0 || x > 127 || (m && out[m - 1u] == (uint8_t)x))
            continue;
        out[m++] = (uint8_t)x;
    }
    if (!m) {
        out[0] = (uint8_t)clamp(r, 0, 127);
        return 1;
    }
    return m;
}

/* chord_make for a note played now: a chord is kept in chord_last (the CHORD page shows it) */
static void latch_bus_capture(track_t *t);
static int latch_would_toggle(const track_t *t, const uint8_t *nn, uint32_t n);
static uint32_t chord_build(track_t *t, uint32_t root, uint8_t *out)
{
    int32_t r;
    uint16_t mask;
    uint32_t m = chord_make(t, root, out, &r, &mask), i, k = trk_index(t);
    if (m > 1u && !latch_would_toggle(t, out, m)) {      /* (a LATCH STACK toggle starts no new chord: chord_last stays) */
        latch_bus_capture(t);
        chord_last[k].root = (uint8_t)clamp(r, 0, 127);
        chord_last[k].key = (uint8_t)clamp((int32_t)root, 0, 127);
        chord_last[k].mask = mask;
        chord_last[k].n = (uint8_t)m;
        chord_last[k].vel = (uint8_t)(kb_vel ? kb_vel : 96u);
        for (i = 0; i < CHORD_MAX; i++)
            chord_last[k].note[i] = i < m ? out[i] : 0u;
        chord_last[k].gen++;
        if (t->p[P_CHRD] == CH_BUS)
            chord_live[k] = 1;
    }
    return m;
}

/* a chord's name from its root and tones (bit i: i semitones above the root): "C", "Cm7", "F#m7b5", "Gsus4",
 * "A5" -> b (12 bytes) */
static void chord_name(char *b, uint32_t root, uint32_t mask)
{
    uint32_t mi = (mask >> 3) & 1u, ma = (mask >> 4) & 1u, b5 = (mask >> 6) & 1u, p5 = (mask >> 7) & 1u;
    uint32_t s5 = (mask >> 8) & 1u, d7 = (mask >> 9) & 1u, m7 = (mask >> 10) & 1u, M7 = (mask >> 11) & 1u;
    const char *q, *x = "";
    str_cpy(b, N_NOTE[root % 12u], 12);
    if (mi && !ma && b5 && !p5)
        q = d7 ? "dim7" : m7 ? "m7b5" : "dim";
    else if (ma && !mi && s5 && !p5)
        q = m7 ? "+7" : M7 ? "+M7" : "aug";
    else if (ma && !mi)
        q = m7 ? "7" : M7 ? "maj7" : d7 ? "6" : "";
    else if (mi)
        q = m7 ? "m7" : M7 ? "mM7" : d7 ? "m6" : "m";
    else if ((mask >> 5) & 1u) {                        /* no third: suspended */
        q = m7 ? "7" : "";
        x = "sus4";
    } else if ((mask >> 2) & 1u) {
        q = m7 ? "7" : "";
        x = "sus2";
    } else
        q = "5";
    str_cpy(b + str_len(b), q, 12 - str_len(b));
    str_cpy(b + str_len(b), x, 12 - str_len(b));
}

/* the MIDI note (ch, src) of track id - 1 that plays a chord, 0 = none */
static mchord_t *mchord_of(uint32_t ch, uint32_t src, uint32_t id)
{
    uint32_t i;
    for (i = 0; i < MCHORD_N; i++)
        if (mchord[i].id == id && mchord[i].ch == ch && mchord[i].src == src)
            return &mchord[i];
    return 0;
}

/* a MIDI-held chord of track id - 1 sounds note */
static int mchord_held(uint32_t id, uint32_t note)
{
    uint32_t i, j;
    for (i = 0; i < MCHORD_N; i++)
        if (mchord[i].id == id)
            for (j = 0; j < mchord[i].n; j++)
                if (mchord[i].note[j] == note)
                    return 1;
    return 0;
}

static void mchord_forget(uint32_t track)               /* panic: the track's MIDI chords are gone */
{
    uint32_t i;
    for (i = 0; i < MCHORD_N; i++)
        if (mchord[i].id == track + 1u)
            mchord[i].id = 0;
}


/* STOP/panic: a bus chord started or retriggered by the HARMONY engine is not in the key/sequence owner lists;
 * release it explicitly so no tone can hang. */
static int chord_plain_owned(uint32_t i, uint32_t note)   /* a key or MIDI chord of the track still lists the note */
{
    uint32_t k, m, j;
    for (k = 0; k < 27u; k++)
        if (kb_chn[k] && kb_trk[k] == i)
            for (j = 0; j < kb_chn[k]; j++)
                if (kb_chord[k][j] == note)
                    return 1;
    for (m = 0; m < MCHORD_N; m++)
        if (mchord[m].id == i + 1u)
            for (j = 0; j < mchord[m].n; j++)
                if (mchord[m].note[j] == note)
                    return 1;
    return 0;
}
static void chord_panic(uint32_t i);
static uint32_t lat_eat[NTRK][4];       /* (seq.c: bit n = the press of note n ended it; declared here for chord_stop_all) */
static void chord_stop_all(void)
{
    uint32_t i, j;
    for (i = 0; i < NTRK; i++) {
        uint32_t bus = trk[i].p[P_CHRD] == CH_BUS;
        if (!bus && !chord_live[i] && !chord_last[i].n)
            continue;                                 /* round 7: a CHRD BUS chord is the engine's: it ends; a plain chord a player still holds (a key or MIDI list names the note) sounds on, as in 0.11.0; a note of the last chord nobody holds any more (an orphan) still ends, so STOP cleans up as before */
        for (j = 0; j < chord_last[i].n; j++)
            if (chord_last[i].note[j] && (bus || !chord_plain_owned(i, chord_last[i].note[j])))
                trk_note_off(&trk[i], chord_last[i].note[j]);
        if (bus) {
            chord_last[i].n = 0;
            memset(lat_eat[i], 0, sizeof lat_eat[i]);   /* (a kept key's 'this press ended it' mark: its release is no longer a live one) */
            chord_panic(i);
        }
    }
}

/* HARMONY / LINK RETRIG: the last CHRD BUS chord of the track is released and sounded again with the bus' new
 * chord / the linked scale. Per track; only CHRD BUS has a held chord to follow (the sequencer and ARP retrigger
 * their own steps anyway). */
static void retrigger_latched(uint32_t i);
static void retrigger_owners(uint32_t i, const uint8_t *old, uint32_t oldn, const uint8_t *new, uint32_t newn);
static void chord_live_sync(uint32_t i);
static void chord_panic(uint32_t i);
static int chord_owner_matches(uint32_t i, const uint8_t *old, uint32_t oldn);
static int chord_owner_fallback(uint32_t i, uint32_t *src, uint8_t *old, uint32_t *oldn);
static int chord_note_held(uint32_t i, uint32_t note);
static void link_retrigger(uint32_t i)
{
    track_t *t = &trk[i];
    if (t->p[P_AMODE])
        return;                                        /* round 7: with the ARP on, the held list is the ARP's and it follows HARMONY on every step; rewriting the key's chord would leave the old notes in that list (an arpeggio that outlives its key) */
    uint32_t k = trk_index(t), j, nn = 0, oldn = chord_last[k].n, src = chord_last[k].key;
    uint8_t out[CHORD_MAX], old[CHORD_MAX];
    int32_t r = 0;
    uint16_t mask = 0;
    for (j = 0; j < oldn; j++)
        old[j] = chord_last[k].note[j];
    if (!chord_live[k] || !chord_owner_matches(k, old, oldn)) {
        if (!chord_owner_fallback(k, &src, old, &oldn)) {   /* no real owner: no resurrection */
            chord_live[k] = 0;
            retrigger_latched(i);
            return;
        }
        chord_live[k] = 1;
    }
    if (t->p[P_CHRD] != CH_BUS || !oldn) {
        retrigger_latched(i);                          /* LATCH without CHRD BUS */
        return;
    }
    /* Rebuild the bus chord for the new harmony chord; reusing the old chord_last notes would repeat the old
     * root/fifth and never sound the new third. */
    nn = chord_make(t, src, out, &r, &mask);
    chord_last[k].key = (uint8_t)clamp((int32_t)src, 0, 127);
    /* Move this chord's owners first. Other voicings may still own one of its old pitches. */
    retrigger_owners(i, old, oldn, out, nn);
    for (j = 0; j < oldn; j++)
        if (!chord_note_held(k, old[j]))
            trk_note_off(t, old[j]);
    chord_last[k].n = (uint8_t)nn;
    chord_last[k].root = (uint8_t)clamp(r, 0, 127);
    chord_last[k].mask = mask;
    for (j = 0; j < CHORD_MAX; j++)
        chord_last[k].note[j] = j < nn ? out[j] : 0u;
    for (j = 0; j < nn; j++)
        if (out[j])
            trk_note_on(t, out[j], chord_last[k].vel ? chord_last[k].vel : 96u);
}
