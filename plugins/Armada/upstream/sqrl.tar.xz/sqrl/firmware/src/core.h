/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA core types: tracks, voices, engines, parameters.
 * Four tracks, each a synth part: its own engine, preset, parameters, voices and 64-step
 * pattern. The parts share one budget of NVOICE sounding voices (voice.c). Drums are the DRUM
 * engine (General MIDI map) on any part; the SAMPLE engine's PERC set is retired (drum_from_perc).
 * Sections: sizes, parameters, voices and engines, tracks and the song, system. */
#include <stdint.h>

/* ------------------------------------------------------------ sizes --- */
#define NVOICE 8                 /* voices per part, and the budget shared by all parts */
#define NPART 4                  /* synth parts: tracks 1..4 */
#define NTRK NPART               /* tracks (the formats and the protocol count these): every track is a part */
#define NSTEP 64
#define HALF_FRAMES 128          /* I2S half buffer: 2.9 ms at 44.1 kHz (a key waits 0..1 half, then plays 1 half later) */

#ifndef FELUCCA_TALK
#define FELUCCA_TALK 0           /* the TALK engine (eng_talk.c), engine 15: left out, as no word banks cleared for
                                  * distribution exist; FELUCCA_TALK=1 builds it with banks of your own in
                                  * firmware/src/banks/, which this repository does not carry */
#endif
#ifndef FELUCCA_SHELL
#define FELUCCA_SHELL 0          /* the SQRL-1 shell (shell.c): modes, the wheel and its grammar in place of the stock UI loop
                                  * (main.c); 0 = Felucca's UI */
#endif
#ifndef FELUCCA_FM4
#define FELUCCA_FM4 0            /* the DIGITAL engine (eng_digital.c, four-operator FM): kept in the tree, not built
                                  * by default; replaced by FM6, its sounds convert (fm4_convert.c) */
#endif
#ifndef FELUCCA_WHEEL
#define FELUCCA_WHEEL (!FELUCCA_SHELL)   /* the WHEEL engine (eng_wheel.c), engine 7, Felucca's drawbar organ: SQRL-1 leaves
                                  * it out (ORGAN covers it, for its flash and 3.3 KB of RAM); its sounds load as ORGAN */
#endif
/* SQRL-1's sounds are the wheel's eight (FM6 LIZARD SHOCK DRUMS MOUTH ANALOG PHASE PHYS): the other engines stay in
 * the tree, each behind its flag (=1 builds it back), as WHEEL is. A sound on one that is not built plays on its
 * sibling (shell.c sh_eng_sibling). Stock Felucca builds them all; ORGAN and LOOP are SQRL-1's own */
#ifndef FELUCCA_SLICE
#define FELUCCA_SLICE (!FELUCCA_SHELL)   /* the SLICE engine (eng_slice.c), engine 13; FELUCCA_SLICE=0 builds without it
                                  * (tools/gen_samples.py leaves its BREAK out then) */
#endif
#ifndef FELUCCA_PHASE
#define FELUCCA_PHASE 1          /* SQRL-1 too: PHASE is B4's SOUND, where SAMPLE was */
#endif
#ifndef FELUCCA_SAMPLE
#define FELUCCA_SAMPLE (!FELUCCA_SHELL)   /* the SAMPLE engine (eng_sample.c), engine 4: SQRL-1 leaves it out, and its sets'
                                  * ADPCM with it (tools/gen_samples.py); its sounds play on PHYS. The sample slots'
                                  * code stays, for GRAIN and SLICE when they are built */
#endif
#ifndef FELUCCA_LOFI
#define FELUCCA_LOFI (!FELUCCA_SHELL)
#endif
#ifndef FELUCCA_VOICE
#define FELUCCA_VOICE (!FELUCCA_SHELL)   /* (eng_formant.c) */
#endif
#ifndef FELUCCA_TRIO
#define FELUCCA_TRIO (!FELUCCA_SHELL)
#endif
#ifndef FELUCCA_GRAIN
#define FELUCCA_GRAIN (!FELUCCA_SHELL)
#endif
#ifndef FELUCCA_NOISE
#define FELUCCA_NOISE (!FELUCCA_SHELL)
#endif
#ifndef FELUCCA_SYLLABLE
#define FELUCCA_SYLLABLE (!FELUCCA_SHELL)   /* (the engine: MOUTH sings on syllable.c either way) */
#endif
#ifndef FELUCCA_VODER
#define FELUCCA_VODER (!FELUCCA_SHELL)
#endif
#ifndef FELUCCA_ORGAN
#define FELUCCA_ORGAN 0          /* (FELUCCA_SHELL builds only) */
#endif
#ifndef FELUCCA_LOOP
#define FELUCCA_LOOP 0           /* (FELUCCA_SHELL builds only) */
#endif
/* SQRL-1 without SAMPLE, GRAIN and SLICE has no user samples, so their flash (0xA0000..0xDBFFF) holds each project's
 * companion instead (project.c PROJ_CMP: the takes parked off their parts, the NOTE records, the SOUND snapshots). A
 * build with any of the three keeps the samples there and has no companion: nothing writes over a sample */
#ifndef FELUCCA_CMP
#define FELUCCA_CMP (FELUCCA_SHELL && !FELUCCA_SAMPLE && !FELUCCA_GRAIN && !FELUCCA_SLICE)
#endif
#define FELUCCA_NCUT (!FELUCCA_FM4 + !FELUCCA_SLICE + !FELUCCA_TALK + !FELUCCA_WHEEL + !FELUCCA_PHASE + !FELUCCA_LOFI + \
                      !FELUCCA_VOICE + !FELUCCA_TRIO + !FELUCCA_GRAIN + !FELUCCA_NOISE + !FELUCCA_SYLLABLE + \
                      !FELUCCA_VODER + !FELUCCA_SAMPLE + FELUCCA_SHELL * (!FELUCCA_ORGAN + !FELUCCA_LOOP))   /* the reserved numbers */
#define NENGINES (19u + 3u * FELUCCA_SHELL)   /* SLICE keeps 13 (reserved when not built); then LIZARD 14,
                                  * the speech engines TALK 15, SYLLABLE 16, VODER 17 (from databurn, MIT), SHOCK 18 and,
                                  * in SQRL-1 only, ORGAN 19, MOUTH 20 (from databurn, MIT) and LOOP 21. Stores hold the numbers: append, never
                                  * reorder */
#define ENGI_SLICE 13u
#define ENGI_LIZARD 14u
#define ENGI_TALK 15u
#define ENGI_SYLLABLE 16u
#define ENGI_VODER 17u
#define ENGI_SHOCK 18u
#define ENGI_ORGAN 19u           /* (FELUCCA_SHELL builds) */
#define ENGI_MOUTH 20u           /* (FELUCCA_SHELL builds) */
#define ENGI_LOOP 21u            /* (FELUCCA_SHELL builds) */
#ifndef FELUCCA_CPU2
#define FELUCCA_CPU2 1           /* the second core (src/felucca.c): 1 = built in, SYSTEM's 2ND CORE ON lets it render
                                  * some parts; 0 = none of it */
#endif
#define C1_NP (FELUCCA_CPU2 ? NPART : 1)   /* the copies of the state a part's render writes that parts shared before the
                                            * second core (mod.c, voice.c SPREAD, eng_formant.c): one each with two cores,
                                            * one for all with one, as up to 1.6 */
#define C1_PI(t) ((uint32_t)((t) - trk) % C1_NP)   /* a part's copy */
#ifndef FELUCCA_ADPCM
#define FELUCCA_ADPCM 0          /* Felucca 1.8's ADPCM engine (eng_adpcm.c) is its engine 14, LIZARD's number here: not
                                  * built (it is too heavy for the FM-1 anyway) */
#endif
#if FELUCCA_ADPCM
#error "FELUCCA_ADPCM: engine 14 is LIZARD in this tree"
#endif
#define ENGI_DIGITAL 1u          /* reserved without FELUCCA_FM4: never selectable (eng_ok), its sounds load as FM6 */
#define ENGI_WHEEL 7u            /* reserved without FELUCCA_WHEEL: never selectable, its sounds load as ORGAN */
#define NENG_SHOWN (NENGINES - FELUCCA_NCUT)   /* the engines one can pick: PRESETS, the EDIT layer, the editor,
                                                * in the display order of engines.c ENGINE_ORDER */
#define UP_SLOTS 32u             /* user presets (upreset.c) */

/* ------------------------------------------------------- parameters --- */
/* the engine interface (Felucca-Engines, MIT: engines/, a git submodule): param_desc_t and F_*, voice_t,
 * vmod_t, preset_t with FX() / PAT(), engine_t, NELEM */
#include "../engines/src/felucca_engine.h"

enum {                          /* per-track parameters */
    P_LEVEL,
    P_ATK, P_DEC, P_SUS, P_REL,
    P_ED_FLT, P_ED_PIT, P_ED_SHP, P_ED_FX,     /* P_ED_FX: unused, kept for the formats / protocol */
    P_LRATE, P_LWAVE, P_LPHASE, P_LFADE,
    P_LD_PIT, P_LD_FLT, P_LD_SHP, P_LD_AMP,
    P_AMODE, P_ARATE, P_AOCT, P_AGATE,
    P_ASWING, P_APROB, P_AHOLD, P_AORDER,
    P_ROOT, P_SCALE, P_QUANT, P_TRANS,
    P_SLEN, P_SDIV, P_SSWING, P_SGATE,
    P_DIST, P_CHOR, P_DLY, P_REV,
    P_VOICE, P_GLIDE, P_PAN, P_MUTE,
    P_GLMODE, P_PRIO, P_ALLOC, P_DETUNE,
    P_SLCR, P_SLPAT, P_SLRATE, P_SLDEPTH,      /* SLICER insert (slicer.c) */
    P_M1SRC, P_M1DST, P_M1AMT,                 /* modulation matrix (mod.c): 4 slots of SRC, DST, AMT; */
    P_M2SRC, P_M2DST, P_M2AMT,                 /* new common parameters go just before P_E0 (user presets */
    P_M3SRC, P_M3DST, P_M3AMT,                 /* and projects map by count) */
    P_M4SRC, P_M4DST, P_M4AMT,
    P_FM1_ATK, P_FM1_DEC, P_FM1_SUS, P_FM1_REL, P_FM1_LEVEL,
    P_FM2_ATK, P_FM2_DEC, P_FM2_SUS, P_FM2_REL, P_FM2_LEVEL,
    P_FM3_ATK, P_FM3_DEC, P_FM3_SUS, P_FM3_REL, P_FM3_LEVEL,
    P_FM4_ATK, P_FM4_DEC, P_FM4_SUS, P_FM4_REL, P_FM4_LEVEL,
    P_CHRD, P_VOIC,                            /* chord keys (chord.c): one key plays a chord; its voicing */
    P_LN0, P_LN1, P_LN2, P_LN3, P_LN4, P_LN5, P_LN6, P_LN7,   /* DRUM lane levels (eng_drum.c, #97): KICK .. BELL */
    P_LSYNC, P_LTRIG, P_LPOL,                  /* 1.2 (#154): LFO SYNC (OFF, a note value), TRIG (NOTE, FREE), POL (BI, UNI) */
    P_SQNT,                                    /* 1.2 (#162): QUANTIZE, the steps' recorded / nudged timing (ON: none) */
    P_SPRD,                                    /* (#148): SPREAD, the voices of a POLY / UNISON track around PAN (fx.c) */
    P_ITYPE, P_IA, P_IB, P_IC, P_IMIX,         /* 1.5 (#78, #177): the INSERT, its TYPE, three values and MIX (fx.c) */
    P_FTYPE,                                   /* 1.5 (#104): ANALOG's filter TYPE, LP (as before) / BP / HP (eng_analog.c) */
    P_ESYNC,                                   /* 1.5 (#175): ENV SYNC: ATK DEC REL as note values of the tempo (voice.c) */
#if FELUCCA_SHELL                              /* the SQRL-1 shell (P_COUNT 127; stores of 111 map by count, as above) */
    P_LZUSER, P_LZWAT,                         /* LIZARD's own drawing in force, and the WAVE it was drawn on */
    P_LZD0, P_LZD1, P_LZD2, P_LZD3, P_LZD4, P_LZD5, P_LZD6, P_LZD7,   /* its eight levels (eng_lizard.c) */
    P_LZUNI, P_LZWARP,                         /* LIZARD's SHAPE: the drawing's unison and WARP (lzshape.c) */
    P_FOLD, P_SYM, P_CRUSH, P_DOWN,            /* every engine's SHAPE stage (lzshape.c; voice.c, shell.c) */
#endif
#if !FELUCCA_SHELL
    P_ATSNS, P_ATDST, P_ATAMT,                 /* 1.8: AFTERTOUCH: the keys' pressure (keytouch.c) and its routing (mod.c) */
#endif
    P_E0, P_E1, P_E2, P_E3, P_E4, P_E5, P_E6, P_E7,
    P_COUNT
};

#if FELUCCA_SHELL && !FELUCCA_FM4
/* GLIDE SPREAD and ORDER (voice.c glide_set) on two of DIGITAL's inert OP ENV ids: without FELUCCA_FM4 they are
 * on no stock page and fm4_convert sets them to 0 (their defaults) when a DIGITAL sound converts, so no old sound
 * brings a value. They keep the OP ENV ids' rules: settings, never motion. (A sound saved here and loaded into a
 * FELUCCA_FM4 build reads them as OP4's ATK and DEC: a known edge, not a path this build offers) */
#define P_GSPR P_FM4_ATK
#define P_GORD P_FM4_DEC
#endif
#if FELUCCA_SHELL
/* Felucca 1.8's AFTERTOUCH (SENS, DEST, AMT) on three more of DIGITAL's inert ids, OP3's ATK DEC REL (0 by default and
 * after any DIGITAL conversion, fm4_convert.c): new ids would take P_COUNT past 127, the editor's 7-bit count, and move
 * P_E0, which every stored SQRL-1 sound and project holds its engine values after. An old project brings 0: OFF */
#define P_ATSNS P_FM3_ATK
#define P_ATDST P_FM3_DEC
#define P_ATAMT P_FM3_REL
#endif

enum {                          /* global parameters */
    G_BPM, G_SWING, G_CLOCK, G_TUNE,
    G_DTIME, G_DFDBK, G_DCOLOR, G_DMIX,
    G_RSIZE, G_RDAMP, G_CRATE, G_CDEPTH,
    G_MIDI, G_SYNC, G_ROUTE, G_INFO,   /* G_ROUTE: MIDI IN, 0 CH1-4 (channels 1..4 -> parts 1..4, 5..16 ignored), 1 SEL;
                                        * 1.2: 2..4 CH5-8 CH9-12 CH13-16 (seq.c midi_base); 1.5.5: 5 TRACK (song.mch) */
    G_SLOT, G_NAME, G_LOAD, G_SAVE,
    G_ENGSEL, G_ENGGO,          /* no page: the editor switches the engine with a SET of G_ENGSEL; G_ENGGO is
                                 * unused (ids are fixed by the formats and the protocol) */
    G_CLRSEQ, G_INITSND,
    G_RTYPE,                    /* REVERB TYPE: 0 ROOM, 1 SPRING, 2 HALL (1.2, the power-on default) (fx.c). Was
                                 * G_DRCH, the GM drum part's MIDI channel (inert since 1.0, never read); projects
                                 * of formats before FUN7 load it as ROOM (project.c proj_rtype_room) */
    G_DRLVL, G_DRREV,           /* inert (label "-", on no page): the GM drum part they set is gone; kept
                                 * because the ids and G_COUNT are fixed by the formats and the protocol (only
                                 * the import of an old project reads them: proj_drums_to_part) */
    G_COUNT
};
#if FELUCCA_SHELL
/* the tape echo's (fx.c, tapedly.c) on the three inert ids: in a project, the song's own. project.c clears G_DRLVL and
 * G_DRREV after an old format's drum part has read them */
#define G_TDHEADS G_ENGGO       /* HEADS 1 2 3 1+2 2+3 1+3 ALL */
#define G_TDREV G_DRLVL         /* REV FWD REV ALT */
#define G_TDSAT G_DRREV         /* SAT 0..127 */
#endif

/* stored parameters of an older layout -> today's P_* order. A store keeps np = the P_COUNT it was
 * written with; common parameters are only ever added just before P_E0, so the first np - 8 are
 * P_LEVEL.. in order and the last 8 are P_E0..P_E7; the parameters a store does not have take def[]
 * (user presets, projects of formats 1 and 2) */
static void params_by_count(int16_t *out, const int16_t *in, uint32_t np, const int16_t *def)
{
    uint32_t i, nc = np - 8u;
    for (i = 0; i < P_E0; i++)
        out[i] = i < nc ? in[i] : def[i];
    for (i = 0; i < 8u; i++)
        out[P_E0 + i] = in[nc + i];
}

/* engine indices the stores name (engines.c ENGINES[]: append-only) */
#define ENGI_PHYS 9u
#define ENGI_DRUM 10u
/* PHYS MODEL DRUM (MODEL 4, before 1.0) -> the DRUM engine, its E values in place: {MODEL, TUNE, TONE, DECY,
 * SNAP, ACC, KICK 0..127, PERC 0..127} -> {KIT, TUNE, TONE, DECY, SNAP, ACC, KICK 0..1, DRV 0}. 1 = it was one
 * (its engine is ENGI_DRUM now); projects (project.c) and user presets (upreset.c) */
static int drum_from_phys(uint32_t engine, int16_t *e)
{
    if (engine != ENGI_PHYS || e[0] != 4)
        return 0;
    e[0] = (int16_t)((e[7] < 0 ? 0 : e[7] > 127 ? 127 : e[7]) >> 5);   /* PERC -> KIT: STD HAND CYM H+CYM */
    e[6] = (int16_t)(e[6] >= 64);                                       /* KICK: PUNCH, ROUND */
    e[7] = 0;
    return 1;
}

/* SAMPLE SET 4 was PERC, the GM-mapped drum kit (tools/gen_samples.py); retired after 1.0.2: its index stays
 * (SET / GRAIN SRC 4 is an alias of PIANO, USR1..3 keep 5..7). A sound that selected it is the DRUM engine with
 * its default kit (eng_drum.c DRUM_PRESETS[0]: the same GM key map, so its patterns still play as drums): its E
 * values become the kit's, the rest of the sound (mix, sends, matrix, ..) stays. 1 = it was one (its engine is
 * ENGI_DRUM now); projects (project.c proj_perc), user presets (upreset.c up_migrate), factory preset 4 and
 * favourites (ui.c, settings_persist.c). Idempotent */
#define ENGI_SAMPLE 4u
#define SMP_SET_PERC 4u
#define DRUM_KIT_E {0, 64, 70, 64, 64, 100, 0, 0}   /* {KIT STD, TUNE, TONE, DECY, SNAP, ACC, KICK PUNCH, DRV} */
static int drum_from_perc(uint32_t engine, int16_t *e)
{
    static const int16_t KIT[8] = DRUM_KIT_E;
    uint32_t i;
    if (engine != ENGI_SAMPLE || e[0] != (int16_t)SMP_SET_PERC)
        return 0;
    for (i = 0; i < 8u; i++)
        e[i] = KIT[i];
    return 1;
}

/* ------------------------------------------------- voices, engines --- */
enum { V_POLY, V_MONO, V_LEGATO, V_UNISON };   /* P_VOICE */
/* voice_t, vmod_t, preset_t, engine_t: felucca_engine.h (above) */

/* ------------------------------------------------- tracks, the song --- */
enum { ST_NOTE, ST_TIE, ST_REST };
#define SF_ACCENT 1u
#define SF_SLIDE 2u
#define SF_RATCH_SH 3u                   /* RATCH: the hits of a NOTE step - 1 (0..3: x1..x4, seq.c seq_ratchet); */
#define SF_RATCH (3u << SF_RATCH_SH)     /* bits 3..4, so a user preset's pattern (flag 4 = tie) carries it too */
#define NLANE 8                  /* drum lanes of a step (the DRUM engine's: eng_drum.c DRUM_LANE_NOTE) */
#define SH_LANES_N 107u          /* SQRL-1: a lanes engine's settings as stored (shell.c sh_lanes_get): LEN FILL ROT
                                  * NOTE [8] each, OCT, DIV [8], TRN + 12, STYLE (LINES'), LANE 2's PAD LOOP WAKE - 1
                                  * NAP [8] each, LOOP's seeds [8] (4 bytes each) */
#define P11_HARM_N 44u           /* SQRL-1: HARMONY as stored, 4 bytes for each of the 11 NOTE engines (shell.c
                                  * sh_harm_get) */
#if FELUCCA_SHELL
#define STEP_NOTES 6u            /* a step's notes: SQRL-1 records a chord of six (FUN11) */
#else
#define STEP_NOTES 4u
#endif
typedef struct {                 /* acid-style step: up to STEP_NOTES notes (POLY), time, accent, slide; drum hits */
    uint8_t note[STEP_NOTES];
    uint8_t n;                   /* notes in use, 0 = empty */
    uint8_t time;                /* ST_NOTE / ST_TIE / ST_REST */
    uint8_t flags;               /* SF_ACCENT | SF_SLIDE | SF_RATCH */
    uint8_t vel;
    uint8_t hit;                 /* bit l: lane l hits (its GM note, on any engine): the DRUM grid */
    uint8_t acc;                 /* bit l: that hit is accented (velocity 127) */
    uint8_t probability;         /* 0 = legacy 100%; 1..100 = percent, 101 = silent; 1.5.5: 102..112 a condition */
#if FELUCCA_SHELL
    uint8_t just[3];             /* each note's TUNE JUST offset (voice.c voice_just), 1/16 semitone, signed 4 bits:
                                  * note j in nibble j & 1 of byte j >> 1 (step_just, step_set_just) */
#endif
} step_t;
#if FELUCCA_SHELL
_Static_assert(sizeof(step_t) == 16u, "step_t: SQRL-1's 16 bytes");
static inline int32_t step_just(const step_t *s, uint32_t j)
{
    int32_t v = (s->just[j >> 1] >> ((j & 1u) * 4u)) & 15;
    return v >= 8 ? v - 16 : v;
}
static inline void step_set_just(step_t *s, uint32_t j, int32_t v)
{
    uint32_t sh = (j & 1u) * 4u;
    v = v < -8 ? -8 : v > 7 ? 7 : v;
    s->just[j >> 1] = (uint8_t)((s->just[j >> 1] & ~(15u << sh)) | ((uint32_t)v & 15u) << sh);
}
static inline void step_just_clear(step_t *s) { s->just[0] = s->just[1] = s->just[2] = 0; }
/* a lanes step's octave for each hit (LINES' octave pages, shell.c sh_lopg): lane l's 3 bits of just[] from bit 3 l,
 * signed (-4..3). A lanes engine's step plays no TUNE JUST: its just[] is its hits' octaves */
static inline uint32_t step_lo_w(const step_t *s) { return s->just[0] | (uint32_t)s->just[1] << 8 | (uint32_t)s->just[2] << 16; }
static inline int32_t step_loct(const step_t *s, uint32_t l)
{
    uint32_t v = (step_lo_w(s) >> (3u * (l & 7u))) & 7u;
    return v >= 4u ? (int32_t)v - 8 : (int32_t)v;
}
static inline void step_set_loct(step_t *s, uint32_t l, int32_t o)
{
    uint32_t w = step_lo_w(s), sh = 3u * (l & 7u);
    o = o < -4 ? -4 : o > 3 ? 3 : o;
    w = (w & ~(7u << sh)) | ((uint32_t)o & 7u) << sh;
    s->just[0] = (uint8_t)w;
    s->just[1] = (uint8_t)(w >> 8);
    s->just[2] = (uint8_t)(w >> 16);
}
#else
#define step_just(s, j) 0
#define step_set_just(s, j, v) ((void)0)
#define step_just_clear(s) ((void)0)
#endif
typedef struct {                 /* a step as formats 1..4 (projects to FUN4) stored it: no hits */
    uint8_t note[4];
    uint8_t n, time, flags, vel;
} step8_t;

/* Probability keeps zero-initialized and legacy patterns at 100%. */
/* 1.5.5 (#209): CONDITIONS, in the chance byte's free values (no format change): COND_FIRST + c - 1 is condition c
 * (1..NCOND): a:b (1:2 2:2 1:3 2:3 3:3 1:4 2:4 3:4 4:4) plays on loop a of every b of its track (seq.c seq_cond), FILL
 * while FILL is held (GLO + E4), !FILL while not. A step has a chance or a condition (one byte): a condition plays at
 * 100 %. Firmware before 1.5.5 refuses a project holding one (its proj_unpack wants 0..101): the slot reads empty there.
 * The knobs and the lists show the two as one value (step_chance_v): 0..100 %, then 101..100 + NCOND the conditions */
#define COND_FIRST 102u
#define NCOND 11u
#define COND_FILL 10u                    /* FILL, NOT FILL: the last two */
#define COND_NFILL 11u
#define CHANCE_V_MAX (100u + NCOND)
static uint32_t step_cond(const step_t *s)   /* its condition 1..NCOND, 0 none */
{
    return s->probability >= COND_FIRST && s->probability < COND_FIRST + NCOND ? s->probability - COND_FIRST + 1u : 0u;
}
static uint32_t step_chance(const step_t *s)
{
    return !s->probability ? 100u : s->probability <= 100u ? s->probability : s->probability == 101u ? 0u : 100u;
}
static void step_set_chance(step_t *s, uint32_t chance) { s->probability = (uint8_t)(chance >= 100u ? 0u : chance ? chance : 101u); }
static uint32_t step_chance_v(const step_t *s) { uint32_t c = step_cond(s); return c ? 100u + c : step_chance(s); }
static void step_set_chance_v(step_t *s, uint32_t v)
{
    if (v > 100u)
        s->probability = (uint8_t)(COND_FIRST - 101u + (v < CHANCE_V_MAX ? v : CHANCE_V_MAX));
    else
        step_set_chance(s, v);
}
/* RATCH: a NOTE step plays its notes and hits this many times (1..4), in equal parts of the step; every older
 * pattern holds 0 there, x1 */
static uint32_t step_ratchet(const step_t *s) { return ((s->flags & SF_RATCH) >> SF_RATCH_SH) + 1u; }
static void step_set_ratchet(step_t *s, uint32_t hits)
{
    s->flags = (uint8_t)((s->flags & ~SF_RATCH) | ((hits < 1u ? 0u : hits > 4u ? 3u : hits - 1u) << SF_RATCH_SH));
}
/* NUDGE (1.2, #162, D98): a step's timing, in 1/NUDGE_DIV of the track's DIV, -8..+7 (half a step early .. 7/16 late);
 * live recording keeps it, SEQ > AUTOMATION's NUDGE rows and STEP (steps held + PRESETS) set it, the track's QUANTIZE
 * OFF (P_SQNT, AUTOMATION's QUANTIZE row) plays it (seq.c seq_tick).
 * Four bits of the flags no other field uses: 4 (bit 3 of the nudge, its sign) and 32 64 128 (bits 0..2). 0 = on the
 * step: every older pattern. A user preset's pattern keeps none (upreset.c up_pat_norm) */
#define NUDGE_DIV 16
#define SF_NUDGE (4u | 0xE0u)
static int32_t step_nudge(const step_t *s)
{
    uint32_t u = (uint32_t)(s->flags >> 5) | (uint32_t)(s->flags & 4u) << 1;
    return (int32_t)(u ^ 8u) - 8;
}
static void step_set_nudge(step_t *s, int32_t v)
{
    uint32_t u = (uint32_t)(v < -8 ? -8 : v > 7 ? 7 : v) & 15u;
    s->flags = (uint8_t)((s->flags & ~SF_NUDGE) | (u & 7u) << 5 | (u >> 1 & 4u));
}
#define MOTION_MAX 128u          /* 1.2 (FUN10): 64 before */
/* Four tracks x64 steps fit one byte. Values retain their signed parameter range (-64..127: an int8_t, 1.2).
 * param: the P_* id (< 128: P_COUNT is at most 127, project.c), bit 7 (MOTION_LOCK, 1.1) a parameter lock: the value
 * sounds on that step only and goes back after it (motion.c motion_step); without it an automation event, the
 * value holds until another one changes it. One record per (track, step, id), of either kind */
#define MOTION_LOCK 0x80u
#define MOTION_ID(e) ((uint32_t)(e)->param & 0x7Fu)
typedef struct { uint8_t place, param; int8_t value; } motion_event_t;
typedef struct { uint8_t count, on, rsv[2]; motion_event_t event[MOTION_MAX]; } motion_store_t;
_Static_assert(sizeof(motion_store_t) == 388u, "motion disk layout (FUN10)");
#define CHAIN_ROWS 16u
/* A song section (1.2, FUN10): the PROJECT slot each track plays (0..3, A..D; CHAIN_SILENT "-": that track plays
 * nothing there) and its repeats (1..16). Up to 1.1 a row was {slot, repeat}, all four tracks on that slot
 * (chain_v9_t, FUN6..FUN9): it loads as a section with the four on it (song_chain.c chain_from_v9) */
#define CHAIN_SILENT 4u
typedef struct { uint8_t slot[NTRK], repeat; } chain_row_t;
typedef struct {
    uint8_t count, rsv[3];
    chain_row_t row[CHAIN_ROWS];
} chain_config_t;
typedef struct { uint8_t slot, repeat; } chain_row_v9_t;   /* frozen: the rows of FUN6..FUN9 */
typedef struct {
    uint8_t count, rsv[3];
    chain_row_v9_t row[CHAIN_ROWS];
} chain_v9_t;
_Static_assert(sizeof(chain_config_t) == 84u && sizeof(chain_v9_t) == 36u, "song chain layouts (FUN10 / FUN6..FUN9)");

typedef struct track {
    int16_t p[P_COUNT];
    uint8_t engine, preset;      /* engine: what the audio ISR renders */
    uint8_t eng_req;             /* engine the UI asked for (the ISR switches at a block start) */
    uint8_t user;                /* user preset slot + 1 the sound came from (UI), 0 = none */
    voice_t v[NVOICE];
    /* LFO */
    uint32_t lfo_ph;
    int32_t lfo_val;             /* Q15 */
    int32_t lfo_fade;            /* Q15 ramp after note-on */
    uint32_t lfo_rnd;
    int16_t lfo_prev;            /* the S&H value of the cycle before (mod.c SLEW glides from it to lfo_rnd's) */
    /* keyboard / arp input: held notes in press order */
    uint8_t held[16];
    uint8_t nheld;
    uint8_t arp_phys;            /* keys physically held for the arp */
    uint8_t latched;             /* HOLD: keep notes after release */
    /* arp runtime */
    uint32_t arp_pos;            /* q8 samples into the current arp step */
    uint32_t arp_idx;
    uint8_t arp_note;            /* sounding arp note, 0 = none */
    uint8_t arp_walk;            /* WALK: the place in the note list it stands on */
    uint8_t arp_ch[3];           /* CHORD: the other notes sounding with arp_note, 0 = none */
    uint32_t arp_off;            /* q8 sample time of its note-off */
    /* sequencer */
    step_t step[NSTEP];
    uint32_t seq_pos;            /* q8 samples into the current step */
    uint16_t seq_idx;
    uint8_t seq_notes[STEP_NOTES + NLANE];   /* sounding seq notes (the step's notes, then its hits) */
    uint8_t seq_n;
    uint8_t seq_hold;            /* last step slides: keep the notes until the next step */
    uint8_t slide_glide;         /* next legato note glides (slide) */
    uint8_t rat_left;            /* RATCH: repeats of the playing step still to come (seq.c seq_ratchet) */
    uint32_t seq_off;
    uint8_t seq_active;          /* any step programmed */
    uint8_t rskip_idx;           /* live recording put notes into the step about to play: */
    uint8_t rskip_n, rskip[NLANE];   /* do not trigger them again there (they sound already) */
    /* NUDGE (QUANTIZE OFF, seq.c seq_tick): a step plays at its start + its nudge. Latched as a step starts: */
    uint32_t nd_late;            /* the step playing now plays at this seq_pos + 1 (0: it played) */
    uint32_t nd_early;           /* the next step plays early, at this seq_pos + 1 of this one (0: on its start) */
    uint8_t nd_fired;            /* that step + 1 once it played early (its start then plays nothing), 0 = none */
    /* live recording of held notes (seq.c rec_hold): the steps they are held into become TIEs */
    uint8_t rh_n, rh_note[STEP_NOTES];   /* recorded notes still held, 0 = none */
    uint8_t rh_start;            /* the step they were recorded into */
    uint8_t rh_ties;             /* TIE steps written after it */
    uint8_t rh_last;             /* the last of them; rh_bak: what it held (an early release puts it back) */
    step_t rh_bak;
    /* mono */
    uint8_t mono_stack[8];
    uint8_t nmono;
    uint8_t mono_note;           /* note the MONO / LEGATO / UNISON voice(s) play, 0 = none */
    uint8_t rr;                  /* POLY ROTATE: next voice to try */
    /* mix runtime */
    int32_t peak;
    int32_t dist_hp, dist_lp1, dist_lp2;   /* DIST insert state (fx.c) */
    uint8_t tail;                /* blocks to mix after the last voice (the DIST / INSERT tail) */
    uint8_t ins_run;             /* the INSERT still sounds (fx.c track_insert: its wet share above 0) */
    uint8_t cond_loop;           /* 1.5.5 (#209): the loop of its LEN playing (0..COND_LOOPS - 1, seq.c seq_tick) */
#if FELUCCA_CPU2
    /* the second core: a part's render state, its own, so the two cores' parts share nothing (fx.c mix_block) */
    uint8_t lfo_wrap;            /* the LFO's phase wrapped this block: its S&H is drawn after the parts (voice.c) */
    uint32_t esync_k[3];         /* ATK's step, DEC's and REL's coefficient (Q16) this block (voice.c esync_coef) */
    uint8_t spread_on;           /* SPREAD this block (fx.c mix_part, voice.c track_render) */
#endif
#if FELUCCA_SHELL
    uint8_t rsv_sz[9];           /* (sizeof(track_t) a multiple of 16: below; the shell's 16 parameters, 32 bytes, its
                                  * 16-byte steps, 1.8's AFTERTOUCH and the second core's state) */
#else
    uint8_t rsv_sz[13];          /* (sizeof(track_t) a multiple of 16: below; with or without the second core) */
#endif
    int16_t armp, aholdp;        /* P_AMODE / P_AHOLD as last seen by the ISR */
    /* engine switch (voice.c engine_block): the old engine's voices fade out, then it switches */
    uint8_t xf_on, xf;           /* fading; blocks of the fade still to render */
    int16_t pe_old[8];           /* P_E0..P_E7 of the sounding engine: the fade renders with these */
    uint8_t xp_n, xp_note[4], xp_vel[4];   /* note-ons during the fade, played on the new engine */
    /* modulation matrix (mod.c): MIDI performance controllers of the track's channel, 0..127 */
    uint8_t mw, at;              /* CC1 mod wheel, channel aftertouch */
    uint8_t ex_off;              /* 127 - CC11 expression (0: full, the MIDI default) */
    uint8_t m_vel, m_key, m_vi;  /* the latest note-on: velocity, note, voice index (per-block destinations) */
    uint8_t sp_alt;              /* SPREAD: the side the next voice starts on (alternating, voice.c voice_start) */
    int16_t m_rnd;               /* .. its RAND */
    int32_t m_env;               /* the amp envelope of voice m_vi, last block (Q15) */
} track_t;
/* the audio ISR indexes trk[] with a multiply by a small immediate and a shift while the size is a multiple of 16; 1.5's
 * new track parameters (the INSERT, the filter TYPE, ENV SYNC) and state would make it no multiple (the constant
 * loaded first: +3 % on the ISR's static cost, target_budget.py): one pad, rsv_sz, keeps it */
_Static_assert(sizeof(track_t) % 16u == 0, "track_t: a multiple of 16 bytes (a cheap trk[] index on the target)");

typedef struct {
    int16_t g[G_COUNT];
    uint8_t playing, seq_mode;
    uint8_t grid;                /* 1: the keys are the DRUM grid (ui.c grid_on): only the lane keys play (seq.c);
                                  * 2: NAME (ui_name.c): no key plays; 3: SONG, A..D are its (seq.c song_key) */
    uint8_t rec;                 /* live recording armed: bit per track */
    uint8_t sel;                 /* selected track 0..NTRK-1: keys, pages, editor */
    int8_t octave;
    uint32_t tick;               /* sub-blocks since play */
    uint32_t cpu_q8;             /* audio ISR load, 1/256 */
    uint32_t master_q12;
    int32_t batt_raw;            /* smoothed ADC ch3 (battery divider), 0 = not read yet */
    uint8_t mch[NTRK];           /* 1.5.5 (#202): MIDI IN TRACK (G_ROUTE ROUTE_TRACK), each track's channel as stored: 0..15
                                  * the channel's distance up from the track's own (track i: channel (i + v) % 16, so 0, the
                                  * zeroed default, is T1..T4 on channels 1..4), MCH_OMNI (any channel no track has), MCH_OFF
                                  * (none); mch_get / mch_set. The project's, in FUN10's spare bytes (project.c PROJ_MIDI_OFF);
                                  * MENU > MIDI > T1..T4 CHANNEL */
} song_t;
#define ROUTE_SEL 1
#define ROUTE_TRACK 5                /* G_ROUTE: TRACK, each track on its own channel (song.mch) */
#define MCH_OMNI 16u
#define MCH_OFF 17u
#define MCH_N 18u                    /* channels 1..16, OMNI, OFF */

static track_t trk[NTRK];        /* the instrument: four parts */
static song_t song;
#define TSEL (&trk[song.sel])    /* the selected track */
/* MIDI IN TRACK: track i's channel 0..15, MCH_OMNI or MCH_OFF (song.mch), and set */
static inline uint32_t mch_get(uint32_t i)
{
    uint32_t v = song.mch[i % NTRK];
    return v < 16u ? (v + i) & 15u : v < MCH_N ? v : (i & 15u);
}
static inline void mch_set(uint32_t i, uint32_t ch) { song.mch[i % NTRK] = (uint8_t)(ch < 16u ? (ch - i) & 15u : ch < MCH_N ? ch : 0u); }

/* SWING of a track's step clock: the track's own plus the global one, at most 100 (#31). The sequencer
 * (seq.c step_samples) and the SLICER (slicer.c sl_enter) both time steps with it. At 100 the even
 * steps are 1.4 x the straight length and the odd ones 0.6 x. */
#define SWING_MAX 100
static inline int32_t track_swing(const track_t *t)
{
    int32_t sw = t->p[P_SSWING] + song.g[G_SWING];
    return sw < 0 ? 0 : sw > SWING_MAX ? SWING_MAX : sw;
}
#if FELUCCA_SHELL
/* GROOVE (SQRL-1, the song's: shell.c SYSTEM 2, saved in FUN11's pair byte 6): the shape a swing takes; its depth is
 * the swing (SWG, 0..100) as ever. groove_off: step i's offset in samples from its straight place, i counted in
 * steps of `base` from a bar line; the step's length is the difference of two offsets, so nothing drifts:
 *   SWING      every other step late by depth x base / 250 (70 % of the pair at 100: as before)
 *   SHUFFLE    every other step late by depth x base / 300 (at 100 exactly the triplet, 2/3 of the pair)
 *   PUSH       every other step early by depth x base / 250 (never past the step before's start)
 *   LAID BACK  every other step late as SWING, and the steps on beats 2 and 4 late by two thirds of that
 *   HUMAN      every step but the bar's first moved by up to 8 ms x depth / 100 (a quarter step at most), the same
 *              at the same place in every bar, each part its own (groove_vel: its velocity by up to 10 %) */
enum { GR_SWING, GR_SHUFFLE, GR_PUSH, GR_LAID, GR_HUMAN, GR_N };
static volatile uint8_t song_groove;
static inline uint32_t gr_hash(uint32_t part, uint32_t i)
{
    uint32_t h = (part + 1u) * 0x9E3779B1u ^ i * 0x85EBCA77u;
    h ^= h >> 15;
    h *= 0x2C1B3C6Du;
    return h ^ h >> 12;
}
static inline uint32_t gr_spq(uint32_t base)            /* steps of `base` in a quarter (the song's BPM) */
{
    uint32_t q = (uint32_t)(2646000 / (song.g[G_BPM] > 0 ? song.g[G_BPM] : 120)), s = base ? (q + base / 2u) / base : 1u;
    return s ? s : 1u;
}
static inline int32_t groove_off(int32_t depth, uint32_t base, uint32_t i, uint32_t part)
{
    int32_t sw = depth * (int32_t)base / 250, m;
    uint32_t spq, pos;
    switch (song_groove) {
    case GR_SHUFFLE:
        return (i & 1u) ? depth * (int32_t)base / 300 : 0;
    case GR_PUSH:
        return (i & 1u) ? -sw : 0;
    case GR_LAID:
        spq = gr_spq(base);
        pos = i % (4u * spq);
        return ((i & 1u) ? sw : 0) + (spq > 1u && (pos == spq || pos == 3u * spq) ? sw * 2 / 3 : 0);
    case GR_HUMAN:
        spq = gr_spq(base);
        pos = i % (4u * spq);
        m = 353 * depth / 100;                          /* (8 ms at 44.1 kHz) */
        m = m < (int32_t)base / 4 ? m : (int32_t)base / 4;
        return pos ? ((int32_t)(gr_hash(part, pos) % 2001u) - 1000) * m / 1000 : 0;
    default:
        return (i & 1u) ? sw : 0;
    }
}
static inline uint32_t groove_vel(uint32_t vel, int32_t depth, uint32_t base, uint32_t i, uint32_t part)
{
    uint32_t pos = i % (4u * gr_spq(base));
    int32_t v = (int32_t)vel;
    if (song_groove != GR_HUMAN || !pos)
        return vel;
    v += v * ((int32_t)(gr_hash(part ^ 0x55u, pos) % 2001u) - 1000) / 1000 * depth / 1000;   /* (+-10 % at 100) */
    return (uint32_t)(v < 1 ? 1 : v > 127 ? 127 : v);
}
/* the length of step idx of a straight length `base`: from its offset to the next's (GROOVE) */
static inline uint32_t swing_step_len(const track_t *t, uint32_t base, uint32_t idx)
{
    int32_t d = track_swing(t);
    uint32_t p = (uint32_t)(t - trk) % NTRK;
    return base + (uint32_t)(groove_off(d, base, idx + 1u, p) - groove_off(d, base, idx, p));
}
#else
/* the length of step idx of a straight length `base`, swung: even steps longer, odd ones shorter */
static inline uint32_t swing_step_len(const track_t *t, uint32_t base, uint32_t idx)
{
    int32_t sw = track_swing(t) * (int32_t)base / 250;
    return base + (uint32_t)((idx & 1u) ? -sw : sw);
}
#endif

/* ----------------------------------------------------------- system --- */
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")   /* slot store before the index update */
static volatile uint32_t fm1_ms;  /* milliseconds since boot (TIMER4-based, TIMER5 ISR in main.c) */
/* boot-loop guard (main.c): two boots in a row that die in the first 30 s -> UBOOT */
#define BOOTGUARD_MAGIC 0x42475244u
struct { uint32_t magic, failed, pending; } bootguard __attribute__((section(".noinit")));
