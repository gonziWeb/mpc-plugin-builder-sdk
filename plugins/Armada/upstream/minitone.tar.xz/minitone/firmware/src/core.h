/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* FELUCCA core types: tracks, voices, engines, parameters.
 * Four tracks, each a synth part: its own engine, preset, parameters, voices and 64-step
 * pattern. The parts share one budget of NVOICE sounding voices (voice.c). Drums are the DRUM
 * engine (General MIDI map) on any part; the SAMPLE engine's PERC set is retired (drum_from_perc).
 * Sections: sizes, parameters, voices and engines, tracks and the song, system. */
#include <stdint.h>

/* ------------------------------------------------------------ sizes --- */
#define NVOICE 8                 /* voices per part, and the budget shared by all parts */
#define NPART 6                  /* synth parts: tracks 1..6 (projects hold tracks 1..4 in their own object, 5 and 6 in an extension: project.c) */
#define NTRK NPART               /* tracks (the formats and the protocol count these): every track is a part */
#define NSTEP 64
#define HALF_FRAMES 128          /* I2S half buffer: 2.9 ms at 44.1 kHz (a key waits 0..1 half, then plays 1 half later) */
#ifndef FELUCCA_FM4
#define FELUCCA_FM4 0            /* the DIGITAL engine (eng_digital.c, four-operator FM): kept in the tree, not built
                                  * by default; replaced by FM6, its sounds convert (fm4_convert.c) */
#endif
#ifndef FELUCCA_SWARM
#define FELUCCA_SWARM 1          /* the SWARM engine (eng_swarm.c), engine 14 */
#endif
#ifndef FELUCCA_FMTONE
#define FELUCCA_FMTONE 1         /* the FMTONE engine (eng_fmtone.c), engine 15; it needs SWARM (14): the numbers are stored */
#endif
#if FELUCCA_FMTONE && !FELUCCA_SWARM
#error "FELUCCA_FMTONE is engine 15 and needs the SWARM engine (14): build with FELUCCA_SWARM=1, or FELUCCA_FMTONE=0"
#endif
#ifndef FELUCCA_WAVETONE
#define FELUCCA_WAVETONE 1       /* the WAVETONE engine (eng_wavetone.c), engine 16; it needs FMTONE (15): the numbers are stored */
#endif
#if FELUCCA_WAVETONE && !FELUCCA_FMTONE
#error "FELUCCA_WAVETONE is engine 16 and needs the FMTONE engine (15): build with FELUCCA_FMTONE=1, or FELUCCA_WAVETONE=0"
#endif
#ifndef FELUCCA_FMDRUM
#define FELUCCA_FMDRUM 1         /* the FMDRUM engine (eng_fmdrum.c), engine 17, with its 62 built-in transients (~40 KB of flash); it needs WAVETONE (16): the numbers are stored */
#endif
#if FELUCCA_FMDRUM && !FELUCCA_WAVETONE
#error "FELUCCA_FMDRUM is engine 17 and needs the WAVETONE engine (16): build with FELUCCA_WAVETONE=1, or FELUCCA_FMDRUM=0"
#endif
#ifndef FELUCCA_SID
#define FELUCCA_SID 1            /* the SID engine (eng_sid.c), engine 18, after the MOS 6581; it needs FMDRUM (17): the numbers are stored */
#endif
#if FELUCCA_SID && !FELUCCA_FMDRUM
#error "FELUCCA_SID is engine 18 and needs the FMDRUM engine (17): build with FELUCCA_FMDRUM=1, or FELUCCA_SID=0"
#endif
#ifndef FELUCCA_CHIP
#define FELUCCA_CHIP 1           /* the CHIP engine (eng_chip.c), engine 19, after Elektron's SY CHIP; it needs SID (18): the numbers are stored */
#endif
#if FELUCCA_CHIP && !FELUCCA_SID
#error "FELUCCA_CHIP is engine 19 and needs the SID engine (18): build with FELUCCA_SID=1, or FELUCCA_CHIP=0"
#endif
#ifndef FELUCCA_DUAL
#define FELUCCA_DUAL 1           /* the DUALVCO engine (eng_dual.c), engine 20, after Elektron's SY DUAL VCO; it needs CHIP (19): the numbers are stored */
#endif
#if FELUCCA_DUAL && !FELUCCA_CHIP
#error "FELUCCA_DUAL is engine 20 and needs the CHIP engine (19): build with FELUCCA_CHIP=1, or FELUCCA_DUAL=0"
#endif
#ifndef FELUCCA_ANA4
#define FELUCCA_ANA4 1           /* the ANALOG4 engine (eng_ana4.c), engine 21, after Elektron's Analog Four; it needs DUALVCO (20): the numbers are stored */
#endif
#if FELUCCA_ANA4 && !FELUCCA_DUAL
#error "FELUCCA_ANA4 is engine 21 and needs the DUALVCO engine (20): build with FELUCCA_DUAL=1, or FELUCCA_ANA4=0"
#endif
#ifndef FELUCCA_BRAIDS
#define FELUCCA_BRAIDS 1         /* the BRAIDS engine (eng_braids.c), engine 22, after Mutable Instruments' Braids (MIT; braids_osc.c); it needs ANALOG4 (21): the numbers are stored */
#endif
#if FELUCCA_BRAIDS && !FELUCCA_ANA4
#error "FELUCCA_BRAIDS is engine 22 and needs the ANALOG4 engine (21): build with FELUCCA_ANA4=1, or FELUCCA_BRAIDS=0"
#endif
#ifndef FELUCCA_TB303
#define FELUCCA_TB303 1          /* the TB303 engine (eng_tb303.c), engine 23, after Roland's TB-303; it needs BRAIDS (22): the numbers are stored */
#endif
#if FELUCCA_TB303 && !FELUCCA_BRAIDS
#error "FELUCCA_TB303 is engine 23 and needs the BRAIDS engine (22): build with FELUCCA_BRAIDS=1, or FELUCCA_TB303=0"
#endif
#ifndef FELUCCA_TR808
#define FELUCCA_TR808 1          /* the TR808 engine (eng_tr808.c), engine 24, after the TR-808 of the 8W8 module (GPL-3.0); it needs TB303 (23): the numbers are stored */
#endif
#if FELUCCA_TR808 && !FELUCCA_TB303
#error "FELUCCA_TR808 is engine 24 and needs the TB303 engine (23): build with FELUCCA_TB303=1, or FELUCCA_TR808=0"
#endif
#define NENGINES (14 + FELUCCA_SWARM + FELUCCA_FMTONE + FELUCCA_WAVETONE + FELUCCA_FMDRUM + FELUCCA_SID + FELUCCA_CHIP + FELUCCA_DUAL + FELUCCA_ANA4 + FELUCCA_BRAIDS + FELUCCA_TB303 + FELUCCA_TR808)   /* SLICE (13), SWARM (14), FMTONE (15), WAVETONE (16), FMDRUM (17) come last: the other engines keep their numbers */
#define ENGI_DIGITAL 1u          /* reserved without FELUCCA_FM4: never selectable (eng_ok), its sounds load as FM6 */
#define NENG_SHOWN (2 + FELUCCA_FM4 + FELUCCA_SWARM + FELUCCA_FMTONE + FELUCCA_WAVETONE + FELUCCA_FMDRUM + FELUCCA_SID + FELUCCA_CHIP + FELUCCA_DUAL + FELUCCA_ANA4 + FELUCCA_BRAIDS + FELUCCA_TB303 + FELUCCA_TR808)   /* the engines one can pick: PRESETS, the EDIT layer, the editor,
                                                * in the display order of engines.c ENGINE_ORDER (FM6, DRUM + the optional ones; the older engines are
                                                * still built, so saved sounds play, but are hidden) */
#define UP_SLOTS 32u             /* user presets (upreset.c) */
#define NELEM(a) (sizeof(a) / sizeof((a)[0]))

/* ------------------------------------------------------- parameters --- */
enum {
    F_INT, F_PCT, F_BIPCT, F_TIME, F_LFOHZ, F_CUTOFF, F_DB, F_SEMI, F_ENUM, F_BPM, F_NOTE,
    F_ONOFF, F_OCT, F_STEPS, F_REVDEC,     /* F_REVDEC: the ELEK reverb's decay: a time, 127 = INF */
    F_DTIME                                /* F_DTIME: the delay's TIME (params.c N_DTIME): a note value, dotted or not, or milliseconds */
};

typedef struct {
    const char *label;
    uint8_t fmt;
    int16_t min, max, def;
    const char *const *names;   /* F_ENUM */
    const char *unit;           /* F_INT / F_ENUM optional unit */
} param_desc_t;

enum {                          /* per-track parameters */
    P_LEVEL,
    P_ATK, P_DEC, P_SUS, P_REL,
    P_ED_FLT, P_ED_PIT, P_ED_SHP, P_ED_FX,     /* P_ED_FX: unused, kept for the formats / protocol */
    P_LRATE, P_LWAVE, P_LPHASE, P_LFADE,
    P_LD_PIT, P_LD_FLT, P_LD_SHP, P_LD_AMP,
    P_AMODE, P_ARATE, P_AOCT, P_AGATE,
    P_ASWING, P_APROB, P_AHOLD, P_AORDER,
    P_ROOT, P_SCALE, P_QUANT, P_TRANS,
    P_SLEN, P_SDIV, P_SSWING, P_SGATE,
    P_DIST, P_CHOR, P_DLY, P_REV,
    P_VOICE, P_GLIDE, P_PAN, P_MUTE,
    P_GLMODE, P_PRIO, P_ALLOC, P_DETUNE,
    P_SLCR, P_SLPAT, P_SLRATE, P_SLDEPTH,      /* SLICER insert (slicer.c) */
    P_M1SRC, P_M1DST, P_M1AMT,                 /* modulation matrix (mod.c): 4 slots of SRC, DST, AMT; */
    P_M2SRC, P_M2DST, P_M2AMT,                 /* new common parameters go just before P_E0 (user presets */
    P_M3SRC, P_M3DST, P_M3AMT,                 /* and projects map by count) */
    P_M4SRC, P_M4DST, P_M4AMT,
    P_FM1_ATK, P_FM1_DEC, P_FM1_SUS, P_FM1_REL, P_FM1_LEVEL,
    P_FM2_ATK, P_FM2_DEC, P_FM2_SUS, P_FM2_REL, P_FM2_LEVEL,
    P_FM3_ATK, P_FM3_DEC, P_FM3_SUS, P_FM3_REL, P_FM3_LEVEL,
    P_FM4_ATK, P_FM4_DEC, P_FM4_SUS, P_FM4_REL, P_FM4_LEVEL,
    P_CHRD, P_VOIC,                            /* chord keys (chord.c): one key plays a chord; its voicing */
    P_LN0, P_LN1, P_LN2, P_LN3, P_LN4, P_LN5, P_LN6, P_LN7,   /* DRUM lane levels (eng_drum.c, #97): KICK .. BELL */
    P_LSYNC, P_LTRIG, P_LPOL,                  /* 1.2 (#154): LFO SYNC (OFF, a note value), TRIG (NOTE, FREE), POL (BI, UNI) */
    P_SQNT,                                    /* 1.2 (#162): QUANTIZE, the steps' recorded / nudged timing (ON: none) */
    P_SPRD,                                    /* (#148): SPREAD, the voices of a POLY / UNISON track around PAN (fx.c) */
    P_ITYPE, P_IA, P_IB, P_IC, P_IMIX,         /* 1.5 (#78, #177): the INSERT, its TYPE, three values and MIX (fx.c) */
    P_FTYPE,                                   /* 1.5 (#104): ANALOG's filter TYPE, LP (as before) / BP / HP (eng_analog.c) */
    P_ESYNC,                                   /* 1.5 (#175): ENV SYNC: ATK DEC REL as note values of the tempo (voice.c) */
    P_E0, P_E1, P_E2, P_E3, P_E4, P_E5, P_E6, P_E7,
    P_COUNT
};

enum {                          /* global parameters */
    G_BPM, G_SWING, G_CLOCK, G_TUNE,
    G_DTIME, G_DFDBK, G_DCOLOR, G_DMIX,
    G_RSIZE, G_RDAMP, G_CRATE, G_CDEPTH,
    G_MIDI, G_SYNC, G_ROUTE, G_INFO,   /* G_ROUTE: MIDI IN, 0 CH1-4 (channels 1..4 -> parts 1..4, 5..16 ignored), 1 SEL;
                                        * 1.2: 2..4 CH5-8 CH9-12 CH13-16 (seq.c midi_base) */
    G_SLOT, G_NAME, G_LOAD, G_SAVE,
    G_ENGSEL, G_ENGGO,          /* no page: the editor switches the engine with a SET of G_ENGSEL; G_ENGGO is
                                 * unused (ids are fixed by the formats and the protocol) */
    G_CLRSEQ, G_INITSND,
    G_RTYPE,                    /* REVERB TYPE: 0 ROOM, 1 SPRING, 2 HALL (1.2, the power-on default) (fx.c). Was
                                 * G_DRCH, the GM drum part's MIDI channel (inert since 1.0, never read); projects
                                 * of formats before FUN7 load it as ROOM (project.c proj_rtype_room) */
    G_DRLVL, G_DRREV,           /* inert (label "-", on no page): the GM drum part they set is gone; kept
                                 * because the ids and G_COUNT are fixed by the formats and the protocol (only
                                 * the import of an old project reads them: proj_drums_to_part) */
    G_COUNT
};

/* stored parameters of an older layout -> today's P_* order. A store keeps np = the P_COUNT it was
 * written with; common parameters are only ever added just before P_E0, so the first np - 8 are
 * P_LEVEL.. in order and the last 8 are P_E0..P_E7; the parameters a store does not have take def[]
 * (user presets, projects of formats 1 and 2) */
static void params_by_count(int16_t *out, const int16_t *in, uint32_t np, const int16_t *def)
{
    uint32_t i, nc = np - 8u;
    for (i = 0; i < P_E0; i++)
        out[i] = i < nc ? in[i] : def[i];
    for (i = 0; i < 8u; i++)
        out[P_E0 + i] = in[nc + i];
}

/* engine indices the stores name (engines.c ENGINES[]: append-only) */
#define ENGI_PHYS 9u
#define ENGI_DRUM 10u
/* PHYS MODEL DRUM (MODEL 4, before 1.0) -> the DRUM engine, its E values in place: {MODEL, TUNE, TONE, DECY,
 * SNAP, ACC, KICK 0..127, PERC 0..127} -> {KIT, TUNE, TONE, DECY, SNAP, ACC, KICK 0..1, DRV 0}. 1 = it was one
 * (its engine is ENGI_DRUM now); projects (project.c) and user presets (upreset.c) */
static int drum_from_phys(uint32_t engine, int16_t *e)
{
    if (engine != ENGI_PHYS || e[0] != 4)
        return 0;
    e[0] = (int16_t)((e[7] < 0 ? 0 : e[7] > 127 ? 127 : e[7]) >> 5);   /* PERC -> KIT: STD HAND CYM H+CYM */
    e[6] = (int16_t)(e[6] >= 64);                                       /* KICK: PUNCH, ROUND */
    e[7] = 0;
    return 1;
}

/* SAMPLE SET 4 was PERC, the GM-mapped drum kit (tools/gen_samples.py); retired after 1.0.2: its index stays
 * (SET / GRAIN SRC 4 is an alias of PIANO, USR1..3 keep 5..7). A sound that selected it is the DRUM engine with
 * its default kit (eng_drum.c DRUM_PRESETS[0]: the same GM key map, so its patterns still play as drums): its E
 * values become the kit's, the rest of the sound (mix, sends, matrix, ..) stays. 1 = it was one (its engine is
 * ENGI_DRUM now); projects (project.c proj_perc), user presets (upreset.c up_migrate), factory preset 4 and
 * favourites (ui.c, settings_persist.c). Idempotent */
#define ENGI_SAMPLE 4u
#define SMP_SET_PERC 4u
#define DRUM_KIT_E {0, 64, 70, 64, 64, 100, 0, 0}   /* {KIT STD, TUNE, TONE, DECY, SNAP, ACC, KICK PUNCH, DRV} */
static int drum_from_perc(uint32_t engine, int16_t *e)
{
    static const int16_t KIT[8] = DRUM_KIT_E;
    uint32_t i;
    if (engine != ENGI_SAMPLE || e[0] != (int16_t)SMP_SET_PERC)
        return 0;
    for (i = 0; i < 8u; i++)
        e[i] = KIT[i];
    return 1;
}

/* ------------------------------------------------- voices, engines --- */
enum { V_POLY, V_MONO, V_LEGATO, V_UNISON };   /* P_VOICE */
typedef struct {
    uint8_t note, vel, gate, active;
    uint8_t stage;               /* env: 0 off, 1 attack, 2 decay/sustain, 3 release */
    uint8_t side;                /* SPREAD (fx.c mix_spread): 0 left of PAN, 1 right; set as the voice starts */
    int32_t env;                 /* Q24 */
    int32_t env_out;             /* last control-rate amplitude, Q15 */
    int32_t pitch16, pitch_cur;  /* 1/16 semitone, with glide */
    int32_t gstep;               /* glide TIME mode: 1/16 st per control tick, 0 = RATE mode */
    int32_t fine;                /* unison detune: phase increment * (1 + fine / 4096) */
    uint32_t ph[3];
    int32_t s[8];                /* engine state (filters, envs) */
    uint32_t age;
    uint8_t mvel;                /* mod.c: the note-on velocity (before UNISON scaling) and RAND of the note */
    int16_t mrnd;
} voice_t;

typedef struct {                 /* per-voice control-rate modulation, computed in voice.c */
    uint32_t inc;                /* phase increment of the base pitch */
    int32_t pitch16;
    int32_t amp0, amp1;          /* Q15 ramp over the block */
    int32_t cutoff;              /* 0..127 << 8 */
    int32_t shape;               /* 0..127 << 8 */
    int32_t envq15;              /* env value (for engines that use it as a mod source) */
    int32_t fine;                /* the residual below 1/16 semitone in inc: unison detune, TUNE, bend (1/4096) */
} vmod_t;

typedef struct {
    const char *name;
    int8_t e[8];                 /* P_E0..P_E7 (signed: an interval below the note; every value fits) */
    uint8_t env[4];              /* ATK DEC SUS REL */
    int8_t fenv;                 /* ENV -> FILTER amount (-64..63) */
    uint8_t mono;                /* 1 = MONO (bass / lead), 0 = POLY */
    /* the rest of the patch; each value is stored + 1, 0 = the default */
    uint8_t fx[4];               /* DIST, CHORUS, DELAY, REVERB sends */
    uint8_t pat;                 /* suggested pattern (PATTERNS[pat - 1], 0 = none): only a hint. A sound load
                                  * never touches the steps; SEQ > PATTERNS loads a pattern (ui.c pat_load). The
                                  * arp is the track's too: a preset does not set it */
} preset_t;
#define FX(d, c, dl, r) .fx = {(d) + 1, (c) + 1, (dl) + 1, (r) + 1}
#define PAT(n) .pat = (n)

struct track;
typedef struct {                 /* an engine (engines.c ENGINES[]; the eng_*.c files) */
    const char *name;            /* "ANALOG" (PRESETS, the editor) */
    const char *page_title[2];   /* EDIT 1 and EDIT 2 */
    param_desc_t edit[8];        /* P_E0..P_E7 */
    const preset_t *presets;
    uint8_t npresets;
    uint8_t knob[4];             /* HOME: the four parameters on KNOB 1..4 */
    uint8_t poly;                /* voice cap for POLY and UNISON, 0 = NVOICE */
    uint8_t sampled;             /* 1 = plays recorded material (a position, not a phase): voice.c keeps
                                  * no phases over a retrigger, spreads none for UNISON, renders at SUS 0 */
    uint8_t keep;                /* bit k: s[k] is kept when a sounding voice is retriggered (filters) */
    uint8_t oneshot;             /* 1 = hits (DRUM): always POLY, no glide; amp ends its voices (eng_drum.c) */
    void (*note_on)(struct track *t, voice_t *v);
    void (*render)(struct track *t, voice_t *v, int32_t *out, uint32_t n, const vmod_t *m);
    /* optional (0 = none): the voice amplitude instead of the ADSR curve, once per control tick;
     * gets the ADSR value (Q15, env_tick already ran: it still gates the voice), returns Q15 */
    int32_t (*amp)(struct track *t, voice_t *v, int32_t adsr);
    /* optional: a mode-dependent descriptor of EDIT k (the same range and default as edit[k],
     * another label / value names), 0 = edit[k] */
    const param_desc_t *(*desc)(const struct track *t, uint32_t k);
    /* optional: the engine's own descriptor of the operator slots P_FM1_ATK .. P_FM4_LEVEL (20 track parameters no other
     * engine uses: DIGITAL's, retired), another label, format, range and default, 0 = TP's. Read by the device display
     * (params.c track_desc) and by everything that clamps a stored or edited value (param_desc_of); a value is stored as
     * any track parameter (int16_t, project / user preset / motion). The defaults a sound load or an engine switch
     * starts from stay TP's (ui.c, project.c), so a descriptor's default should be TP's */
    const param_desc_t *(*tdesc)(uint32_t id);
    /* optional: once per block and part, before its voices (also with no voice sounding) */
    void (*block)(struct track *t);
    /* optional: the note of key k (0 = the lowest) when the engine maps the keys itself, else -1
     * (then the scale keyboard of seq.c kb_map) */
    int32_t (*keys)(const struct track *t, uint32_t k);
    /* 1 = the engine's own envelopes are the voice's amplitude (FM6): voice.c renders it at 1.0 (no ADSR, no
     * velocity; LFO -> AMP, the matrix's AMP and the fades still apply; ENV is 0) and the voice ends when
     * done() says so (once per control tick, before the render), not at the end of the ADSR's release */
    uint8_t ownenv;
    int (*done)(struct track *t, voice_t *v);
    /* bytes of the part's engine memory (engines.c eng_mem, at most ENG_MEM_PART) the engine keeps its state
     * in, 0 = none: a part plays one engine at a time, so they share one region; on a switch to the engine
     * (after the old one's fade) the region is zeroed when another engine had it (eng_mem_claim) */
    uint16_t mem;
} engine_t;

/* ------------------------------------------------- tracks, the song --- */
enum { ST_NOTE, ST_TIE, ST_REST };
#define SF_ACCENT 1u
#define SF_SLIDE 2u
#define SF_RATCH_SH 3u                   /* RATCH: the hits of a NOTE step - 1 (0..3: x1..x4, seq.c seq_ratchet); */
#define SF_RATCH (3u << SF_RATCH_SH)     /* bits 3..4, so a user preset's pattern (flag 4 = tie) carries it too */
#define NLANE 8                  /* drum lanes of a step (the DRUM engine's: eng_drum.c DRUM_LANE_NOTE) */
typedef struct {                 /* acid-style step: up to 4 notes (POLY), time, accent, slide; drum hits */
    uint8_t note[4];
    uint8_t n;                   /* notes in use, 0 = empty */
    uint8_t time;                /* ST_NOTE / ST_TIE / ST_REST */
    uint8_t flags;               /* SF_ACCENT | SF_SLIDE | SF_RATCH */
    uint8_t vel;
    uint8_t hit;                 /* bit l: lane l hits (its GM note, on any engine): the DRUM grid */
    uint8_t acc;                 /* bit l: that hit is accented (velocity 127) */
    uint8_t probability;         /* 0 = legacy 100%; 1..100 = percent, 101 = silent */
    uint8_t lvl;                 /* (SLOOP 2.8) 2 bits per note, note k at bits 2k..2k+1: its LV_* force; 0 = as the step's VEL */
    uint8_t rat;                 /* 2 bits per note: that note's own ratchet - 1 (0: the step's RATCH) */
    uint8_t fx;                  /* bits 0..1: the step's condition (FC_*); bits 2..3: its NUDGE's quarter (step_micro) */
} step_t;
typedef struct {                 /* a step as formats 1..4 (projects to FUN4) stored it: no hits */
    uint8_t note[4];
    uint8_t n, time, flags, vel;
} step8_t;

/* Probability keeps zero-initialized and legacy patterns at 100%. */
static uint32_t step_chance(const step_t *s) { return !s->probability ? 100u : s->probability <= 100u ? s->probability : 0u; }
static void step_set_chance(step_t *s, uint32_t chance) { s->probability = (uint8_t)(chance >= 100u ? 0u : chance ? chance : 101u); }
/* RATCH: a NOTE step plays its notes and hits this many times (1..4), in equal parts of the step; every older
 * pattern holds 0 there, x1 */
static uint32_t step_ratchet(const step_t *s) { return ((s->flags & SF_RATCH) >> SF_RATCH_SH) + 1u; }
static void step_set_ratchet(step_t *s, uint32_t hits)
{
    s->flags = (uint8_t)((s->flags & ~SF_RATCH) | ((hits < 1u ? 0u : hits > 4u ? 3u : hits - 1u) << SF_RATCH_SH));
}
/* NUDGE (1.2, #162, D98): a step's timing, in 1/NUDGE_DIV of the track's DIV, -8..+7 (half a step early .. 7/16 late);
 * live recording keeps it, SEQ > AUTOMATION's NUDGE rows and STEP (steps held + PRESETS) set it, the track's QUANTIZE
 * OFF (P_SQNT, AUTOMATION's QUANTIZE row) plays it (seq.c seq_tick).
 * Four bits of the flags no other field uses: 4 (bit 3 of the nudge, its sign) and 32 64 128 (bits 0..2). 0 = on the
 * step: every older pattern. A user preset's pattern keeps none (upreset.c up_pat_norm) */
#define NUDGE_DIV 16
#define SF_NUDGE (4u | 0xE0u)
static int32_t step_nudge(const step_t *s)
{
    uint32_t u = (uint32_t)(s->flags >> 5) | (uint32_t)(s->flags & 4u) << 1;
    return (int32_t)(u ^ 8u) - 8;
}
static void step_set_nudge(step_t *s, int32_t v)
{
    uint32_t u = (uint32_t)(v < -8 ? -8 : v > 7 ? 7 : v) & 15u;
    s->flags = (uint8_t)((s->flags & ~SF_NUDGE) | (u & 7u) << 5 | (u >> 1 & 4u));
}
/* SLOOP 2.8's per-note force and the condition (a step's fx / lvl / rat; every older pattern holds 0: as before) */
enum { LV_NORM, LV_GHOST, LV_SOFT, LV_HARD };
enum { FC_NORM, FC_FILL, FC_NOFILL };     /* plays always, only during a fill, never during one (3: as FC_NORM) */
static uint32_t step_lvl(const step_t *s, uint32_t k) { return (s->lvl >> (2u * (k & 3u))) & 3u; }
static void step_set_lvl(step_t *s, uint32_t k, uint32_t v)
{
    uint32_t sh = 2u * (k & 3u);
    s->lvl = (uint8_t)((s->lvl & ~(3u << sh)) | (v & 3u) << sh);
}
static uint32_t step_nrat(const step_t *s, uint32_t k) { return (s->rat >> (2u * (k & 3u))) & 3u; }
static void step_set_nrat(step_t *s, uint32_t k, uint32_t v)
{
    uint32_t sh = 2u * (k & 3u);
    s->rat = (uint8_t)((s->rat & ~(3u << sh)) | (v & 3u) << sh);
}
/* note k out of the step (the ones above it move down, with their force and ratchet) */
static uint32_t drop2(uint32_t v, uint32_t k) { return (v & ((1u << (2u * k)) - 1u)) | ((v >> (2u * k + 2u)) << (2u * k)); }
static void step_drop_note(step_t *s, uint32_t k)
{
    uint32_t j;
    if (k >= s->n || k >= 4u)
        return;
    for (j = k; j + 1u < 4u; j++)
        s->note[j] = s->note[j + 1u];
    s->note[3] = 0;
    s->lvl = (uint8_t)drop2(s->lvl, k);
    s->rat = (uint8_t)drop2(s->rat, k);
    s->n--;
}
static uint32_t step_fill(const step_t *s) { return (s->fx & 3u) == 3u ? FC_NORM : (uint32_t)(s->fx & 3u); }
static void step_set_fill(step_t *s, uint32_t v) { s->fx = (uint8_t)((s->fx & ~3u) | (v > 2u ? 0u : v)); }
/* SLOOP's micro timing: a step's nudge in 1/MICRO_DIV of the step, -32..+31 (a quarter of NUDGE's sixteenth: the
 * nudge's own bits and the quarter in fx) */
#define MICRO_DIV 64
#define MICRO_MIN (-32)
#define MICRO_MAX 31
static int32_t step_micro(const step_t *s) { return step_nudge(s) * 4 + (int32_t)((s->fx >> 2) & 3u); }
static void step_set_micro(step_t *s, int32_t v)
{
    v = v < MICRO_MIN ? MICRO_MIN : v > MICRO_MAX ? MICRO_MAX : v;
    step_set_nudge(s, v >> 2);
    s->fx = (uint8_t)((s->fx & ~12u) | (uint32_t)(v & 3) << 2);
}
/* STOCHASTIC mode (after the OXI ONE's): a track with it ON generates each step as it comes (seq.c stoch_gen) from these
 * odds, instead of playing its steps (they rest, untouched; seq.c seq_play). Saved with the project (project.c: the
 * extension); every older project holds zeros, read as the defaults and OFF */
typedef struct {
    uint8_t on;                  /* 1: the track generates */
    uint8_t dens;                /* 0..100: the chance a step plays */
    uint8_t groove;              /* 0..100: how much likelier the downbeats are than the offbeats (+- groove / 2 points) */
    uint8_t oct;                 /* 0..8: the lowest octave: a note is 12 (oct + 1 + 0..range - 1) + its pitch class */
    uint8_t range;               /* 1..4: octaves */
    uint8_t vmin, vmax;          /* 1..127: a note's velocity is drawn between them */
    uint8_t rat;                 /* 0..100: the chance a step ratchets (x2..x4) */
    uint8_t sld;                 /* 0..100: the chance a note slides into the next */
    uint8_t stack;               /* 0..100: the chance of each extra note of a chord (up to two more) */
    uint8_t loop;                /* 0: free, a new one every pass; 1..64: the same loop of that many steps, until REROLL */
    uint8_t euc2_ro;             /* EUCLID layer B (seq.c euclid_gen): ROT 0..63 in bits 0..5, the operator in bits 6..7 (EUC_AND..EUC_SUB); was rsv */
    uint16_t seed;               /* the loop's (REROLL draws another) */
    uint8_t w[12];               /* each pitch class's weight 0..15, C to B (a DRUM track: w[0..7] are the lanes) */
    uint8_t euc_on;              /* EUCLID mode (exclusive with `on`; seq.c euclid_gen): 1: the track plays the rhythm below */
    uint8_t euc_len;             /* 1..64: the rhythm's steps (its own loop: not the pattern's LEN) */
    uint8_t euc_pulses;          /* 0..euc_len: the hits, spread as evenly as they can be */
    uint8_t euc_rot;             /* 0..euc_len-1: the rhythm turned that many steps */
    uint8_t euc2_len;            /* layer B: bits 0..6 its LEN 1..64 (0: not set yet), bit 7 ON (EUCLID 2); zeros = OFF */
    uint8_t euc2_pulses;         /* layer B: 0..LEN, the hits (32 bytes, as the extension stores it) */
} stoch_t;
_Static_assert(sizeof(stoch_t) == 32u, "a stochastic setting is 32 bytes (project.c extension)");
static void euclid_defaults(stoch_t *g)
{
    g->euc_on = 0; g->euc_len = 16; g->euc_pulses = 4; g->euc_rot = 0;
}
/* EUCLID 2: a second rhythm B (its own LEN, PULSES, ROT) combined with A by a boolean operator, step by step */
enum { EUC_AND, EUC_OR, EUC_XOR, EUC_SUB };            /* SUB: A without B */
#define EUC2_LEN(g) ((uint32_t)((g)->euc2_len & 127u))
#define EUC2_ON(g) (((g)->euc2_len & 128u) && EUC2_LEN(g))
#define EUC2_ROT(g) ((uint32_t)((g)->euc2_ro & 63u))
#define EUC2_OP(g) ((uint32_t)((g)->euc2_ro >> 6))
static void euclid2_defaults(stoch_t *g)
{
    g->euc2_len = 12; g->euc2_pulses = 3; g->euc2_ro = 0;
}
/* EUCLID: step i of the rhythm hits when the pulses, turned by ROT, fall on it (Bjorklund by the floor: E(3,8) x..x..x.) */
static uint32_t euclid_hit(const stoch_t *g, uint32_t i)
{
    uint32_t n = g->euc_len, k = (i + n - g->euc_rot % n) % n;   /* (turned right: ROT steps later) */
    return (k * g->euc_pulses) % n < g->euc_pulses;
}
static uint32_t euclid_hit2(const stoch_t *g, uint32_t i)       /* rhythm B (EUC2_LEN > 0) */
{
    uint32_t n = EUC2_LEN(g), k = (i + n - EUC2_ROT(g) % n) % n, p = g->euc2_pulses;
    return (k * p) % n < p;
}
/* the track's hit at A's step ia and B's step ib: A alone, or A (op) B with layer B on */
static uint32_t euclid_mix(const stoch_t *g, uint32_t ia, uint32_t ib)
{
    uint32_t a = euclid_hit(g, ia % g->euc_len), b;
    if (!EUC2_ON(g))
        return a;
    b = euclid_hit2(g, ib % EUC2_LEN(g));
    switch (EUC2_OP(g)) {
    case EUC_AND: return a & b;
    case EUC_OR: return a | b;
    case EUC_XOR: return a ^ b;
    default: return a & !b;
    }
}
static void stoch_defaults(stoch_t *g)
{
    uint32_t i;
    uint8_t eo = g->euc_on, el = g->euc_len, ep = g->euc_pulses, er = g->euc_rot;   /* (EUCLID's are kept) */
    uint8_t l2 = g->euc2_len, p2 = g->euc2_pulses, r2 = g->euc2_ro;
    memset(g, 0, sizeof *g);
    g->euc_on = eo; g->euc_len = el; g->euc_pulses = ep; g->euc_rot = er;
    g->euc2_len = l2; g->euc2_pulses = p2; g->euc2_ro = r2;
    g->dens = 60; g->groove = 40; g->oct = 3; g->range = 2; g->vmin = 70; g->vmax = 110; g->seed = 1;
    for (i = 0; i < 12u; i++)
        g->w[i] = 8;
}
/* a stored setting is zeros (no stochastic setting then) or inside its ranges: anything else is the defaults */
static void stoch_bound(stoch_t *g)
{
    uint32_t i, bad = !g->vmax || !g->range || g->range > 4u || g->oct > 8u || g->vmin > g->vmax || g->vmax > 127u || !g->vmin ||
                      g->dens > 100u || g->groove > 100u || g->rat > 100u || g->sld > 100u || g->stack > 100u || g->loop > 64u || g->on > 1u;
    for (i = 0; i < 12u; i++)
        bad |= g->w[i] > 15u;
    if (bad)
        stoch_defaults(g);
    if (!g->euc_len || g->euc_len > 64u || g->euc_pulses > g->euc_len || g->euc_rot >= g->euc_len || g->euc_on > 1u) {
        euclid_defaults(g);                          /* (zeros, as every older project holds: the defaults, OFF) */
    }
    if (g->on)
        g->euc_on = 0;                               /* (exclusive) */
    if (EUC2_LEN(g) > 64u || g->euc2_pulses > EUC2_LEN(g) || EUC2_ROT(g) >= (EUC2_LEN(g) ? EUC2_LEN(g) : 1u))
        g->euc2_len = g->euc2_pulses = g->euc2_ro = 0;       /* (layer B off; zeros, as older projects hold) */
    if (!EUC2_LEN(g))
        g->euc2_len = g->euc2_pulses = 0;
}
#define GEN_ON(t) ((t)->stoch.on || (t)->stoch.euc_on)   /* the track draws its steps (STOCHASTIC or EUCLID), its pattern rests */
#define MOTION_MAX 128u          /* 1.2 (FUN10): 64 before */
/* Four tracks x64 steps fit one byte. Values retain their signed parameter range (-64..127: an int8_t, 1.2).
 * param: the P_* id (< 128: P_COUNT is at most 127, project.c), bit 7 (MOTION_LOCK, 1.1) a parameter lock: the value
 * sounds on that step only and goes back after it (motion.c motion_step); without it an automation event, the
 * value holds until another one changes it. One record per (track, step, id), of either kind */
#define MOTION_LOCK 0x80u
#define MOTION_ID(e) ((uint32_t)(e)->param & 0x7Fu)
/* place: track << 6 | step (a track is 0..NTRK - 1: 9 bits with six tracks; the stored FUN10 record has them in one byte,
 * tracks 1..4 only: motion_wire_t, the events of tracks 5 and 6 are kept in the project's extension, project.c) */
typedef struct { uint16_t place; uint8_t param; int8_t value; } motion_event_t;
typedef struct { uint8_t count, on, rsv[2]; motion_event_t event[MOTION_MAX]; } motion_store_t;
typedef struct { uint8_t place, param; int8_t value; } motion_wire_event_t;
typedef struct { uint8_t count, on, rsv[2]; motion_wire_event_t event[MOTION_MAX]; } motion_wire_t;
_Static_assert(sizeof(motion_wire_t) == 388u, "motion disk layout (FUN10)");
#define CHAIN_ROWS 16u
/* A song section (1.2, FUN10): the PROJECT slot each track plays (0..3, A..D; CHAIN_SILENT "-": that track plays
 * nothing there) and its repeats (1..16). Up to 1.1 a row was {slot, repeat}, all four tracks on that slot
 * (chain_v9_t, FUN6..FUN9): it loads as a section with the four on it (song_chain.c chain_from_v9) */
#define CHAIN_SILENT 4u
typedef struct { uint8_t slot[NTRK], repeat; } chain_row_t;
typedef struct {
    uint8_t count, rsv[3];
    chain_row_t row[CHAIN_ROWS];
} chain_config_t;
#define NPROJ 4u                 /* the tracks a stored FUN10 holds (the firmware before 1.0.0 had four parts); tracks 5 and 6 are in the extension */
typedef struct { uint8_t slot[NPROJ], repeat; } chain_wire_row_t;     /* FUN10's sections */
typedef struct {
    uint8_t count, rsv[3];
    chain_wire_row_t row[CHAIN_ROWS];
} chain_wire_t;
typedef struct { uint8_t slot, repeat; } chain_row_v9_t;   /* frozen: the rows of FUN6..FUN9 */
typedef struct {
    uint8_t count, rsv[3];
    chain_row_v9_t row[CHAIN_ROWS];
} chain_v9_t;
_Static_assert(sizeof(chain_wire_t) == 84u && sizeof(chain_v9_t) == 36u, "song chain layouts (FUN10 / FUN6..FUN9)");

typedef struct track {
    int16_t p[P_COUNT];
    uint8_t engine, preset;      /* engine: what the audio ISR renders */
    uint8_t eng_req;             /* engine the UI asked for (the ISR switches at a block start) */
    uint8_t user;                /* user preset slot + 1 the sound came from (UI), 0 = none */
    voice_t v[NVOICE];
    /* LFO */
    uint32_t lfo_ph;
    int32_t lfo_val;             /* Q15 */
    int32_t lfo_fade;            /* Q15 ramp after note-on */
    uint32_t lfo_rnd;
    int16_t lfo_prev;            /* the S&H value of the cycle before (mod.c SLEW glides from it to lfo_rnd's) */
    /* keyboard / arp input: held notes in press order */
    uint8_t held[16];
    uint8_t nheld;
    uint8_t arp_phys;            /* keys physically held for the arp */
    uint8_t latched;             /* HOLD: keep notes after release */
    /* arp runtime */
    uint32_t arp_pos;            /* q8 samples into the current arp step */
    uint32_t arp_idx;
    uint8_t arp_note;            /* sounding arp note, 0 = none */
    uint8_t arp_walk;            /* WALK: the place in the note list it stands on */
    uint8_t arp_ch[3];           /* CHORD: the other notes sounding with arp_note, 0 = none */
    uint32_t arp_off;            /* q8 sample time of its note-off */
    /* sequencer */
    step_t step[NSTEP];
    uint32_t seq_pos;            /* q8 samples into the current step */
    uint16_t seq_idx;
    uint8_t seq_notes[4 + NLANE];   /* sounding seq notes (the step's notes, then its hits) */
    uint8_t seq_n;
    uint8_t seq_hold;            /* last step slides: keep the notes until the next step */
    uint8_t slide_glide;         /* next legato note glides (slide) */
    uint8_t rat_left;            /* RATCH: repeats of the playing step still to come (seq.c seq_ratchet) */
    uint32_t seq_off;
    uint8_t seq_active;          /* any step programmed */
    uint8_t rskip_idx;           /* live recording put notes into the step about to play: */
    uint8_t rskip_n, rskip[NLANE];   /* do not trigger them again there (they sound already) */
    /* NUDGE (QUANTIZE OFF, seq.c seq_tick): a step plays at its start + its nudge. Latched as a step starts: */
    uint32_t nd_late;            /* the step playing now plays at this seq_pos + 1 (0: it played) */
    uint32_t nd_early;           /* the next step plays early, at this seq_pos + 1 of this one (0: on its start) */
    uint8_t nd_fired;            /* that step + 1 once it played early (its start then plays nothing), 0 = none */
    /* live recording of held notes (seq.c rec_hold): the steps they are held into become TIEs */
    uint8_t rh_n, rh_note[4];    /* recorded notes still held, 0 = none */
    uint8_t rh_start;            /* the step they were recorded into */
    uint8_t rh_ties;             /* TIE steps written after it */
    uint8_t rh_last;             /* the last of them; rh_bak: what it held (an early release puts it back) */
    step_t rh_bak;
    /* mono */
    uint8_t mono_stack[8];
    uint8_t nmono;
    uint8_t mono_note;           /* note the MONO / LEGATO / UNISON voice(s) play, 0 = none */
    uint8_t rr;                  /* POLY ROTATE: next voice to try */
    /* mix runtime */
    int32_t peak;
    int32_t dist_hp, dist_lp1, dist_lp2;   /* DIST insert state (fx.c) */
    uint8_t tail;                /* blocks to mix after the last voice (the DIST / INSERT tail) */
    uint8_t ins_run;             /* the INSERT still sounds (fx.c track_insert: its wet share above 0) */
    /* (SLOOP 2.8) per-note ratchet (seq.c seq_step / seq_ratchet_notes): the parts each note of the playing step still plays */
    uint32_t rat_off[4];         /* samples to the note-off of note i's part, 0 = none */
    uint8_t rn_on;               /* the step playing ratchets per note (rat_left: its repeats are in rat_done) */
    uint8_t rn_note[4], rn_vel[4], rat_done[4];   /* the notes it plays (0: none), their velocities, the parts played */
    stoch_t stoch;               /* STOCHASTIC mode (above) */
    step_t stoch_step;           /* the step it generated for the one playing (seq.c seq_play; seq_ratchet reads it again) */
    uint32_t stoch_rs;           /* its loop's random state */
    uint16_t euc_pos;            /* EUCLID: the rhythm's step now (seq.c euclid_gen; 0 at the start) */
    uint16_t euc_pos2;           /* .. and layer B's (both < 64: the pair fills the 4 bytes euc_pos had) */
    uint8_t rsv_sz[5];           /* (sizeof(track_t) a multiple of 16: below) */
    int16_t armp, aholdp;        /* P_AMODE / P_AHOLD as last seen by the ISR */
    /* engine switch (voice.c engine_block): the old engine's voices fade out, then it switches */
    uint8_t xf_on, xf;           /* fading; blocks of the fade still to render */
    int16_t pe_old[8];           /* P_E0..P_E7 of the sounding engine: the fade renders with these */
    int16_t ps_old[24];          /* (21 used, 24 keeps track_t a multiple of 16 bytes) the same for its operator slots P_FM1_ATK .. P_FM4_LEVEL and P_FTYPE (the filter's CUT, RES, KEY
                                  * and TYPE are slots: a fade must not read the next engine's) */
    uint8_t xp_n, xp_note[4], xp_vel[4];   /* note-ons during the fade, played on the new engine */
    /* modulation matrix (mod.c): MIDI performance controllers of the track's channel, 0..127 */
    uint8_t mw, at;              /* CC1 mod wheel, channel aftertouch */
    uint8_t ex_off;              /* 127 - CC11 expression (0: full, the MIDI default) */
    uint8_t m_vel, m_key, m_vi;  /* the latest note-on: velocity, note, voice index (per-block destinations) */
    uint8_t sp_alt;              /* SPREAD: the side the next voice starts on (alternating, voice.c voice_start) */
    int16_t m_rnd;               /* .. its RAND */
    int32_t m_env;               /* the amp envelope of voice m_vi, last block (Q15) */
} track_t;
/* the audio ISR indexes trk[] with a multiply by a small immediate and a shift while the size is a multiple of 16; 1.5's
 * new track parameters (the INSERT, the filter TYPE, ENV SYNC) and state would make it no multiple (the constant
 * loaded first: +3 % on the ISR's static cost, target_budget.py): one pad, rsv_sz, keeps it */
_Static_assert(sizeof(track_t) % 16u == 0, "track_t: a multiple of 16 bytes (a cheap trk[] index on the target)");

typedef struct {
    int16_t g[G_COUNT];
    uint8_t playing, seq_mode;
    uint8_t grid;                /* 1: the keys are the DRUM grid (ui.c grid_on): only the lane keys play (seq.c);
                                  * 2: NAME (ui_name.c): no key plays; 3: SONG, A..D are its (seq.c song_key) */
    uint8_t rec;                 /* live recording armed: bit per track */
    uint8_t sel;                 /* selected track 0..NTRK-1: keys, pages, editor */
    int8_t octave;
    uint32_t tick;               /* sub-blocks since play */
    uint32_t cpu_q8;             /* audio ISR load, 1/256 */
    uint32_t master_q12;
    int32_t batt_raw;            /* smoothed ADC ch3 (battery divider), 0 = not read yet */
} song_t;

static track_t trk[NTRK];        /* the instrument: six parts */
static song_t song;
#define TSEL (&trk[song.sel])    /* the selected track */
/* the panel has four knobs and four columns, the firmware six tracks: the screens that show a track per knob or column (the
 * MIXER, HOME > TRACKS and LEVELS, the GLO layer, the FX layer's mutes) show a window of four: tracks 1..4, or, when the
 * selected track is 5 or 6, tracks 3..6 */
#define NWIN 4u
static inline uint32_t win_base(void) { return song.sel >= NWIN ? NTRK - NWIN : 0u; }

/* SWING of a track's step clock: the track's own plus the global one, at most 100 (#31). The sequencer
 * (seq.c step_samples) and the SLICER (slicer.c sl_enter) both time steps with it. At 100 the even
 * steps are 1.4 x the straight length and the odd ones 0.6 x. */
#define SWING_MAX 100
static inline int32_t track_swing(const track_t *t)
{
    int32_t sw = t->p[P_SSWING] + song.g[G_SWING];
    return sw < 0 ? 0 : sw > SWING_MAX ? SWING_MAX : sw;
}
/* the length of step idx of a straight length `base`, swung: even steps longer, odd ones shorter */
static inline uint32_t swing_step_len(const track_t *t, uint32_t base, uint32_t idx)
{
    int32_t sw = track_swing(t) * (int32_t)base / 250;
    return base + (uint32_t)((idx & 1u) ? -sw : sw);
}

/* ----------------------------------------------------------- system --- */
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")   /* slot store before the index update */
static volatile uint32_t fm1_ms;  /* milliseconds since boot (TIMER4-based, TIMER5 ISR in main.c) */
/* boot-loop guard (main.c): two boots in a row that die in the first 30 s -> UBOOT */
#define BOOTGUARD_MAGIC 0x42475244u
struct { uint32_t magic, failed, pending; } bootguard __attribute__((section(".noinit")));
